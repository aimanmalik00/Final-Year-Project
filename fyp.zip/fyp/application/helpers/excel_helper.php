<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
if (!function_exists('readExcelFile')) {
    /**
     * @param $FileUploadPath
     * @return mixed
     * @throws PHPExcel_Exception
     * @throws PHPExcel_Reader_Exception
     */
    function readExcelFile($inputFileName)
    {
        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch(Exception $e) {
            die('Error loading file"'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
        }//end try Catch
        //  Get worksheet dimensions
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();
        $headings = $sheet->rangeToArray('A1:' . $highestColumn . 1,
            NULL,
            TRUE,
            FALSE);
        $result = [];
        for ($row = 2; $row <= $highestRow; $row++){
            //  Read a row of data into an array
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                NULL,
                TRUE,
                FALSE);
            $rowData[0] = array_combine(SpaceToUnderscore($headings[0]), $rowData[0]);
            array_push($result,$rowData[0]);
        }//end for loop
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }//enf if statment
        return $result;
    }// end function readExcelFile
}//enf if statment


if (!function_exists('UploadFiles')) {
    /**
     * @param $fileName
     * @param $target_dir
     * @return bool
     */
    function UploadFiles($fileName, $target_dir)
    {
        $target_file = $target_dir . basename($fileName["name"]);
        if (move_uploaded_file($fileName["tmp_name"], $target_file)) {
            return $target_file;
        }//en if statment
        return false;
    }// end function UploadFiles
}//enf if statment


if (!function_exists('readExcel')) {
    /**
     * @param $inputFileName
     * @return bool
     * @throws PHPExcel_Exception
     * @throws PHPExcel_Reader_Exception
     */
    function readExcel($inputFileName)
    {
        // read file from path
        $objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
        //get only the Cell Collection
        $cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();
        //extract to a PHP readable array format
        foreach ($cell_collection as $cell) {
            $column = $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
            $row = $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
            $data_value = $objPHPExcel->getActiveSheet()->getCell($cell)->getValue();

            //The data will/should be after 2nd row only. of course, this can be modified to suit your need.
            if($row != 2 && $row != 1 ) {
                $arr_data[$row][$column] = $data_value;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        //send the data in an array format
        return $arr_data;
    }
}

if (!function_exists('readExcelByDate')) {
    /**
     * @param $inputFileName
     * @return bool
     * @throws PHPExcel_Exception
     * @throws PHPExcel_Reader_Exception
     */
    function readExcelByDate($inputFileName)
    {
        // read file from path
        $objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
        //get only the Cell Collection
        $cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();
        //extract to a PHP readable array format
        foreach ($cell_collection as $cell) {
            $column = $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
            $row = $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
            $data_value = $objPHPExcel->getActiveSheet()->getCell($cell)->getValue();

            if($row == 1 ) {
                if(strpos($data_value,"Viewing") === 0){
                    $Datainfo = explode("=",$data_value);
                    $date = str_replace("[","",$Datainfo[1]);
                    $date = str_replace("]","",$date);
                    $date = explode("-",$date);
                    $results['startdate'] = date('Y-m-d', strtotime($date[0]));
                    $results['enddate'] =  date('Y-m-d', strtotime($date[1]));
                };
            }elseif($row != 2 && $row != 1 ) {
                $arr_data[$row][$column] = $data_value;
            }
        }
        unset($objPHPExcel);
        $results['records'] = $arr_data;
        //send the data in an array format
        return $results;
    }
}