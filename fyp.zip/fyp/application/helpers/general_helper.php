<?php
INCLUDE APPPATH . 'third_party/PHPExcel/IOFactory.php';
function upload_image($id, $files, $image_dir)
{
    // print_r($_POST); die;
    $CI =& get_instance();
    $CI->load->library('upload');
    if (isset($files['file_image']) && !empty($files['file_image']['name']) && $files['file_image']['size'] > 0) {
        // echo "i am here"; die;

        if (!is_dir($image_dir . "/" . $id)) {
            mkdir($image_dir . "/" . $id, 0777);
            copy_indexhtml($image_dir . "/" . $id);
            $image_path = $image_dir . "/" . $id;
        } else {
            $image_path = $image_dir . "/" . $id;
        }

        $upload_path = $image_path . "/";
        $ext = pathinfo($files['file_image']['name'], PATHINFO_EXTENSION);
        $orig_file_name = uniqid() . "." . $ext;

        $CI->upload->initialize(array('overwrite' => TRUE,
            'upload_path' => $upload_path,
            'allowed_types' => 'jpeg|jpg|png|gif',
            'file_name' => $orig_file_name
        ));

        $CI->upload->do_upload('file_image');
        $image = $CI->upload->data();
        if ($image['is_image'] != 1) {
            return -1;
        }
        $CI->load->library('image_lib');
        //Image Resizing 800 x 600
        $config_large['source_image'] = $CI->upload->upload_path . $CI->upload->file_name;
        $config_large['maintain_ratio'] = TRUE;
        $config_large['new_image'] = $CI->upload->upload_path . "large_" . $CI->upload->file_name;
        $config_large['width'] = LARGE_WIDTH;
        $config_large['height'] = LARGE_HEIGHT;
        $config_large['create_thumb'] = FALSE;
        $CI->image_lib->initialize($config_large);
        if (!$CI->image_lib->resize()) {
            echo $CI->image_lib->display_errors();
            return -1;
        }
        //Image Resizing 600 x 400
        $config_med['source_image'] = $CI->upload->upload_path . $CI->upload->file_name;
        $config_med['maintain_ratio'] = TRUE;
        $config_med['new_image'] = $CI->upload->upload_path . "medium_" . $CI->upload->file_name;
        $config_med['width'] = MEDIUM_WIDTH;
        $config_med['height'] = MEDIUM_HEIGHT;
        $config_med['create_thumb'] = FALSE;
        $CI->image_lib->initialize($config_med);
        if (!$CI->image_lib->resize()) {
            echo $CI->image_lib->display_errors();
            return -1;
        }
        //Image Resizing 200 x 200
        $config_small['source_image'] = $CI->upload->upload_path . $CI->upload->file_name;
        $config_small['maintain_ratio'] = TRUE;
        $config_small['new_image'] = $CI->upload->upload_path . "thumb_" . $CI->upload->file_name;
        $config_small['width'] = THUMB_WIDTH;
        $config_small['height'] = THUMB_HEIGHT;
        $config_small['create_thumb'] = FALSE;
        $CI->image_lib->initialize($config_small);
        if (!$CI->image_lib->resize()) {
            echo $CI->image_lib->display_errors();
            return -1;
        }

        //unlink($image['full_path']);
        return $image;
        $config_small['height'] = THUMB_HEIGHT;
        $config_small['create_thumb'] = FALSE;
        $CI->image_lib->initialize($config_small);
        if (!$CI->image_lib->resize()) {
            echo $CI->image_lib->display_errors();
            return -1;
        }

        //unlink($image['full_path']);
        return $image;

    }
}

function delete_image($user_id, $image_name, $image_dir)
{
    if (file_exists($image_dir . "/" . $user_id . "/" . $image_name)) {
        @unlink($image_dir . "/" . $user_id . "/thumb_" . $image_name);
        @unlink($image_dir . "/" . $user_id . "/medium_" . $image_name);
        @unlink($image_dir . "/" . $user_id . "/large_" . $image_name);
        @unlink($image_dir . "/" . $user_id . '/' . $image_name);
    }

}

function is_user_loggedin($link = "")
{
    $CI =& get_instance();
    $user_id = 0;
    $user_id = $CI->session->userdata('user_id');
    if ($user_id) {
        return TRUE;
    } else {
        if ($link) {
            $session_url = array('sign_in_redirect' => $link);
        } else {
            $session_url = array('sign_in_redirect' => $_SERVER['REQUEST_URI']);
        }
        $CI->session->set_userdata($session_url);
        redirect('user', 'refresh');
    }
    redirect('user', 'refresh');
}

function is_admin_loggedin($link = "")
{
    $CI =& get_instance();
    $admin_id = 0;
    $admin_id = $CI->session->userdata('admin_id');
    if ($admin_id) {
        return TRUE;
    } else {
        if ($link) {
            $session_url = array('sign_in_redirect' => $link);
        } else {
            $session_url = array('sign_in_redirect' => $_SERVER['REQUEST_URI']);
        }
        $CI->session->set_userdata($session_url);
        redirect('admin', 'refresh');
    }
    redirect('admin', 'refresh');
}

function category_status_html($val)
{
    return get_status_html($val);
}

function product_status_html($val)
{
    return get_status_html($val);
}

function send_email($data, $tag = "Unknown")
{
    $CI =& get_instance();
    //print_R($data); exit;
    $CI->load->library('email');
    $CI->email->initialize(get_email_config());

    $CI->email->from($data['email_from'], WEBSITE_TITLE);
    $CI->email->to($data['email_to']);
    if (isset($data['bcc']) && !empty($data['bcc'])) {
        $CI->email->bcc($data['bcc']);
    } else {
        //$CI->email->bcc('muhammad.naeem@codeinformatics.com');
    }
    if (isset($data['upload']) && !empty($data['upload'])) {
        $CI->email->attach($data['upload']);
    }
    $CI->email->subject($data['subject']);
    $CI->email->message($data['body']);
    $CI->email->send();
    //echo $CI->email->print_debugger();exit;
}

function get_email_config()
{
    $config_email = array();
    $config_email['protocol'] = 'mail'; // mail, sendmail, or smtp    The mail sending protocol.
    $config_email['mailpath'] = '/usr/sbin/sendmail'; // The server path to Sendmail.
    $config_email['wordwrap'] = TRUE; // TRUE or FALSE (boolean)    Enable word-wrap.
    $config_email['mailtype'] = 'html'; // text or html Type of mail. If you send HTML email you must send it as a complete web page. Make sure you don't have any relative links or relative image paths otherwise they will not work.
    $config_email['charset'] = 'utf-8'; // Character set (utf-8, iso-8859-1, etc.).
    $config_email['validate'] = FALSE; // TRUE or FALSE (boolean)    Whether to validate the email address.
    $config_email['priority'] = 1; // 1, 2, 3, 4, 5    Email Priority. 1 = highest. 5 = lowest. 3 = normal.
    $config_email['crlf'] = "\r\n"; // "\r\n" or "\n" or "\r" Newline character. (Use "\r\n" to comply with RFC 822).
    $config_email['newline'] = "\r\n"; // "\r\n" or "\n" or "\r"    Newline character. (Use "\r\n" to comply with RFC 822).
    $config_email['bcc_batch_mode'] = FALSE; // TRUE or FALSE (boolean)    Enable BCC Batch Mode.
    $config_email['bcc_batch_size'] = 200; // Number of emails in each BCC batch.

    return $config_email;
}


function get_status_html($val)
{
    if ($val == STATUS_ACTIVE) {
        return '<span class="label label-sm label-success">Active</span>';
    } elseif ($val == STATUS_INACTIVE) {
        return '<span class="label label-sm label-danger">Inactive</span>';
    } else {
        return "";
    }
}


function product_actions($prod_id)
{
    $str = '';
    $str .= '<a href="/admin/product/edit/' . $prod_id . '" class="btn default btn-xs black" data-id="' . $prod_id . '"> <i class="fa fa-pencil-square-o"></i> Edit</a>
        
        	<a href="' . base_url("admin/product/suspend_product/$prod_id") . '" class="btn default btn-xs black" onClick="return confirm(\'Are you sure you want to suspend?\');"><i class="fa fa-trash-o"></i> Suspend</a>';
    return $str;
}

function settings_actions($setting_id)
{
    $str = '';
    $str .= '<a href="/admin/settings/edit/' . $setting_id . '" class="btn default btn-xs black" ><i class="fa fa-pencil-square-o"></i> Edit</a>';
    return $str;
}


function image_thumbnail($id, $image, $dir)
{
    $CI =& get_instance();

    $image_path = "/" . $dir . "/" . $id . "/" . $image;
    if (is_dir($image_path) || empty($image) || is_null($image)) {
        $image_path = "/assets/images/default70.jpg";
    }
    return '<img src="' . $image_path . '" width="100">';
}

function delete_images($image_dir, $image_name)
{
    @unlink($image_dir . "/thumb_" . $image_name);
    @unlink($image_dir . "/medium_" . $image_name);
    @unlink($image_dir . "/large_" . $image_name);
    @unlink($image_dir . '/' . $image_name);
}


function create_img_thumb($image_path, $id)
{
    if (isset($image_path) && !empty($image_path)) {
        return '<img src="' . base_url($id . '/thumb_' . $image_path) . '" />';
    } else {
        return "No image found";
    }
}

function copy_indexhtml($destination)
{
    copy("assets/index.html", rtrim($destination, '/') . "/index.html");
}

function importUser($row_callback = null)
{

    //print_r(SpaceToUnderscore('Hello World'));die;

    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');

    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv';
    $config['remove_spaces'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    //print_r($_FILES);die;
    if (!$CI->upload->do_upload('files')) {
        $data = array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
//print_r($inputFileName);die;

    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
        //echo '<pre>'; print_r( $inputFileType);die;
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $orderon_date = $_POST['date'];
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }

                $record['orderon_date'] = $orderon_date;
                $record['capture_date'] = CURRENT_DATE;
                $results[] = $record;
            }
        }


        //echo '<pre>'; print_r($results);die;
        return $results;
    }

}


function daily_sales_file($row_callback = null)
{

    //print_r(SpaceToUnderscore('Hello World'));die;

    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');

    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    //print_r($_FILES);die;
    if (!$CI->upload->do_upload('data_files')) {
        $data = array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;

    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
        //echo '<pre>'; print_r( $inputFileType);die;
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $orderon_date = $_POST['date'];
    $keys = array();
    $results = array();
    //echo '<pre>';print_r($highestColumn);die;
    if (is_callable($row_callback)) {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                    //$record[PercentageToNull($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            //$row = unlink($rowData[0]);
            //echo "<pre>";print_r($rowData);die;
            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                    //$record[PercentageToNull($keys)[$pos]] = $value;
                }

                $results[] = $record;
            }
        }


        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }

}
function read_ftp_file_bydate($report , $row_callback = null)
{

    $inputFileName = $report['local_file_path'];
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        log_message(
            'debug',
            'Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME). '": ' . $e->getMessage()
        );
        return;
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();

    $records =  array();
    for ($row = 1; $row <= $highestRow; $row++){
        $record = array();
        $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
        if ($row === 1) {
            foreach ($rowData[0] as $value) {
                if(strpos($value,"Viewing") === 0){
                    $Datainfo = explode("=",$value);
                    $date = str_replace("[","",$Datainfo[1]);
                    $date = str_replace("]","",$date);
                    $date = explode("-",$date);
                    $results['startdate'] = date('Y-m-d', strtotime($date[0]));
                    $results['enddate'] =  date('Y-m-d', strtotime($date[1]));
                }
            }
        }elseif ($row === 2){
            $keys = $rowData[0];
        } else {

            foreach ($rowData[0] as $pos => $value) {
                $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
            }
            $records[] = $record;
        }
    }
    $results['records'] = $records;

    unset($objPHPExcel);
    unset($inputFileType);
    return $results;

}
function read_ftp_file($report , $row_callback = null)
{

    $inputFileName = $report['local_file_path'];
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        log_message(
            'debug',
            'Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME). '": ' . $e->getMessage()
        );
        return;
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();

    $records =  array();

    for ($row = 1; $row <= $highestRow; $row++){
        $record = array();
        $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
        if ($row === 1){
            $keys = $rowData[0];
        } else {

            foreach ($rowData[0] as $pos => $value) {
                $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
            }
            $records[] = $record;
        }
    }
    unset($objPHPExcel);
    unset($inputFileType);
    return $records;

}

function upload_category($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    //$config['max_size'] = 5000;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;

    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }

}

/**
 * @param $value
 */
function dd($value)
{
    echo '<pre>';
    print_r($value);
    exit;
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_sales_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    // check detail data file is not uploaded
    if (!$CI->upload->do_upload('data_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        // if uploaded then get all data
        $keys = array();
        $results = array();
        $data = array('upload_data' => $CI->upload->data());
        if (!empty($data['upload_data']['file_name'])) {
            $import_xls_file = $data['upload_data']['file_name'];
        } else {
            $import_xls_file = 0;
        }
        $inputFileName = $path . $import_xls_file;
        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch (Exception $e) {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
        }
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();
        if (is_callable($row_callback)) {
            for ($row = 2; $row <= $highestRow; $row++) {
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
                if ($row === 2) {
                    $keys = $rowData[0];
                } else {
                    $record = array();
                    foreach ($rowData[0] as $pos => $value) {
                        $record[SpaceToUnderscore($keys)[$pos]] = $value;
                    }
                    $row_callback($record);
                }
            }
        } else {
            for ($row = 2; $row <= $highestRow; $row++) {
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
                if ($row === 2) {
                    $keys = $rowData[0];
                } else {
                    $record = array();
                    foreach ($rowData[0] as $pos => $value) {
                        $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                    }
                    $results[] = $record;
                }
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}


function weekly_summary_file($row_callback = null)
{

    //print_r(SpaceToUnderscore('Hello World'));die;
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');

    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    //print_r($_FILES);die;
    if (!$CI->upload->do_upload('summary_files')) {
        $data = array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
//print_r($inputFileName);die;

    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
        //echo '<pre>'; print_r( $inputFileType);die;
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    //$orderon_date = $_POST['date'];
    $keys = array();
    $results = array();
    //echo '<pre>';print_r($highestColumn);die;
    if (is_callable($row_callback)) {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                    //$record[PercentageToNull($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            //$row = unlink($rowData[0]);
            //echo "<pre>";print_r($rowData);die;
            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                    //$record[PercentageToNull($keys)[$pos]] = $value;
                }

                $results[] = $record;
            }
        }
    }
    unset($objPHPExcel);
    unset($inputFileType);
    if (file_exists($inputFileName)) {
        unlink($inputFileName);
    }
    return $results;
}


function salesDetailed($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('files')) {
        $data = array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;

    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}


function dataReadFromExcelFile($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('data_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_trafficDetail_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('data_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);//Identify file type using automatic PHPExcel_Reader_IReader resolution
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);//Create PHPExcel_Reader_IReader
        $objPHPExcel = $objReader->load($inputFileName); //Loads PHPExcel from file using automatic PHPExcel_Reader_IReader resolution
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }

    $sheet = $objPHPExcel->getSheet(0);  //PHPExcel_Worksheet Object

    $highestRow = $sheet->getHighestRow(); // number of rows in sheets
    $highestColumn = $sheet->getHighestColumn(); // number of column in sheet

    $keys = array();
    $results = array();

    if (is_callable($row_callback)) {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 2; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_traffic_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('summary_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}


/**
 * @param null $row_callback
 * @return array
 */
function monthly_promotionSummarry_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('summary_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull(RemoveBrakets(RemoveStricSign($keys))))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_brandstoreSource_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('source_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull(RemoveBrakets(SlashToUnderscore(RemoveStricSign($keys)))))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_brandstoreDate_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('date_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull(RemoveBrakets(SlashToUnderscore(RemoveStricSign($keys)))))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_brandstorePage_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('page_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull(RemoveBrakets(SlashToUnderscore(RemoveStricSign($keys)))))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}



/**
 * @param null $row_callback
 * @return array
 */
function executive_dashboard_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('date_file')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull(RemoveBrakets(SlashToUnderscore(RemoveStricSign($keys)))))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}



/**
 * @param null $row_callback
 * @return array
 */
function monthly_promotionCoupons_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('coupons_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull(RemoveBrakets(RemoveStricSign($keys))))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_forecastDetail_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('data_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);//Identify file type using automatic PHPExcel_Reader_IReader resolution
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);//Create PHPExcel_Reader_IReader
        $objPHPExcel = $objReader->load($inputFileName); //Loads PHPExcel from file using automatic PHPExcel_Reader_IReader resolution
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }

    $sheet = $objPHPExcel->getSheet(0);  //PHPExcel_Worksheet Object

    $highestRow = $sheet->getHighestRow(); // number of rows in sheets
    $highestColumn = $sheet->getHighestColumn(); // number of column in sheet

    $keys = array();
    $results = array();

    if (is_callable($row_callback)) {
        for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 2; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 2) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function weekly_forecast_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('summary_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * This function is used to Perform Action on Daily Charge Back Excel File
 * @param null $row_callback
 * @return array
 */
function chargeback($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('summary_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}


function campaigns($row_callback = null)
{

    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('campaign')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

function brands($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('brands')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }

                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }

}

function products($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $CI->load->model('Reports_model');
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('product')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull($keys))))))[$pos]] = $value;
                }

                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}



/**
 * @param null $row_callback
 * @return array
 */
function monthly_dropship_file($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('data_files')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;
    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {

            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);

            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[RemOf(Redundant(RedundantAll(SpaceToUnderscore(PercentageToNull(DashToNull(RemoveBrakets(SlashToUnderscore(RemoveStricSign($keys)))))))))[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }
}

/**
 * This function is used to Remove Space and convert lower case
 * @param $value
 * @return array|mixed
 */
function SpaceToUnderscore($value)
{
    $result = str_replace(' ', '_', $value);
    $result = array_map('strtolower', $result);
    return $result;
}

/**
 * This function is used to Remove Space and convert lower case
 * @param $value
 * @return array|mixed
 */
function RemoveStricSign($value)
{
    $result = str_replace('*', '', $value);
    $result = array_map('strtolower', $result);
    return $result;
}

/**
 * This function is used to Remove Space and convert lower case
 * @param $value
 * @return array|mixed
 */
function RemoveBrakets($value)
{
    $result = str_replace('(', '', $value);
    $result = str_replace(')', '', $result);
    $result = array_map('strtolower', $result);
    return $result;
}

/**
 * This function is used to Remove Dollar Sign
 * @param $value
 * @return mixed
 */
function RemoveDollarSign($value)
{
    $result = str_replace('$', ' ', $value);
    return $result;
}

/**
 * This function is used to Convert Excel Date into Unix Date
 * @param $value
 * @return false|string|null
 */
function DateConversionExcelFile($value)
{
    if (!empty($value)) {
        return gmdate("Y-m-d", ($value - 25569) * 86400);
    }
    return NULL;
}

/**
 * @param $value
 * @return false|null|string
 */
function DateConversion($value)
{
    if (!empty($value)) {
        if (is_numeric($value)) {
            $result = gmdate("Y-m-d", ($value - 25569) * 86400);
        } else {
            $result = date('Y-m-d', strtotime($value));
        }
    } else {
        $result = NULL;
    }
    return $result;
}

function timeAgo($time_ago)
{
    $time_ago = strtotime($time_ago);
    $cur_time   = time();
    $time_elapsed   = $cur_time - $time_ago;
    $seconds    = $time_elapsed;
    $minutes    = round($time_elapsed / 60 );
    $hours      = round($time_elapsed / 3600);

    // Seconds
    if($seconds <= 1){
        return "just now";
    }
    //Minutes
    else if($minutes <=60){
        if($minutes==1){
            return "one minute ago";
        }
        else{
            return "$minutes minutes ago";
        }
    }
    //Hours
    else if($hours <=24){
        if($hours==1){
            return "an hour ago";
        }else{
            return "$hours hrs ago";
        }
    }else{
        return date("F j, Y g:i a", $time_ago);
    }
}

function RemoveComma($value)
{
    $result = str_replace(',', '', $value);
    return $result;
}

function RemoveVariations($value)
{
    $result = str_replace('%', '', $value);
    return $result;
}

function DashToNull($value)
{
    $result = str_replace('-', '', $value);
    return $result;
}

function PercentageToNull($value)
{
    $result = str_replace('%', '', $value);
    return $result;
}

function SlashToUnderscore($value)
{
    $result = str_replace('/', '_', $value);
    return $result;
}

function Redundant($value)
{
    $result = str_replace('__', '_', $value);
    return $result;
}

function RedundantAll($value)
{
    $result = str_replace('___', '_', $value);

    return $result;
}

function RemOf($value)
{
    $result = str_replace('of', 'percentage', $value);

    return $result;
}

if (!function_exists('checkFileType')) {
    function checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type = '')
    {
        $_this = &get_instance();
        if (strpos($FileName, $FileType) == false && strpos($FileName, $FileType) !== 0) {
            if ($error_type != '' && $Redirect == '') {
                $_this->session->set_flashdata($error_type, '<strong>Error!</strong> ' . $Msg);
                return false;
            } else {
                $_this->session->set_flashdata('empty_files', '<strong>Error!</strong> ' . $Msg);
                redirect($Redirect);
            }
        } else {
            return true;
        }
    }
}

if (!function_exists('checkFtpFileType')) {
    function checkFtpFileType($FileName, $FileType, $Msg, $Redirect, $error_type = '')
    {
        $_this = &get_instance();
        if (strpos($FileName, $FileType) == false && strpos($FileName, $FileType) !== 0) {
            if ($error_type != '' && $Redirect == '') {
                log_message(
                    'debug',
                    $Msg
                );
                return false;
            } else {
                log_message(
                    'debug',
                    $Msg
                );
            }
        } else {
            return true;
        }
    }
}

/**
 * @param null $row_callback
 * @return array
 */
function upload_VendorCode($row_callback = null)
{
    $CI =& get_instance();
    $CI->load->library(array('excel', 'upload'));
    $path = REPORTS_DIR;
    $config['upload_path'] = $path;
    $config['allowed_types'] = 'csv|xlsx';
    $config['remove_spaces'] = TRUE;
    $config['encrypt_name'] = TRUE;
    //$config['max_size'] = 5000;
    $CI->upload->initialize($config);
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload('vendor_code')) {
        return array('error' => $CI->upload->display_errors());
    } else {
        $data = array('upload_data' => $CI->upload->data());
    }
    if (!empty($data['upload_data']['file_name'])) {
        $import_xls_file = $data['upload_data']['file_name'];
    } else {
        $import_xls_file = 0;
    }
    $inputFileName = $path . $import_xls_file;

    try {
        $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
        $objReader = PHPExcel_IOFactory::createReader($inputFileType);
        $objPHPExcel = $objReader->load($inputFileName);
    } catch (Exception $e) {
        die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
            . '": ' . $e->getMessage());
    }
    $sheet = $objPHPExcel->getSheet(0);
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    $keys = array();
    $results = array();
    if (is_callable($row_callback)) {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $row_callback($record);
            }
        }
    } else {
        for ($row = 1; $row <= $highestRow; $row++) {
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, null, true, false);
            if ($row === 1) {
                $keys = $rowData[0];
            } else {
                $record = array();
                foreach ($rowData[0] as $pos => $value) {
                    $record[SpaceToUnderscore($keys)[$pos]] = $value;
                }
                $results[] = $record;
            }
        }
        unset($objPHPExcel);
        unset($inputFileType);
        if (file_exists($inputFileName)) {
            unlink($inputFileName);
        }
        return $results;
    }

}

/**
 * This Function is used to get all the root file from root of  given directory
 * @param $path path of directory on FTP
 * @return array list of all directories
 */
function ftp_all_file_path_list($path){


    ini_set('memory_limit', '-1');//set memory limit
    ini_set('max_execution_time', 0);
    $ftpHost = FTP_HOST;
    $ftpUsername = FTP_USERNAME;
    $ftpPassword = FTP_PASSWORD;
    $ftpPort = FTP_PORT;

    // open an FTP connection
    $connId = ftp_ssl_connect($ftpHost, $ftpPort) or die("Couldn't connect to $ftpHost");
    //login to FTP
    $login_result = ftp_login($connId, $ftpUsername, $ftpPassword);

    if($login_result){
        $result = array();

        //Enable PASV
        ftp_pasv($connId, TRUE);

        //get list of file in the folder
        $dir_list = ftp_nlist($connId, $path);

        //check array
        if(is_array($dir_list)){

            //Traverse list
            foreach ($dir_list as $item){

                //check item is not moved folder (we have no need to read files from Moved folder)
                if($item != "Moved"){

                    //call function again for getting list of sub folder in path
                    $next_dir = ftp_all_file_path_list($path.'/'.$item);

                    //check if count of sub-files are not Zero
                    if(count($next_dir) != 0){

                        //Traverse list item and merge it
                        foreach($next_dir as $file) {

                            if($item != "Moved"){
                                if($item == $file){
                                    array_push($result, $file);
                                }else{
                                    array_push($result, $item."/".$file);
                                }
                            }

                        }

                    }else{
                        array_push($result, $item);

                    }
                }
            }
        }
        return $result;
    }
    // close the connection
    ftp_close($connId);

}

/**
 * This Function is used to get all the root file from root of  local directory
 * @param $ftp_file file on ftp server
 * @param $resumepos
 * @return array downloaded file location
 */
function download_ftp_file($ftp_file , $resumepos){

    ini_set('memory_limit', '-1');//set memory limit
    ini_set('max_execution_time', 0);
    ini_set('upload_max_filesize', '100M');
    ini_set('post_max_size', '100M');

    $ftpHost = FTP_HOST;
    $ftpUsername = FTP_USERNAME;
    $ftpPassword = FTP_PASSWORD;
    $ftpPort = FTP_PORT;

    // open an FTP connection
    $connId = ftp_ssl_connect($ftpHost, $ftpPort) or die("Couldn't connect to $ftpHost");
    //login to FTP
    $login_result = ftp_login($connId, $ftpUsername, $ftpPassword);
    $result = array();
    if($login_result) {
        //Enable PASV ( Note: must be done after ftp_login())
        ftp_pasv($connId, TRUE);

        ftp_set_option($connId, FTP_TIMEOUT_SEC, 3600);

        $ftp_file_array = explode("/", $ftp_file);//split file Path to array

        $file_name = $ftp_file_array[5]; //get name of file

        $local_file = getcwd() . '/assets/uploads/' . $file_name;

        $server_file = str_replace($file_name, '', $ftp_file);

        ftp_chdir($connId, $server_file);

        $fp =  $resumepos == 0 ? fopen($local_file,"w") : fopen($local_file,"r+");

        if(@ftp_fget($connId, $fp, $file_name, FTP_BINARY ,$resumepos ))
        {
            $result['success'] =  $local_file;
            log_message(
                'debug',
                "Successfully Written $file_name to $local_file\n"
            );
        } else {
            $result['error'] =  fstat($fp)['size'];
        }
        fclose($fp);
    }
    // close the connection
    ftp_close($connId);
    return $result;
}

/**
 * This Function is used to get all the root file from root of  local directory
 * @param $ftp_file file on ftp server
 * @return string downloaded file location
 */
function download_ftp_po_file($ftp_file , $resumepos){

    ini_set('memory_limit', '-1');//set memory limit
    ini_set('max_execution_time', 0);
    ini_set('upload_max_filesize', '100M');
    ini_set('post_max_size', '100M');

    $ftpHost = FTP_HOST;
    $ftpUsername = FTP_USERNAME;
    $ftpPassword = FTP_PASSWORD;
    $ftpPort = FTP_PORT;

    // open an FTP connection
    $connId = ftp_ssl_connect($ftpHost, $ftpPort) or die("Couldn't connect to $ftpHost");
    //login to FTP
    $login_result = ftp_login($connId, $ftpUsername, $ftpPassword);
    $result = array();
    if($login_result) {
        //Enable PASV ( Note: must be done after ftp_login())
        ftp_pasv($connId, TRUE);

        ftp_set_option($connId, FTP_TIMEOUT_SEC, 3600);

        $ftp_file_array = explode("/", $ftp_file);//split file Path to array

        $file_name = $ftp_file_array[6]; //get name of file

        $local_file = getcwd() . '/assets/uploads/' . $file_name;

        $server_file = str_replace($file_name, '', $ftp_file);

        ftp_chdir($connId, $server_file);

        $fp =  $resumepos == 0 ? fopen($local_file,"w") : fopen($local_file,"r+");

        if(@ftp_fget($connId, $fp, $file_name, FTP_BINARY ,$resumepos ))
        {
            $result['success'] =  $local_file;
            log_message(
                'debug',
                "Successfully Written $file_name to $local_file\n"
            );
        } else {
            $result['error'] =  fstat($fp)['size'];
        }
        fclose($fp);
    }
    // close the connection
    ftp_close($connId);
    return $result;
}

/**
 * This Function is used for moving file to moved directory
 * @param $location file location in local directory
 * @param $filename name of file
 * @param $content new name after move
 * @return bool message status
 */
function move_ftp_file($location, $filename , $content){

    ini_set('memory_limit', '-1');//set memory limit
    ini_set('max_execution_time', 0);
    ini_set('upload_max_filesize', '100M');
    ini_set('post_max_size', '100M');

    $ftpHost = FTP_HOST;
    $ftpUsername = FTP_USERNAME;
    $ftpPassword = FTP_PASSWORD;
    $ftpPort = FTP_PORT;

    // open an FTP connection
    $connId = ftp_ssl_connect($ftpHost, $ftpPort) or die("Couldn't connect to $ftpHost");
    //login to FTP
    $login_result = ftp_login($connId, $ftpUsername, $ftpPassword);

    if($login_result){
        //Enable PASV ( Note: must be done after ftp_login())
        ftp_pasv($connId, TRUE);
        ftp_set_option($connId, FTP_TIMEOUT_SEC, 180);

        if(ftp_put($connId, $location.'/Moved/'.$filename ,getcwd().'/assets/uploads/'.$filename, FTP_BINARY)){

            $fileNameInfo = explode(".", $filename);//Path
            $filetype = $fileNameInfo[sizeof($fileNameInfo)-1];//Get Type of file e.g. csv

            if(rename_ftp_file($connId, $location.'/Moved/', $filename , $content.".".$filetype)){
                ftp_cdup ($connId);
                ftp_delete ( $connId,$filename );// remove file from FTP directory
                unlink(getcwd().'/assets/uploads/'.$filename); // remove file from local directory
                ftp_close($connId);
                log_message(
                    'debug',
                    "File $filename Moved and Renamed to Moved Folder\n"
                );
                return TRUE;
            }else{
                ftp_cdup ($connId);
                ftp_delete($connId,$filename );// remove file from FTP directory
                unlink(getcwd().'/assets/uploads/'.$filename); // remove file from local directory
                ftp_close($connId);
                log_message(
                    'debug',
                    "File $filename Renaming Failed in Moved Folder\n"
                );
                return FALSE;
            }
        }else{
            ftp_delete($connId,$location.'/'.$filename );// remove file from FTP directory
            unlink(getcwd().'/assets/uploads/'.$filename); // remove file from local directory
            ftp_close($connId);
            log_message(
                'debug',
                "File $filename Uploaded Failed in Moved Folder\n"
            );
            return FALSE;
        }
    }
    // close the connection
    ftp_close($connId);
    return FALSE;
}

/**
 * This Function is used to Rename File name in moved directory
 * @param $ftp_stream ftp connectionID
 * @param $location
 * @param $filename
 * @param $content file renaming contents
 * @return bool message
 */
function rename_ftp_file($ftp_stream, $location, $filename , $content){
    // open the folder that have the file
    if(ftp_chdir($ftp_stream, $location)){
        // rename the file
        if(@ftp_rename($ftp_stream, $filename, $content)){
            return TRUE;
        }
    }
    return FALSE;
}

?>