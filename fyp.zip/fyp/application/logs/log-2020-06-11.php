<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-11 11:53:06 --> 404 Page Not Found: Xmlrpcphp/index
