<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-25 08:48:02 --> 404 Page Not Found: admin/Reports/verifysales
ERROR - 2020-10-25 08:48:08 --> 404 Page Not Found: admin/Reports/verifysales
ERROR - 2020-10-25 08:49:12 --> 404 Page Not Found: admin/Reports/verifysales
ERROR - 2020-10-25 11:52:13 --> Severity: Notice --> Undefined index: open_aggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 55
ERROR - 2020-10-25 11:52:13 --> Severity: Notice --> Undefined index: open_nonaggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 56
ERROR - 2020-10-25 11:52:13 --> Severity: Notice --> Undefined index: close_aggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 57
ERROR - 2020-10-25 11:52:13 --> Severity: Notice --> Undefined index: close_nonaggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 58
ERROR - 2020-10-25 11:52:47 --> Severity: Notice --> Undefined index: open_aggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 55
ERROR - 2020-10-25 11:52:47 --> Severity: Notice --> Undefined index: open_nonaggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 56
ERROR - 2020-10-25 11:52:47 --> Severity: Notice --> Undefined index: close_aggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 57
ERROR - 2020-10-25 11:52:47 --> Severity: Notice --> Undefined index: close_nonaggfile C:\New folder\htdocs\fyp\application\controllers\admin\Reports.php 58
ERROR - 2020-10-25 11:56:06 --> Query error: Table 'db_fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-10-25 11:56:12 --> Query error: Table 'db_fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-10-25 11:56:15 --> Query error: Table 'db_fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-10-25 11:56:26 --> Query error: Table 'db_fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-10-25 11:57:20 --> Query error: Table 'db_fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-10-25 11:57:40 --> Query error: Table 'db_fyp.tbl_stage_tanabi_dropship' doesn't exist - Invalid query: SELECT *
FROM `tbl_stage_tanabi_dropship`
WHERE `fk_vendor_id` IS NULL
ERROR - 2020-10-25 11:57:43 --> Query error: Table 'db_fyp.tbl_stage_tanabi_dropship' doesn't exist - Invalid query: SELECT *
FROM `tbl_stage_tanabi_dropship`
WHERE `fk_vendor_id` IS NULL
ERROR - 2020-10-25 11:57:50 --> Query error: Table 'db_fyp.tbl_stage_tanabi_dropship' doesn't exist - Invalid query: SELECT *
FROM `tbl_stage_tanabi_dropship`
WHERE `fk_vendor_id` IS NULL
ERROR - 2020-10-25 11:58:38 --> Query error: Table 'db_fyp.tbl_stage_forecast_weekly' doesn't exist - Invalid query: SELECT *
FROM `tbl_stage_forecast_weekly`
WHERE `fk_vendor_id` IS NULL
ERROR - 2020-10-25 12:01:30 --> Query error: Table 'db_fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-10-25 12:22:19 --> Query error: Table 'db_fyp.tbl_tanabi_main_purchaseorders' doesn't exist - Invalid query: SELECT `tbl_purchaseorders_vendors`.`vendor_id`, `tbl_purchaseorders_vendors`.`vendor_name`, `tbl_purchaseorders_vendors`.`domain`, MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date
FROM `tbl_purchaseorders_vendors`
LEFT JOIN `tbl_tanabi_main_purchaseorders` ON `tbl_tanabi_main_purchaseorders`.`fk_vendor_id` = `tbl_purchaseorders_vendors`.`vendor_id`
GROUP BY `tbl_purchaseorders_vendors`.`vendor_id`
ORDER BY `tbl_purchaseorders_vendors`.`vendor_name`
ERROR - 2020-10-25 12:22:32 --> Query error: Table 'db_fyp.tbl_stage_tanabi_dropship' doesn't exist - Invalid query: SELECT *
FROM `tbl_stage_tanabi_dropship`
WHERE `fk_vendor_id` IS NULL
