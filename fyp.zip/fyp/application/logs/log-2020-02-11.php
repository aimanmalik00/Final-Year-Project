<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-11 12:56:45 --> 404 Page Not Found: admin/Reports/amsreport
ERROR - 2020-02-11 12:56:50 --> 404 Page Not Found: admin/Reports/amsreport
