<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-21 01:07:28 --> 404 Page Not Found: /index
ERROR - 2020-06-21 02:16:47 --> 404 Page Not Found: /index
