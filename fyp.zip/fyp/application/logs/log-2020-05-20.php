<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-20 07:03:10 --> 404 Page Not Found: Wp_loginphp/index
