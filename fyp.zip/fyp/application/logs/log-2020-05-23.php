<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-23 08:11:19 --> 404 Page Not Found: Adminer/index.php
