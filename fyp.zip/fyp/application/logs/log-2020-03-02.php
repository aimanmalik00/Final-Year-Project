<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-02 01:35:18 --> 404 Page Not Found: /index
