<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-18 04:54:54 --> 404 Page Not Found: Wp_loginphp/index
