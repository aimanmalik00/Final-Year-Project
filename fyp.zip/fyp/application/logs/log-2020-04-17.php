<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-17 00:28:04 --> 404 Page Not Found: Wp_loginphp/index
ERROR - 2020-04-17 02:28:18 --> 404 Page Not Found: Wp_loginphp/index
