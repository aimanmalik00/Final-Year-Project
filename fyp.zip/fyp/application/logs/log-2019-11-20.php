<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-20 05:56:07 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 154
ERROR - 2019-11-20 06:06:52 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:06:54 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:06:56 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:06:58 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:08 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:29 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:31 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:33 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:35 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:36 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:57 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:07:59 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:09:01 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:09:11 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:09:13 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:10:13 --> Severity: Notice --> Use of undefined constant admin - assumed 'admin' C:\xampp5\htdocs\dev.tanabi\application\views\admin\view_vendor.php 136
ERROR - 2019-11-20 06:10:13 --> Severity: Notice --> Use of undefined constant get_vendor_rec - assumed 'get_vendor_rec' C:\xampp5\htdocs\dev.tanabi\application\views\admin\view_vendor.php 136
ERROR - 2019-11-20 06:10:13 --> Severity: Warning --> Division by zero C:\xampp5\htdocs\dev.tanabi\application\views\admin\view_vendor.php 136
ERROR - 2019-11-20 06:11:19 --> Severity: Notice --> Use of undefined constant admin - assumed 'admin' C:\xampp5\htdocs\dev.tanabi\application\views\admin\view_vendor.php 136
ERROR - 2019-11-20 06:11:19 --> Severity: Notice --> Use of undefined constant get_vendor_rec - assumed 'get_vendor_rec' C:\xampp5\htdocs\dev.tanabi\application\views\admin\view_vendor.php 136
ERROR - 2019-11-20 06:11:19 --> Severity: Warning --> Division by zero C:\xampp5\htdocs\dev.tanabi\application\views\admin\view_vendor.php 136
ERROR - 2019-11-20 06:11:46 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:11:58 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:13:01 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:13:03 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:13:05 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Array to string conversion C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 153
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Undefined index: vendor_id C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 156
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Undefined index: vendor_id C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 156
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Undefined index: vendor_id C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 156
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Undefined index: vendor_id C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 156
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Undefined index: vendor_id C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 156
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Undefined index: vendor_id C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 156
ERROR - 2019-11-20 06:13:46 --> Severity: Notice --> Undefined index: vendor_id C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 156
ERROR - 2019-11-20 06:14:29 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:15:59 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:16:11 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:16:30 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:17:44 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:18:04 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:18:08 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:18:12 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:18:50 --> 404 Page Not Found: admin/VendorInfo/index
ERROR - 2019-11-20 06:19:00 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:19:03 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:19:05 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:19:07 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:22:14 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:22:16 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:22:34 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:22:51 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:23:20 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:23:46 --> 404 Page Not Found: admin/Admin/admin
ERROR - 2019-11-20 06:27:21 --> Severity: Warning --> Illegal string offset 'vendor_id' C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 155
ERROR - 2019-11-20 06:27:21 --> Severity: Warning --> Illegal string offset 'vendor_id' C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 155
ERROR - 2019-11-20 06:27:21 --> Severity: Warning --> Illegal string offset 'vendor_id' C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 155
ERROR - 2019-11-20 06:27:21 --> Severity: Warning --> Illegal string offset 'vendor_id' C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 155
ERROR - 2019-11-20 06:27:21 --> Severity: Warning --> Illegal string offset 'vendor_id' C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 155
ERROR - 2019-11-20 06:27:21 --> Severity: Warning --> Illegal string offset 'vendor_id' C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 155
ERROR - 2019-11-20 06:27:21 --> Severity: Warning --> Illegal string offset 'vendor_id' C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 155
ERROR - 2019-11-20 06:27:21 --> Severity: Notice --> Undefined variable: result C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php 163
ERROR - 2019-11-20 06:42:00 --> Severity: Warning --> Missing argument 1 for Reports_model::get_vendor_rec(), called in C:\xampp5\htdocs\dev.tanabi\application\controllers\admin\Admin.php on line 152 and defined C:\xampp5\htdocs\dev.tanabi\application\models\Reports_model.php 69
ERROR - 2019-11-20 06:42:00 --> Severity: Notice --> Undefined variable: vendor_id C:\xampp5\htdocs\dev.tanabi\application\models\Reports_model.php 73
ERROR - 2019-11-20 07:19:29 --> 404 Page Not Found: admin/SetVendor/index
ERROR - 2019-11-20 07:19:51 --> 404 Page Not Found: admin/SetVendor/index
ERROR - 2019-11-20 07:20:02 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:20:12 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:20:16 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:20:20 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:20:36 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:20:56 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:23:56 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:24:01 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:24:25 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:45:01 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:45:09 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:45:44 --> 404 Page Not Found: admin/VendorInfo/index
ERROR - 2019-11-20 07:47:43 --> 404 Page Not Found: admin/VendorInfo/index
ERROR - 2019-11-20 07:48:06 --> 404 Page Not Found: admin/VendorInfo/index
ERROR - 2019-11-20 07:48:13 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:48:24 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:48:42 --> 404 Page Not Found: admin/Get_vendor_rec/index
ERROR - 2019-11-20 07:48:52 --> 404 Page Not Found: admin/DeleteVendor/index
ERROR - 2019-11-20 07:49:04 --> 404 Page Not Found: admin/DeleteVendor/index
ERROR - 2019-11-20 07:49:11 --> 404 Page Not Found: admin/View_vendor/index
