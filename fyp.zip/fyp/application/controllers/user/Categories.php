<?php

/**
 * This Categories Class for uplaading different categories
 */
class Categories extends CI_Controller
{
    /**
     * This Class Constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->library('encrypt');
        $this->load->library('encryption');
        $this->load->model('User_model');
        $this->load->helper('date');
    }//end class construct

    /**
     * This function is used to upload categories
     */
    public function upload_categories()
    {
        is_user_loggedin('user/categories');//check login status
        $data['status'] = FALSE;
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set MAX execution time
            ini_set('memory_limit', '1024M');//set Memort limit
            $fetchData = upload_category();//read file
            //check error 
            if (isset($fetchData['error'])) {
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> ' . strip_tags($fetchData["error"]));
                redirect('user/categories/upload_categories');
            }//end if statment
            //check $fetchData is not empty
            if (!empty($fetchData)) {
                $storeArray = [];
                foreach ($fetchData as $data) {
                    $db_data['asin'] = str_replace("'", "`", $data['asin']);
                    $db_data['category'] = str_replace("'", "`", isset($data['category']) ? $data['category'] : $data['tana_category']);
                    $db_data['vendor_name'] = str_replace("'", "`", isset($data['vendor']) ? $data['vendor'] : $data['reporting_vendor_name']);
                    $db_data['capture_at'] = CURRENT_DATE;
                    array_push($storeArray, $db_data);
                }//end foreach 
                $this->User_model->insert_categories($storeArray);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Category updated successfully!');
                redirect('user/categories/upload_categories');
            } else {//when $fetchData is empty
                echo 'error';
            }//end if statment
        }//end if statment
        $this->load->view('user/categories', isset($data) ? $data : NULL);
    }//end function upload_categories()

    /**
     * This function is use to RUN CRON JOB
     * @param null $value
     */
    public function updateCategory()
    {
        //check request type
        if (is_cli()) {
            ini_set('max_execution_time', 0);
            $getAllTempTableValue = $this->db->get('tbl_temp_asin_sales_category')->result();
            if (!empty($getAllTempTableValue)) {
                log_message('error', 'Cron Job is running.');
                foreach ($getAllTempTableValue as $index => $value) {
                    $this->db->query("INSERT INTO tbl_asin_sales_category(`asin`, `category`, `vendor_name`,`capture_at`) VALUES ('$value->asin','$value->category','$value->vendor_name',CURDATE()) ON DUPLICATE KEY UPDATE category = '$value->category'");
                    if ($this->db->affected_rows() == 2) {
                        $this->db->query("UPDATE `tbl_asin_sales_category` SET `updated_date` = CURDATE() WHERE `asin` = '$value->asin'");
                    }//end if statment
                }//end foreach
                log_message('error', 'Cron Job is Stop.');
                $this->db->query("TRUNCATE TABLE tbl_temp_asin_sales_category;");
            } else {
                log_message('error', 'Cron Job is not running because temp table is empty.');
            }//end if statment
        } else {
            log_message('error', 'Cron Job hit from browser.');
        }//end if statment
    }//end function updateCategory()
}//end class Categories