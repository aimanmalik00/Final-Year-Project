<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
* This is User Class for perform User Functionality
*/
class User extends CI_Controller
{
	/**
	* This is User Class constructor
	*/
     public function __construct()
    {
        parent::__construct();
        $this->load->library('encrypt');
        $this->load->library('encryption');
        $this->load->model('User_model');
    }//end class constructor
	
	/**
	* This function is used for login user after authentication
	*/
    public function index()
    {
        $this->load->library('encrypt');//load encryption library
        $user_id = $this->session->userdata('user_id');//get UserID from SESSION
		//check user is already login
        if ($user_id) {
			//redirect to User Dashboard
            redirect('/user/dashboard/');
        }//end if statment
		//check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
			//set Validation Rules for username and password
			$this->form_validation->set_rules(array(
                array(
                    'field' => 'username',
                    'rules' => 'trim|required|max_length[50]'
                ),
                array(
                    'field' => 'password',
                    'rules' => 'trim|required|max_length[50]'
                )
            ));
            // Run form validation
            if ($this->form_validation->run() === TRUE) {
				//validate user
                $user = $this->User_model->authenticate_user(array('user_name' => $this->input->post('username', TRUE), 'is_active' => STATUS_ACTIVE));
				//check user is Valid
                if (isset($user->user_id) && $this->encrypt->decode($user->password) === $this->input->post('password', TRUE)) {
					//set seesion variable
                    $this->session->set_userdata(array('user_id' => $user->user_id));
                    // Redirect signed in user with session redirect
                    if ($redirect = $this->session->userdata('sign_in_redirect')) {
                        $this->session->unset_userdata('sign_in_redirect');
                        redirect($redirect);
                    }//end if statment
                    redirect('user/dashboard');
                } else {//when user info is not valid
                    $data['error_msg'] = "Invalid username or password.";
                }//end if statment
            } else {//when user info is not valid
                $data['error_msg'] = "Invalid username or password.";
            }//end if statment
        }//end if statment
        // Load sign in view
        $this->load->view('user/login', isset($data) ? $data : '');
    }//end function index()

	/**
	* This function is used for Changing User password
	*/
     public function change_pass()
    {
        is_user_loggedin('user/change_pass');//check login status
		//check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
			//set Rules for changing password
            $this->form_validation->set_rules(array(
                array(
                    'field' => 'old_pass',
                    'rules' => 'trim|required'
                ),
                array(
                    'field' => 'new_pass',
                    'rules' => 'trim|required'
                ),
                array(
                    'field' => 'conf_pass',
                    'rules' => 'trim|required|matches[new_pass]'
                )
            ));

            // Run form validation
            if ($this->form_validation->run() === TRUE) {
				//validate UserID
                $admin_user = $this->User_model->authenticate_user(array('user_id' => $this->session->userdata('user_id')));
				//Check Old Password And New Password is not same
                if ($this->input->post('old_pass', TRUE) != $this->input->post('new_pass', TRUE)) {
					//check old password
                    if (isset($admin_user->user_id) && $this->encrypt->decode($admin_user->password) === $this->input->post('old_pass', TRUE)) {
                        $this->User_model->update($this->session->userdata('user_id'), array('password' => $this->encrypt->encode($this->input->post('new_pass', TRUE))));
                        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Password has been changed!');
                        redirect('user/user/change_pass');
                    } else {//when Old Password not matched
                        $data['error_msg'] = "Incorrect Field.";
                    }//end if statment
                } else {//when Old Password and New Password are same
                    $data['error_msg'] = "Old Password and New Password Must Be Different.";
                }//end if statment
            } else {//when form validation show error
                $data['error_msg'] = "Incorrect Password.";
            }//end if statment
        }//end if statment
        $this->load->view('user/change_pass', isset($data) ? $data : NULL);
    }//end function change_pass()

	/**
	* This function is used for loading Dashboard Page
	*/
     public function dashboard()
    {
        is_user_loggedin('user/dashboard');//check login status
        $this->load->view('user/dashboard', isset($data) ? $data : NULL);
    }//end function dashboard

    /**
	* This function is used to upload Vendor Code File
	*/
    public function Vendor()
    {
        is_user_loggedin('user/vendor');//check login status
		//Check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);// set MAX Execution time
            $fetchData = upload_VendorCode();//read file
            //check file error
			if (isset($fetchData['error'])) {
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> ' . strip_tags($fetchData["error"]));
                redirect('user/vendor');
            }//end if statment
			//check data is not empty
            if (!empty($fetchData)) {
                //Check total Rows of file
                if (COUNT($fetchData) > 1000) {
                    $this->session->set_flashdata('verror_msg', '<strong>Error!</strong> Records must be less then 1000 !');
                    redirect('user/vendor');
                }//end if statment
                // check vendor code column is EXIST
                if (!isset($fetchData[0]['vendor_code'])) {
                    $this->session->set_flashdata('verror_msg', '<strong>Error!</strong> Vendor Code header is missing!');
                    redirect('user/vendor');
                }//end if statment
                // check distribution column is EXIST
                if (!isset($fetchData[0]['distribution_type'])) {
                    $this->session->set_flashdata('derror_msg', '<strong>Error!</strong> Distribution Type header is missing!');
                    redirect('user/vendor');
                }//end if statment
                $storeArray = [];
                foreach ($fetchData as $data) {
                    $db_data['vendor_code'] = str_replace("'", "`", $data['vendor_code']);
                    $db_data['distribution_type'] = str_replace("'", "`", $data['distribution_type']);
                    $db_data['capture_date'] = CURRENT_DATE;
                    array_push($storeArray, $db_data);
                }//end foreach
                $addVendorResponse = $this->User_model->AddVendorRecord($storeArray);
                if (!empty($addVendorResponse)) {
                    $return = [
                        'totalValues'=>$addVendorResponse
                    ];
                    $this->session->set_userdata($return);
                } else {
                    $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Not add successfully!');
                }//end if statment
            }//end if statment
            redirect('user/vendor');
        }//end if statment
        $this->load->view('user/vendor', isset($data) ? $data : NULL);
    }//end function Vendor()

    /**
	* This function is used to logout user
	*/
     public function logout()
    {
        if (!is_user_loggedin()) {
            redirect('user');
        }//edn if statment
        $this->session->sess_destroy();
        redirect('user');
    }//end function logout()
}//end class user