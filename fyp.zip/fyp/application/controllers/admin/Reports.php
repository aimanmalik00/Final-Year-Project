<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * This is the class Report for the report functnality.
 */
class Reports extends CI_Controller
{
    /**
     * This is the Constructor of this Class in this we load libraries and Models.
     * @see model/Reports_model for Models
     * @see libraries file also
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->library('encrypt');
        $this->load->library('encryption');
        $this->load->model('Reports_model');
        $this->load->helper('date');
    }//end __construct

    /**
     * This function is used to Render Purchase Order View
     */
    public function purchaseorder()
    {
        //check login status
        is_admin_loggedin('admin/reports/purchaseorder');
        //get list of All Active Vendor
        $data['vendors'] = $this->Reports_model->get_all_vendors();
        //load view purchaseorder_new and send Data
        $this->load->view('admin/reports/purchaseorder_new', isset($data) ? $data : NULL);
    }//end purchaseorder function

    /**
     * This fucntion is used to read OPEN and CLOSE (AGG and NON-AGG ) Files
     * @throws PHPExcel_Exception
     * @throws PHPExcel_Reader_Exception
     */
    public function ajaxPO()
    {
        //check REQUEST_METHOD is Not post and show 403 Error
        if ($this->input->server('REQUEST_METHOD') != 'POST') {
            show_error('You don`t have permission to access on this server.', '403', 'Forbidden');
        }
        ini_set('max_execution_time', 0);//set max_execution_time
        ini_set("memory_limit", "1024M");//set memory limit 1GB
        $StoreArray = [];//declearing array for Open AGG and NON-AGG Record
        $closeStoreArray = [];//declearing array for Close AGG and NON-AGG Record
        $this->load->helper('excel');//loading Excel Helper 
        $this->load->library('excel');//loading Excel Library
        $target_dir = "assets/uploads/"; //set directory for file uploading 
        $fk_vendor_id = $this->input->post('fk_vendor_id', true);//get vendor ID from POST Variable
        //get File information $_FILES
        $open_aggfile = $_FILES["open_aggfile"];
        $open_nonaggfile = $_FILES["open_nonaggfile"];
        $close_aggfile = $_FILES["close_aggfile"];
        $close_nonaggfile = $_FILES["close_nonaggfile"];
        //check the ERROR type of Files
        //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
        if ($open_aggfile['error'] == 4 && $open_nonaggfile['error'] == 4 && $close_aggfile['error'] == 4 && $close_nonaggfile['error'] == 4) {
            $this->session->set_flashdata('vendor_id', $fk_vendor_id);
            $this->session->set_flashdata('error_msg_open', '<strong>Error!</strong> Open AGG and Non-AGG file are not selected!');
            $this->session->set_flashdata('error_msg_close', '<strong>Error!</strong> Close AGG and Non-AGG file are not selected!');
        }//end if statment
        //Open AGG and NON-AGG FILE DATA
        if ($open_aggfile['error'] != 4 && $open_nonaggfile['error'] != 4) {
            // Agg File Open
            $ResponseFilePath_OPEN_AG = UploadFiles($open_aggfile, $target_dir);
            //check response of OPEN AG File
            if ($ResponseFilePath_OPEN_AG != FALSE) {
                //read Exel file to get_open_aggfileData
                $get_open_aggfileData = readExcelFile($ResponseFilePath_OPEN_AG);
                //declar singleEntry Array for openAgg Data
                $singleEntry['openAgg'] = [];
                foreach ($get_open_aggfileData as $index) {
                    $OpenAgg['po'] = isset($index['poid']) ? $index['poid'] : $index['po'];
                    $OpenAgg['orderon_date'] = isset($index['orderdate']) ? $index['orderdate'] : $index['ordered_on'];
                    array_push($singleEntry['openAgg'], $OpenAgg);
                }//end foreach
                $StoreArray = $singleEntry;
            } else {//when Reponse from UploadFiles is False
                $this->session->set_flashdata('error_msg_open', '<strong>Error!</strong> File not upload successfully!');
            }//end if statment
            // Non Agg File OPEN
            $ResponseFilePath_OPEN_NONAG = UploadFiles($open_nonaggfile, $target_dir);
            //check response of OPEN NON AG File
            if ($ResponseFilePath_OPEN_NONAG != FALSE) {
                //read Exel file to get_open_nonaggfile Data
                $open_nonaggfile = readExcelFile($ResponseFilePath_OPEN_NONAG);
                //declar singleEntry Array for openAgg Data
                $singleEntry['openNonAgg'] = [];
                foreach ($open_nonaggfile as $index) {
                    $data['fk_vendor_id'] = $fk_vendor_id;
                    $data['po'] = isset($index['poid']) ? $index['poid'] : $index['po'];
                    $data['vendor'] = $index['vendor'];
                    $data['ship_to_location'] = isset($index['ship_to_location']) ? $index['ship_to_location'] : (isset($index['shiplocation']) ? $index['shiplocation'] : 'NA');
                    $data['model_number'] = isset($index['model_number']) ? $index['model_number'] : 'NA';
                    $data['asin'] = $index['asin'];
                    $data['sku'] = isset($index['sku']) ? $index['sku'] : (isset($index['vendorsku']) ? $index['vendorsku'] : $index['model_number']);
                    $data['title'] = isset($index['title']) ? str_replace('/', '', str_replace('"', '', $index['title'])) : 'NA';
                    $data['ack_code_translation_id'] = isset($index['ackcodetranslationid']) ? $index['ackcodetranslationid'] : (isset($index['availability']) ? $index['availability'] : 'NA');
                    $data['hand_off_type'] = isset($index['handofftype']) ? $index['handofftype'] : (isset($index['window_type']) ? $index['window_type'] : 'NA');
                    $data['status'] = isset($index['status']) ? $index['status'] : 'NA';
                    $data['delivery_window_start'] = isset($index['ship_window_start']) ? DateConversion($index['ship_window_start']) : (isset($index['ship_from']) ? DateConversion($index['ship_from']) : ((isset($index['handoffstart']) ? DateConversion($index['handoffstart']) : (isset($index['window_start']) ? DateConversion($index['window_start']) : '0'))));
                    $data['delivery_window_end'] = isset($index['ship_window_end']) ? DateConversion($index['ship_window_end']) : (isset($index['ship_to']) ? DateConversion($index['ship_to']) : ((isset($index['handoffend']) ? DateConversion($index['handoffend']) : (isset($index['window_end']) ? DateConversion($index['window_end']) : '0'))));
                    $data['backorder'] = isset($index['backorder']) ? $index['backorder'] : 'NA';
                    $data['case_size'] = isset($index['case_size']) ? $index['case_size'] : '';
                    $data['expected_delivery_date'] = isset($index['expected_ship_date']) ? DateConversion($index['expected_ship_date']) : (isset($index['edd']) ? DateConversion($index['edd']) : (isset($index['expected_date']) ? DateConversion($index['expected_date']) : ''));
                    $data['confirmed_delivery_date'] = isset($index['confirmed_ship_date']) ? DateConversion($index['confirmed_ship_date']) : '';
                    $data['submitted_cases'] = isset($index['quantity_submitted']) ? $index['quantity_submitted'] : (isset($index['qtysubmitted']) ? $index['qtysubmitted'] : (isset($index['quantity_requested']) ? $index['quantity_requested'] : ''));
                    $data['accepted_cases'] = isset($index['accepted_quantity']) ? $index['accepted_quantity'] : (isset($index['qtyaccepted']) ? $index['qtyaccepted'] : '');
                    $data['received_cases'] = isset($index['quantity_received']) ? $index['quantity_received'] : (isset($index['qtyreceived']) ? $index['qtyreceived'] : '');
                    $data['outstanding_cases'] = isset($index['quantity_outstanding']) ? $index['quantity_outstanding'] : (isset($index['qtyoutstanding']) ? $index['qtyoutstanding'] : (isset($index['outstanding_quantity']) ? $index['outstanding_quantity'] : ''));
                    $data['str_case_cost'] = (isset($index['unit_cost']) ? $index['unit_cost'] : (isset($index['unitcost']) ? $index['unitcost'] : '0'));
                    $data['str_total_cost'] = (isset($index['total_cost']) ? $index['total_cost'] : (isset($index['totalcost']) ? $index['totalcost'] : '0'));
                    $removeDollarSignCastCost = RemoveComma(RemoveDollarSign($data['str_case_cost']));
                    $removeDollarSignTotalCost = RemoveComma(RemoveDollarSign($data['str_total_cost']));
                    $data['case_cost'] = (!empty($removeDollarSignCastCost) ? $removeDollarSignCastCost : 0);
                    $data['total_cost'] = (!empty($removeDollarSignTotalCost) ? $removeDollarSignTotalCost : 0);
                    foreach ($StoreArray['openAgg'] as $openAgg) {
                        if ($openAgg['po'] == $data['po']) {
                            $data['orderon_date'] = DateConversion($openAgg['orderon_date']);
                        }
                    }
                    array_push($singleEntry['openNonAgg'], $data);
                }//end foreach
                $StoreArray = $singleEntry;
            } else {//when Reponse from UploadFiles is False
                $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                $this->session->set_flashdata('error_msg_open', '<strong>Error!</strong> File not upload successfully!');
            }//end if statment
            // check if Array Is empty then insert data into DB OPEN
            if (!empty($StoreArray['openNonAgg'])) {
                $this->Reports_model->insert_poData($StoreArray['openNonAgg']);
                $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                $this->session->set_flashdata('success_msg_open', '<strong>Success!</strong> Open AGG and Non-AGG file uploaded successfully!');
            }//end if statment
        } else {//When Open AGG and NON-AGG FILE DATA files are not Selected
            $this->session->set_flashdata('vendor_id', $fk_vendor_id);
            $this->session->set_flashdata('error_msg_open', '<strong>Error!</strong> Open AGG and Non-AGG file are not selected!');
        }//end if statment

        /*
        *Close AGG and NON-AGG FILE DATA
        */

        //check the ERROR type of Files
        //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
        if ($close_aggfile['error'] != 4 && $close_nonaggfile['error'] != 4) {
            // Agg File close
            $ResponseFilePath_CLOSE_AG = UploadFiles($close_aggfile, $target_dir);
            //check response of UploadFiles
            if ($ResponseFilePath_CLOSE_AG != FALSE) {
                //read  CLOSE_AG file to get_close_aggfileData
                $get_close_aggfileData = readExcelFile($ResponseFilePath_CLOSE_AG);
                //declar singleEntry Array variable for closeAgg
                $singleEntry['closeAgg'] = [];
                //traverse close_aggfileData
                foreach ($get_close_aggfileData as $index) {
                    $CloseAgg['po'] = isset($index['po']) ? $index['po'] : $index['poid'];
                    $CloseAgg['orderon_date'] = isset($index['ordered_on']) ? $index['ordered_on'] : $index['orderdate'];
                    array_push($singleEntry['closeAgg'], $CloseAgg);//
                }// end foreach
                $closeStoreArray = $singleEntry;
            } else { //when response of UploadFiles is False
                $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                $this->session->set_flashdata('error_msg_close', '<strong>Error!</strong> File not upload successfully!');
            }// end if statment
            // Non Agg File Close DATA INSERT
            $ResponseFilePath_CLOSE_NONAG = UploadFiles($close_nonaggfile, $target_dir);
            //check response of UploadFiles
            if ($ResponseFilePath_CLOSE_NONAG != FALSE) {
                //read  CLOSE_AG file to get_close_aggnonfileData
                $close_nonaggfile = readExcelFile($ResponseFilePath_CLOSE_NONAG);
                //declar singleEntry Array variable for closeNonAgg
                $singleEntry['closeNonAgg'] = [];
                //traverse close_aggfileData
                foreach ($close_nonaggfile as $index) {
                    $data['fk_vendor_id'] = $fk_vendor_id;
                    $data['fk_vendor_id'] = $fk_vendor_id;
                    $data['po'] = isset($index['poid']) ? $index['poid'] : $index['po'];
                    $data['vendor'] = $index['vendor'];
                    $data['ship_to_location'] = isset($index['ship_to_location']) ? $index['ship_to_location'] : (isset($index['shiplocation']) ? $index['shiplocation'] : 'NA');
                    $data['model_number'] = isset($index['model_number']) ? $index['model_number'] : 'NA';
                    $data['asin'] = $index['asin'];
                    $data['sku'] = isset($index['sku']) ? $index['sku'] : (isset($index['vendorsku']) ? $index['vendorsku'] : $index['model_number']);
                    $data['title'] = isset($index['title']) ? str_replace('/', '', str_replace('"', '', $index['title'])) : 'NA';
                    $data['ack_code_translation_id'] = isset($index['ackcodetranslationid']) ? $index['ackcodetranslationid'] : (isset($index['availability']) ? $index['availability'] : 'NA');
                    $data['hand_off_type'] = isset($index['handofftype']) ? $index['handofftype'] : (isset($index['window_type']) ? $index['window_type'] : 'NA');
                    $data['status'] = isset($index['status']) ? $index['status'] : 'NA';
                    $data['delivery_window_start'] = isset($index['ship_window_start']) ? DateConversion($index['ship_window_start']) : (isset($index['ship_from']) ? DateConversion($index['ship_from']) : ((isset($index['handoffstart']) ? DateConversion($index['handoffstart']) : (isset($index['window_start']) ? DateConversion($index['window_start']) : '0'))));
                    $data['delivery_window_end'] = isset($index['ship_window_end']) ? DateConversion($index['ship_window_end']) : (isset($index['ship_to']) ? DateConversion($index['ship_to']) : ((isset($index['handoffend']) ? DateConversion($index['handoffend']) : (isset($index['window_end']) ? DateConversion($index['window_end']) : '0'))));
                    $data['backorder'] = isset($index['backorder']) ? $index['backorder'] : 'NA';
                    $data['case_size'] = isset($index['case_size']) ? $index['case_size'] : '';
                    $data['expected_delivery_date'] = isset($index['expected_ship_date']) ? DateConversion($index['expected_ship_date']) : (isset($index['edd']) ? DateConversion($index['edd']) : (isset($index['expected_date']) ? DateConversion($index['expected_date']) : ''));
                    $data['confirmed_delivery_date'] = isset($index['confirmed_ship_date']) ? DateConversion($index['confirmed_ship_date']) : '';
                    $data['submitted_cases'] = isset($index['quantity_submitted']) ? $index['quantity_submitted'] : (isset($index['qtysubmitted']) ? $index['qtysubmitted'] : (isset($index['quantity_requested']) ? $index['quantity_requested'] : ''));
                    $data['accepted_cases'] = isset($index['accepted_quantity']) ? $index['accepted_quantity'] : (isset($index['qtyaccepted']) ? $index['qtyaccepted'] : '');
                    $data['received_cases'] = isset($index['quantity_received']) ? $index['quantity_received'] : (isset($index['qtyreceived']) ? $index['qtyreceived'] : '');
                    $data['outstanding_cases'] = isset($index['quantity_outstanding']) ? $index['quantity_outstanding'] : (isset($index['qtyoutstanding']) ? $index['qtyoutstanding'] : (isset($index['outstanding_quantity']) ? $index['outstanding_quantity'] : ''));
                    $data['str_case_cost'] = (isset($index['unit_cost']) ? $index['unit_cost'] : (isset($index['unitcost']) ? $index['unitcost'] : '0'));
                    $data['str_total_cost'] = (isset($index['total_cost']) ? $index['total_cost'] : (isset($index['totalcost']) ? $index['totalcost'] : '0'));
                    $removeDollarSignCastCost = RemoveComma(RemoveDollarSign($data['str_case_cost']));
                    $removeDollarSignTotalCost = RemoveComma(RemoveDollarSign($data['str_total_cost']));
                    $data['case_cost'] = (!empty($removeDollarSignCastCost) ? $removeDollarSignCastCost : 0);
                    $data['total_cost'] = (!empty($removeDollarSignTotalCost) ? $removeDollarSignTotalCost : 0);
                    foreach ($closeStoreArray['closeAgg'] as $closeAgg) {
                        if ($closeAgg['po'] == $data['po']) {
                            $data['orderon_date'] = DateConversion($closeAgg['orderon_date']);
                        }//end if
                    }//end foreach 
                    array_push($singleEntry['closeNonAgg'], $data);
                }// end foreach
                $closeStoreArray = $singleEntry;
            } else {// when response of UploadFiles is False
                $this->session->set_flashdata('error_msg_close', '<strong>Error!</strong> File not upload successfully!');
            }// end if statment
            // Close Agg Function DATA INSERT
            if (!empty($closeStoreArray['closeNonAgg'])) {
                $this->Reports_model->insert_poData($closeStoreArray['closeNonAgg']);
                $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                $this->session->set_flashdata('success_msg_close', '<strong>Success!</strong> Close AGG and Non-AGG file uploaded successfully!');
            }//end if statment
        } else { // when files are not exist 
            $this->session->set_flashdata('vendor_id', $fk_vendor_id);
            $this->session->set_flashdata('error_msg_close', '<strong>Error!</strong> Close AGG and Non-AGG file are not selected!');
        }//end if ststments
        redirect('admin/reports/purchaseorder');
    }// end ajaxPO fucntion

    /**
     * This function is not use any more Due to change require
     */
    public function purchaseorder_old()
    {
        //check admin login status
        is_admin_loggedin('admin/reports/purchaseorder');
        $data['vendors'] = $this->Reports_model->get_all_vendors(); //get list of all vendors
        $data['status'] = FALSE;
        // check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            //load Excel library
            $this->load->library('Excel');
            //set memory_limit
            ini_set('memory_limit', '2048M');
            $vender = $this->input->post('fk_vendor_id', true);//get vendor ID from POST Variable
            $orderDate = $this->input->post('date', true);//get Order from POST Variable
            $fetchData = importUser(); // importUser from the general helpers fucntion
            // check User are not empty
            if (!empty($fetchData)) {
                //declar storeData Array variable for storing data
                $storeData = [];
                //traverse User Data
                foreach ($fetchData as $data) {
                    $db_data['fk_vendor_id'] = $vender;
                    $db_data['str_case_cost'] = isset($data['case_cost']) ? $data['case_cost'] : $data['unit_cost'];
                    $db_data['ship_to_location'] = isset($data['ship_to_location']) ? $data['ship_to_location'] : $data['warehouse'];
                    $db_data['asin'] = $data['asin'];
                    $db_data['model_number'] = $data['model_number'];
                    $db_data['sku'] = $data['sku'];
                    $db_data['po'] = $data['po'];
                    $db_data['title'] = $data['title'];
                    $db_data['vendor'] = $data['vendor'];
                    $db_data['status'] = $data['status'];
                    $db_data['case_size'] = isset($data['case_size']) ? $data['case_size'] : '';
                    $db_data['backorder'] = isset($data['backorder']) ? $data['backorder'] : '';
                    $num1 = RemoveDollarSign(isset($data['case_cost']) ? $data['case_cost'] : isset($data['unit_cost']));
                    $num2 = RemoveDollarSign($data['total_cost']);
                    $num1 = RemoveComma($num1);
                    //$num2 = RemoveComma($num2);
                    $db_data['case_cost'] = $num1;
                    $db_data['total_cost'] = RemoveComma(RemoveDollarSign($data['total_cost']));
                    $db_data['str_total_cost'] = $data['total_cost'];
                    $db_data['delivery_window_start'] = DateConversion(isset($data['delivery_window_start']) ? $data['delivery_window_start'] : (isset($data['ship_from']) ? $data['ship_from'] : $data['ship_window_start']));
                    $db_data['delivery_window_end'] = DateConversion(isset($data['delivery_window_end']) ? $data['delivery_window_end'] : (isset($data['ship_to']) ? $data['ship_to'] : $data['ship_window_end']));
                    $db_data['expected_delivery_date'] = DateConversion(isset($data['expected_delivery_date']) ? $data['expected_delivery_date'] : isset($data['expected_ship_date']));
                    $db_data['confirmed_delivery_date'] = DateConversion(isset($data['confirmed_delivery_date']) ? $data['confirmed_delivery_date'] : isset($data['confirmed_ship_date']));
                    $db_data['submitted_cases'] = isset($data['submitted_cases']) ? $data['submitted_cases'] : (isset($data['submitted_quantity']) ? $data['submitted_quantity'] : $data['quantity_submitted']);
                    $db_data['accepted_cases'] = isset($data['accepted_cases']) ? $data['accepted_cases'] : $data['accepted_quantity'];
                    $db_data['received_cases'] = isset($data['recieved_cases']) ? $data['recieved_cases'] : (isset($data['recieved_quantity']) ? $data['recieved_quantity'] : (isset($data['quantity_recieved']) ? $data['quantity_recieved'] : ''));
                    $db_data['outstanding_cases'] = isset($data['outstanding_cases']) ? $data['outstanding_cases'] : (isset($data['outstanding_quantity']) ? $data['outstanding_quantity'] : $data['quantity_outstanding']);
                    $db_data['orderon_date'] = $orderDate;
                    $db_data['capture_date'] = CURRENT_DATE;
                    array_push($storeData, $db_data);
                }//end foreach
                //insert data into DB using insert_report Model
                $this->Reports_model->insert_report($storeData);
                $this->session->set_userdata('fk_vendor_id', $this->input->post('fk_vendor_id'));
                $this->session->set_flashdata('vendor_id', $this->input->post('fk_vendor_id'));
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Uploaded Successfully!');
                redirect('admin/reports/purchaseorder');

            } else {// when importUser are empty
                echo 'error';
            }// end if statment
        }//end if statment
        $this->load->view('admin/reports/purchaseorder', isset($data) ? $data : NULL);
    }//end purchaseorder_old function()

    /**
     * This function is to Verify PO Record
     */
    public function verify_po()
    {
        is_admin_loggedin('admin/reports/verifypurchaseorder');//Check Admin is logged in
        $vendor_id = $this->input->post('fk_vendor_id'); //get Vendor ID from POST
        $data['vendors'] = $this->Reports_model->get_all_vendors();//check list of all active vendors
        $data['count'] = $this->Reports_model->get_all_count($vendor_id);//get count of all vendors
        $data['repeated_dates'] = $this->Reports_model->repeated_each_date($vendor_id);//get repeated record by date
        $data['date_records'] = $this->Reports_model->dates_for_record($vendor_id);//get record by date
        $data['distinct_po'] = $this->Reports_model->distinct_po($vendor_id);//get distint PO Records
        $this->session->set_userdata('fk_vendor_id', $vendor_id); //set session
        $this->load->view('admin/reports/verifypurchaseorder', isset($data) ? $data : NULL);//load verifypurchaseorder view with data
    }//end verify_po function()

    /**
     * This function is po_dashboard for Geting Last PO Entry in Main
     */
    public function po_dashboard()
    {
        is_admin_loggedin('admin/reports/po_dashboard');//Check Admin is logged in
        $data['last_entries'] = $this->Reports_model->get_po_last_entries();//get last entry in PO Main Table
        $this->load->view('admin/reports/podashboard', isset($data) ? $data : NULL);//load verifypurchaseorder view with data
    }//end fucntion po_dashboard()

    /**
     * This function is delete_po for Deleting PO Record for Specific Vendor
     */
    public function delete_po()
    {
        is_admin_loggedin('admin/reports/delete_po');//Check Admin is logged in
        $vendor_id = $this->session->userdata('fk_vendor_id');//get Vendor ID 
        $this->Reports_model->delete_po($vendor_id);//delete record of Vendor from stage
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
        redirect('admin/reports/verify_po ');
        $this->load->view('admin/reports/verifypurchaseorder', isset($data) ? $data : NULL);//load verifypurchaseorder view with data
    }//end function delete_po()

    /**
     * This function is delete_po_selected for Deleting PO Record for Specific Vendor by slected Date
     */
    public function delete_po_selected()
    {
        is_admin_loggedin('admin/reports/delete_po');//Check Admin is logged in
        $vendor_id = $this->session->userdata('fk_vendor_id');//get Vendor ID 
        $date = $this->input->post('date_selected', TRUE);//get selected date 
        $this->Reports_model->delete_po_selected($vendor_id, $date);//delete record of Vendor by date  from stage
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> report deleted successfully!');
        redirect('admin/reports/verify_po ');
        $this->load->view('admin/reports/verifypurchaseorder', isset($data) ? $data : NULL);//load verifypurchaseorder view with data
    }//end function delete_po_selected()

    /**
     * This function is move_to_main for moving PO Record to main for Specific Vendor
     */
    public function move_to_main()
    {
        is_admin_loggedin('admin/reports/move_to_main');//Check Admin is logged in
        $vendor_id = $this->session->userdata('fk_vendor_id');//get Vendor ID 
        $this->Reports_model->move_to_main($vendor_id);//Move record of Vendor to main
        $this->Reports_model->delete_po($vendor_id);//delete record of Vendor from stage
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report moved successfully!');
        redirect('admin/reports/verify_po ');
    }//end function move_to_main()

    /**
     * This function is used to Render Daily Sales Detail And Upload Daily Sales File Data
     */
    public function daily_sales()
    {
        is_admin_loggedin('admin/reports/daily_sales_view');//Check Admin is logged in
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get Vendor ID
        $data['fk_vendor_id'] = $this->session->userdata('de_vendor_id');
        $data['status'] = FALSE;
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set max_execution_time
            $fk_vendor_id = $this->input->post('fk_vendor_id', true);//get vendorID from post
            $date = $this->input->post('date', true);// get date from post
            $this->load->library('Excel');//load excel library
            ini_set('memory_limit', '2048M');//set memory limit
            $category_Data = $this->Reports_model->get_all_categories();//get categories using Model
            //check the ERROR type of Files
            //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4) {
                $FileName = $_FILES['data_files']['name'];//get File Name
                $FileType = 'Detail';//set file type
                $Msg = 'Kindly select appropriate detail file'; // if file name does not contain FileType then we will show this message
                $Redirect = 'admin/reports/daily_sales';//set page for redirection
                $error_type = 'empty_filesDetail';//set error type
                // verify its Detail file.
                $fileCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                if ($fileCheckResponse != false) {
                    // Read Detail Sales File
                    $file_Data = daily_sales_file();//read daily sales using helper fucntion
                    $storeData = [];
                    foreach ($file_Data as $key2 => $data) {
                        $db_data['fk_vendor_id'] = $fk_vendor_id;
                        $db_data['asin'] = $data['asin'];
                        $db_data['product_title'] = $data['product_title'];
                        $db_data['str_shipped_cogs'] = $data['shipped_cogs'];
                        $db_data['model_no'] = isset($data['model_/_style_number']) ? $data['model_/_style_number'] : 'NA';
                        $db_data['str_shipped_cogs_percentage_total'] = isset($data['shipped_cogs_percentage_total']) ? $data['shipped_cogs_percentage_total'] : '';
                        $db_data['str_shipped_cogs_prior_period'] = isset($data['shipped_cogs_prior_period']) ? $data['shipped_cogs_prior_period'] : '';
                        $db_data['str_shipped_cogs_last_year'] = $data['shipped_cogs_last_year'];
                        $db_data['str_shipped_units'] = $data['shipped_units'];
                        $db_data['str_shipped_units_percentage_total'] = isset($data['shipped_units_percentage_total']) ? $data['shipped_units_percentage_total'] : '';
                        $db_data['str_shipped_units_prior_period'] = isset($data['shipped_units_prior_period']) ? $data['shipped_units_prior_period'] : '';
                        $db_data['str_shipped_units_last_year'] = $data['shipped_units_last_year'];
                        $db_data['str_shipped_units_last_year'] = $data['shipped_units_last_year'];
                        $db_data['shipped_cogs'] = RemoveComma(RemoveDollarSign($data['shipped_cogs']));
                        $db_data['shipped_cogs_percentage_total'] = RemoveVariations($data['shipped_cogs_percentage_total']);
                        $db_data['shipped_cogs_prior_period'] = RemoveVariations(isset($data['shipped_cogs_prior_period']) ? $data['shipped_cogs_prior_period'] : '');
                        $db_data['shipped_cogs_last_year'] = RemoveVariations($data['shipped_cogs_last_year']);
                        $db_data['shipped_units'] = RemoveComma(RemoveDollarSign(RemoveVariations($data['shipped_units'])));
                        $db_data['shipped_units_percentage_total'] = RemoveVariations($db_data['str_shipped_units_percentage_total']);
                        $db_data['shipped_units_prior_period'] = RemoveVariations(isset($data['shipped_units_prior_period']) ? $data['shipped_units_prior_period'] : '');
                        $db_data['shipped_units_last_year'] = RemoveVariations($data['shipped_units_last_year']);
                        $db_data['shipped_units_last_year'] = RemoveVariations($data['shipped_units_last_year']);
                        $db_data['category'] = isset($data['category']) ? $data['category'] : '';
                        $db_data['subcategory'] = isset($data['subcategory']) ? $data['subcategory'] : '';
                        $db_data['customer_returns'] = $data['customer_returns'];
                        $db_data['free_replacements'] = $data['free_replacements'];
                        $db_data['sale_date'] = DateConversion($date);
                        $db_data['capture_date'] = CURRENT_DATE;
                        array_push($storeData, $db_data);
                    }//end foreeach
                    // Reason Reduce Time for insertion
                    $this->Reports_model->insert_sales_data($storeData, $fk_vendor_id, $date);
                    // update Category based ASIN Number After Insertion
                    //$this->Reports_model->updateCategoryAsinDaily($fk_vendor_id, $date);
                    $this->session->set_userdata('de_vendor_id', $fk_vendor_id);
                    $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                    $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Detail report uploaded successfully!');

                }//end if statment
            } else { // No file was uploaded
                $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                $this->session->set_flashdata('empty_filesDetail', '<strong>Error!</strong> Kindly upload detail file!');
            }//end if statment
            redirect('admin/reports/daily_sales');
        }//end if statment
        //load View with data
        $this->load->view('admin/reports/daily_sales_view', isset($data) ? $data : NULL);
    }//end function daily_sales()


    /**
     * This function is used to render Weekly Uploading Page and Also Calculate Weekly Summary
     */
    public function weekly_sales_summary()
    {
        is_admin_loggedin('admin/reports/weekly_sales_summary_view');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get all active vendor
        // old code
        $data['fk_vendor_id'] = $this->session->userdata('we_vendor_id', true);
        $data['status'] = FALSE;
        //Check REQUEST_METHOD Is Post
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set max execution time
            ini_set("memory_limit", "1024M"); // set memory limit
            $vendor_id = $this->input->post('fk_vendor_id', true);//get vendor if from Post variable
            $daterange = $this->input->post('datefilter', true);// get date range from the post Variable
            $daterangeIndex = explode(" - ", $daterange);// split date range on " - "
            $startDate = date('Y-m-d', strtotime($daterangeIndex[0])); // convert String to time and set date formate "Y-m-d" for Starting Date
            $endDate = date('Y-m-d', strtotime($daterangeIndex[1])); // convert String to time and set date formate "Y-m-d" for ending Date
            $currentDate = date('Y-m-d');// get Current date
            $this->session->set_userdata('we_vendor_id', $vendor_id);//set session 
            //check the ERROR type of Files
            //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4 && $_FILES['summary_files']['error'] != 4) {
                $FileNameDetail = $_FILES['data_files']['name'];//get Data File Name
                $FileTypeDetail = 'Detail';//set Data file type
                $MsgDetail = 'Kindly select appropriate detail file';//if Data file name does not contain FileType then we will show this message
                $error_typeDetail = 'empty_filesDetail';//set error type for Data file
                $RedirectDetail = '';
                // verify its Detail file.
                $fileCheckResponse = checkFileType($FileNameDetail, $FileTypeDetail, $MsgDetail, $RedirectDetail, $error_typeDetail);
                $FileNameSummary = $_FILES['summary_files']['name'];//get Summary File Name
                $FileTypeSummary = 'Summary';//set Summary file type
                $MsgSummary = 'Kindly select appropriate summary file';//if Summary file name does not contain FileType then we will show this message
                //$Redirect = 'admin/reports/weekly_sales_summary';
                $error_typeSummary = 'empty_filesSummary';//set error type for Summary file
                $RedirectSummary = '';
                // verify its summary file.
                $fileSummaryCheckResponse = checkFileType($FileNameSummary, $FileTypeSummary, $MsgSummary, $RedirectSummary, $error_typeSummary);
                if ($fileCheckResponse == FALSE || $fileSummaryCheckResponse == FALSE) {
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Detail and Summary report file must be valid!');
                    redirect('admin/reports/weekly_sales_summary');
                }//end if statment
            }//end if statment
            //check the ERROR type of Files
            //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4) {
                $FileName = $_FILES['data_files']['name'];//get Data File Name
                $FileType = 'Detail';//set Data file type
                $Msg = 'Kindly select appropriate detail file';//if Data file name does not contain FileType then we will show this message
                $error_type = 'empty_filesDetail';//set error type for Data file
                $Redirect = '';
                // verify its Detail file.
                $fileCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                $file_Data = weekly_sales_file();//get file date
                $numberRecord = count($file_Data[0]);//get number of rows
                //check rows in excel are 2
                if ($numberRecord == 2) {
                    $this->session->set_flashdata('empty_filesDetail', '<strong>Error!</strong> Detail report data is not appropriated!');
                } else {// when number of rows are not equal to 2
                    // store detail data file into DB
                    $storeData = [];
                    foreach ($file_Data as $key2 => $data) {
                        $db_data['fk_vendor_id'] = $vendor_id;
                        $db_data['asin'] = $data['asin'];
                        $db_data['model_no'] = isset($data['model_/_style_number']) ? $data['model_/_style_number'] : 'NA';
                        $db_data['product_title'] = $data['product_title'];
                        $db_data['str_shipped_cogs'] = isset($data['shipped_cogs']) ? $data['shipped_cogs'] : '';
                        $db_data['str_shipped_cogs_percentage_total'] = isset($data['shipped_cogs_percentage_total']) ? $data['shipped_cogs_percentage_total'] : '';
                        $db_data['str_shipped_cogs_prior_period'] = isset($data['shipped_cogs_prior_period']) ? $data['shipped_cogs_prior_period'] : '';
                        $db_data['str_shipped_cogs_last_year'] = isset($data['shipped_cogs_last_year']) ? $data['shipped_cogs_last_year'] : '';
                        $db_data['str_shipped_units'] = isset($data['shipped_units']) ? $data['shipped_units'] : '';
                        $db_data['str_shipped_units_percentage_total'] = isset($data['shipped_units_percentage_total']) ? $data['shipped_units_percentage_total'] : '';
                        $db_data['str_shipped_units_prior_period'] = isset($data['shipped_units_prior_period']) ? $data['shipped_units_prior_period'] : '';
                        $db_data['str_shipped_units_last_year'] = isset($data['shipped_units_last_year']) ? $data['shipped_units_last_year'] : '';
                        // create new Variable for Shipped Cogs
                        $shipped_cogs = isset($data['shipped_cogs']) ? $data['shipped_cogs'] : '';
                        $db_data['shipped_cogs'] = RemoveComma(RemoveDollarSign($shipped_cogs));
                        // create new Variable for shipped cogs percentage total
                        $shipped_cogs_percentage_total = isset($data['shipped_cogs_percentage_total']) ? $data['shipped_cogs_percentage_total'] : '';
                        $db_data['shipped_cogs_percentage_total'] = RemoveVariations($shipped_cogs_percentage_total);
                        $db_data['shipped_cogs_prior_period'] = RemoveVariations($db_data['str_shipped_cogs_prior_period']);
                        // create new Variable for shipped cogs last year
                        $shipped_cogs_last_year = isset($data['shipped_cogs_last_year']) ? $data['shipped_cogs_last_year'] : '';
                        $db_data['shipped_cogs_last_year'] = RemoveVariations($shipped_cogs_last_year);
                        $db_data['shipped_units'] = RemoveComma(RemoveDollarSign(RemoveVariations($data['shipped_units'])));
                        $db_data['shipped_units_percentage_total'] = RemoveVariations($db_data['str_shipped_units_percentage_total']);
                        $db_data['shipped_units_prior_period'] = RemoveVariations($db_data['str_shipped_units_prior_period']);
                        $db_data['shipped_units_last_year'] = RemoveVariations($data['shipped_units_last_year']);
                        $db_data['shipped_units_last_year'] = RemoveVariations($data['shipped_units_last_year']);
                        $db_data['category'] = isset($data['category']) ? $data['category'] : '';
                        $db_data['subcategory'] = isset($data['subcategory']) ? $data['subcategory'] : '';
                        $db_data['customer_returns'] = $data['customer_returns'];
                        $db_data['free_replacements'] = $data['free_replacements'];
                        $db_data['start_date'] = DateConversion($startDate);
                        $db_data['end_date'] = DateConversion($endDate);
                        $db_data['capture_date'] = $currentDate;
                        array_push($storeData, $db_data);
                    }//end foreach
                    // for insertion call Model Function
                    $this->Reports_model->insert_sales_weekly($storeData, $vendor_id, $startDate, $endDate);
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('success_msgDetail', '<strong>Success!</strong> Detail report uploaded successfully!');
                }// end if statment
            } else {

                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('empty_filesDetail', '<strong>Error!</strong> Kindly upload detail report!');
            }//end if statment
            //check the ERROR type of Files 
            //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['summary_files']['error'] != 4) {
                $FileName = $_FILES['summary_files']['name']; // set file name
                $FileType = 'Summary';//set Summary file type
                $Msg = 'Kindly select appropriate summary file';//if Summary file name does not contain FileType then we will show this message
                //$Redirect = 'admin/reports/weekly_sales_summary';
                $error_type = 'empty_filesSummary';//set Summary file error type
                $Redirect = '';
                // verify its summary file.
                //checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                $summary_Data = weekly_summary_file();
                $arr1[] = $summary_Data[0];
                if (!empty($arr1)) {
                    foreach ($arr1 as $data1) {
                        $ar1_data['str_shipped_cogs_reported'] = $data1['reported'];
                        $ar1_data['str_shipped_cogs_prior_period'] = $data1['prior_period'];
                        $ar1_data['str_shipped_cogs_last_year'] = $data1['last_year'];
                        $ar1_data['shipped_cogs_reported'] = RemoveComma(RemoveDollarSign($data1['reported']));
                        $ar1_data['shipped_cogs_prior_period'] = RemoveVariations($data1['prior_period']);
                        $ar1_data['shipped_cogs_last_year'] = RemoveComma(RemoveVariations($data1['last_year']));
                        $array1[] = $ar1_data;
                    }//end foreach 
                }//end if statment
                $arr2[] = $summary_Data[1];
                if (!empty($arr2)) {
                    foreach ($arr2 as $data2) {
                        // old code
                        //$ar2_data['fk_vendor_id'] = $this->input->post('fk_vendor_id');
                        $ar2_data['fk_vendor_id'] = $vendor_id;
                        $ar2_data['str_shipped_units_reported'] = $data2['reported'];
                        $ar2_data['str_shipped_units_prior_period'] = $data2['prior_period'];
                        $ar2_data['str_shipped_units_last_year'] = $data2['last_year'];
                        $ar2_data['shipped_units_reported'] = RemoveComma($data2['reported']);
                        $ar2_data['shipped_units_prior_period'] = RemoveVariations($data2['prior_period']);
                        $ar2_data['shipped_units_last_year'] = RemoveComma(RemoveVariations($data2['last_year']));
                        $ar2_data['start_date'] = DateConversion($startDate);
                        $ar2_data['end_date'] = DateConversion($endDate);
                        $ar2_data['capture_date'] = DateConversion(CURRENT_DATE);
                        $array2[] = $ar2_data;
                    }//end foreach
                }//end if statment 
                $summary_data = $result[0] = $array1[0] + $array2[0];
                $this->Reports_model->insert_sales_weekly_summary($summary_data);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msgSummary', '<strong>Success!</strong> Summary report uploaded successfully!');
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('empty_filesSummary', '<strong>Error!</strong> Kindly upload summary report!');
            }//end if statment
            redirect('admin/reports/weekly_sales_summary');
        }//end if statment
        $this->load->view('admin/reports/weekly_sales_summary_view', isset($data) ? $data : NULL);
    }//end function weekly_sales_summary()

    /**
     * This function is used to Render Monthly Sales View
     * Also Perform File Read and Data Storage Activity On POST Call
     */
    public function monthly_sales_summary()
    {
        is_admin_loggedin('admin/reports/weekly_sales_summary_view');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get all active vendor list
        $data['fk_vendor_id'] = $this->session->userdata('mo_vendor_id');//get vendorID from session variable
        $data['status'] = FALSE;
        //check the ERROR type of Files
        //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set max execution time
            $vendor_id = $this->input->post('fk_vendor_id', true);//get VendorID from POST Variable
            $daterange = $this->input->post('datefilter', true);//get date range from from POST Variable
            $daterangeIndex = explode(" - ", $daterange);// split date range on " - "
            $startDate = date('Y-m-d', strtotime($daterangeIndex[0])); // convert String to time and set date formate "Y-m-d" for Starting Date
            $endDate = date('Y-m-d', strtotime($daterangeIndex[1])); // convert String to time and set date formate "Y-m-d" for end Date
            $this->session->set_userdata('mo_vendor_id', $vendor_id);
            //check the ERROR type of Files
            //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4 && $_FILES['summary_files']['error'] != 4) {
                $FileNameDetail = $_FILES['data_files']['name'];//get file name
                $FileTypeDetail = 'Detail';//set file type
                $MsgDetail = 'Kindly select appropriate detail file';//if Detail file name does not contain FileType then we will show this message
                $error_typeDetail = 'empty_filesDetail';// set error type
                $RedirectDetail = '';
                // verify its Detail file.
                $fileCheckResponse = checkFileType($FileNameDetail, $FileTypeDetail, $MsgDetail, $RedirectDetail, $error_typeDetail);
                $FileNameSummary = $_FILES['summary_files']['name'];//get file name
                $FileTypeSummary = 'Summary';//set file type
                $MsgSummary = 'Kindly select appropriate summary file';//if Summary file name does not contain FileType then we will show this message
                //$Redirect = 'admin/reports/monthly_sales_summary';
                $error_typeSummary = 'empty_filesSummary';// set error type
                $RedirectSummary = '';
                // verify its summary file.
                $fileSummaryCheckResponse = checkFileType($FileNameSummary, $FileTypeSummary, $MsgSummary, $RedirectSummary, $error_typeSummary);
                if ($fileCheckResponse == FALSE || $fileSummaryCheckResponse == FALSE) {
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Detail and Summary report file must be valid!');
                    redirect('admin/reports/monthly_sales_summary');
                }//end if statment
            }//end if statment
            //check the ERROR type of Files
            //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4) {
                $FileName = $_FILES['data_files']['name'];//get file name
                $FileType = 'Detail';//set file type
                $Msg = 'Kindly select appropriate detail file';//if  file name does not contain FileType then we will show this message
                //$Redirect = 'admin/reports/monthly_sales_summary';
                $error_type = 'empty_filesDetail';// set error type
                $Redirect = '';
                // verify its Detail file.
                $fileDetailCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                if ($fileDetailCheckResponse != false) {
                    // get all Detail file Data from CSV file
                    $file_Data = weekly_sales_file();
                    // create array for assign values
                    $storeData = [];
                    foreach ($file_Data as $key2 => $data) {
                        $db_data['fk_vendor_id'] = $vendor_id;
                        $db_data['asin'] = $data['asin'];
                        $db_data['model_no'] = isset($data['model_/_style_number']) ? $data['model_/_style_number'] : 'NA';
                        $db_data['product_title'] = isset($data['product_title']) ? $data['product_title'] : '';
                        $db_data['str_shipped_cogs'] = isset($data['shipped_cogs']) ? $data['shipped_cogs'] : '';
                        $db_data['str_shipped_cogs_percentage_total'] = isset($data['shipped_cogs_percentage_total']) ? $data['shipped_cogs_percentage_total'] : '';
                        $db_data['str_shipped_cogs_prior_period'] = isset($data['shipped_cogs_prior_period']) ? $data['shipped_cogs_prior_period'] : '';
                        $db_data['str_shipped_cogs_last_year'] = isset($data['shipped_cogs_last_year']) ? $data['shipped_cogs_last_year'] : '';
                        $db_data['str_shipped_units'] = isset($data['shipped_units']) ? $data['shipped_units'] : '';
                        $db_data['str_shipped_units_percentage_total'] = isset($data['shipped_units_percentage_total']) ? $data['shipped_units_percentage_total'] : '';
                        $db_data['str_shipped_units_prior_period'] = isset($data['shipped_units_prior_period']) ? $data['shipped_units_prior_period'] : '';
                        $db_data['str_shipped_units_last_year'] = isset($data['shipped_units_last_year']) ? $data['shipped_units_last_year'] : '';
                        $db_data['shipped_cogs'] = RemoveComma(RemoveDollarSign($db_data['str_shipped_cogs']));
                        $db_data['shipped_cogs_percentage_total'] = RemoveVariations($db_data['str_shipped_cogs_percentage_total']);
                        $db_data['shipped_cogs_prior_period'] = RemoveVariations($db_data['str_shipped_cogs_prior_period']);
                        $db_data['shipped_cogs_last_year'] = RemoveVariations($db_data['str_shipped_cogs_last_year']);
                        $db_data['shipped_units'] = RemoveComma(RemoveDollarSign(RemoveVariations($db_data['str_shipped_units'])));
                        $db_data['shipped_units_percentage_total'] = RemoveVariations($db_data['str_shipped_units_percentage_total']);
                        $db_data['shipped_units_prior_period'] = RemoveVariations($db_data['str_shipped_units_prior_period']);
                        $db_data['shipped_units_last_year'] = RemoveVariations($db_data['str_shipped_units_last_year']);
                        $db_data['category'] = isset($data['category']) ? $data['category'] : '';
                        $db_data['subcategory'] = isset($data['subcategory']) ? $data['subcategory'] : '';
                        $db_data['customer_returns'] = $data['customer_returns'];
                        $db_data['free_replacements'] = $data['free_replacements'];
                        $db_data['start_date'] = DateConversion($startDate);
                        $db_data['end_date'] = DateConversion($endDate);
                        $db_data['capture_date'] = CURRENT_DATE;
                        array_push($storeData, $db_data);
                    }//end foreach
                    $this->Reports_model->insert_sales_monthly($storeData, $vendor_id, $startDate, $endDate);
                    // update Category based ASIN Number After Insertion
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('success_msgDetail', '<strong>Success!</strong> Detail report uploaded successfully!');
                }//end if statment
            } else {//when file not found
                $this->session->set_flashdata('empty_filesDetail', '<strong>Error!</strong> Kindly upload detail report!');
            }//end if statment
            //check the ERROR type of Files
            //UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['summary_files']['error'] != 4) {
                $FileName = $_FILES['summary_files']['name'];//get file name
                $FileType = 'Summary';//set file type
                $Msg = 'Kindly Select Appropriate Summary File';//if Summary file name does not contain FileType then we will show this message
                //$Redirect = 'admin/reports/monthly_sales_summary';
                $error_type = 'empty_filesSummary';//set error type
                $Redirect = '';
                // verify its Summary file.
                $fileSummaryCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                if ($fileSummaryCheckResponse != false) {
                    // get all Summary file Data from CSV file
                    $summary_Data = weekly_summary_file();
                    // store First row data of Summary file
                    $arr1[] = $summary_Data[0];
                    if (!empty($arr1)) {
                        foreach ($arr1 as $data1) {
                            $ar1_data['str_shipped_cogs_reported'] = $data1['reported'];
                            $ar1_data['str_shipped_cogs_prior_period'] = $data1['prior_period'];
                            $ar1_data['str_shipped_cogs_last_year'] = $data1['last_year'];
                            $ar1_data['shipped_cogs_reported'] = RemoveComma(RemoveDollarSign($data1['reported']));
                            $ar1_data['shipped_cogs_prior_period'] = RemoveVariations($data1['prior_period']);
                            $ar1_data['shipped_cogs_last_year'] = RemoveComma(RemoveVariations($data1['last_year']));
                            $array1[] = $ar1_data;
                        }//end foreach
                    }//end if statment

                    // store second Row data of Summary file
                    $arr2[] = $summary_Data[1];
                    if (!empty($arr2)) {
                        foreach ($arr2 as $data2) {
                            $ar2_data['fk_vendor_id'] = $vendor_id;
                            $ar2_data['str_shipped_units_reported'] = $data2['reported'];
                            $ar2_data['str_shipped_units_prior_period'] = $data2['prior_period'];
                            $ar2_data['str_shipped_units_last_year'] = $data2['last_year'];
                            $ar2_data['shipped_units_reported'] = RemoveComma($data2['reported']);
                            $ar2_data['shipped_units_prior_period'] = RemoveVariations($data2['prior_period']);
                            $ar2_data['shipped_units_last_year'] = RemoveComma(RemoveVariations($data2['last_year']));
                            $ar2_data['start_date'] = DateConversion($startDate);
                            $ar2_data['end_date'] = DateConversion($endDate);
                            $ar2_data['capture_date'] = CURRENT_DATE;
                            $array2[] = $ar2_data;
                        }//end foreach
                    }//end if statment
                    $summary_data = $result[0] = $array1[0] + $array2[0];
                    //insert Montly sales Summary
                    $this->Reports_model->insert_sales_monthly_summary($summary_data);
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('success_msgSummary', '<strong>Success!</strong> Summary report uploaded successfully!');
                }//end if statment
            } else {// when file not found
                $this->session->set_flashdata('empty_filesSummary', '<strong>Error!</strong> Kindly upload summary report!');
            }//end if statment
            redirect('admin/reports/monthly_sales_summary');
        }//end if statment
        $this->load->view('admin/reports/monthly_sales_summary_view', isset($data) ? $data : NULL);
    }//end function monthly_sales_summary()

    /**
     * This function is used for Verify Sales View
     */
    public function verify_sales()
    {
        $vendor_id = $this->input->post('fk_vendor_id', true);//get VendorID from POST Variable
        is_admin_loggedin('admin/reports/verifysales'); // check login status
        $data['count'] = $this->Reports_model->get_sdaily_count($vendor_id);// get Sales daily count
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get all vendors
        $data['countw'] = $this->Reports_model->get_sweekly_count($vendor_id);//get Sales weekly count
        $data['countm'] = $this->Reports_model->get_smonthly_count($vendor_id);//get Sales monthly count
        $data['repeated_dates_daily'] = $this->Reports_model->repeated_daily_sales_date($vendor_id);// get repeated daily sales date
        $data['date_daily'] = $this->Reports_model->dates_daily_sales_record($vendor_id);//get all dates daily sales record
        $data['repeated_dates_weekly'] = $this->Reports_model->repeated_weekly_sales_date($vendor_id);//get repeated weekly sales date
        $data['date_weekly'] = $this->Reports_model->dates_weekly_sales_record($vendor_id);//get weekly sales dates record
        $data['repeated_dates_monthly'] = $this->Reports_model->repeated_monthly_sales_date($vendor_id);//get repeated monthly sales date
        $data['date_monthly'] = $this->Reports_model->dates_monthly_sales_record($vendor_id);//get dates monthly sales record
        $data['fk_vendor_id'] = $vendor_id;//get vendorID
        $this->session->set_userdata('fk_vendor_id', $vendor_id);//Set VendorID in Session
        $this->load->view('admin/reports/verifysales', isset($data) ? $data : NULL);//load View with data
    }//end function verify_sales() 

    /**
     * This function is used for Last Entry of Sales in main table
     */
    public function sales_dashboard()
    {
        is_admin_loggedin('admin/reports/sales_dashboard');//check login status
        $data['last_entries_daily'] = $this->Reports_model->get_sales_daily_last_entries();// get last entry date in daily sales for all active vendors
        $data['last_entries_weekly'] = $this->Reports_model->get_sales_weekly_last_entries();// get last entry date in Weekly sales for all active vendors
        $data['last_entries_monthly'] = $this->Reports_model->get_sales_monthly_last_entries();// get last entry date in monthly sales for all active vendors
        $this->load->view('admin/reports/salesdashboard', isset($data) ? $data : NULL);// load view with data
    }//end function sales_dashboard()

    /**
     * This function is used for Deleting all the Sales from stage table
     */
    public function delete_sales()
    {
        is_admin_loggedin('admin/reports/delete_sales');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID form Session variable
        //check vendorID is not empty
        if ($vendor_id != '') {
            //delete all the sale of vendor
            $delete_sales_overAll = $this->Reports_model->deleteAllSalesSpecificVendor($vendor_id);
            //check response of the model
            if ($delete_sales_overAll == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Record deleted successfully!');
            } else {//when reponse is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record deleted!');
            }//end if statment
        } else {//when vendor id is empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_sales');
    }//end function delete_sales()

    /**
     * This function is used for Deleting daily Sales from stage table
     */
    public function delete_sales_daily()
    {
        is_admin_loggedin('admin/reports/delete_sales_daily');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');// get VendorID from Session Variable
        $date = $this->input->post('date_selected', TRUE);//get date from POST Variable
        //check vendorID and date is not empty
        if ($vendor_id != '' && $date != '') {
            //call model to delete sales
            $Response = $this->Reports_model->delete_sales_daily($vendor_id, $date);
            //check response of mdoel
            if ($Response == true) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when thier is no record for deletion , response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {// check vendorID and date is empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        $this->session->set_userdata('fk_vendor_id', $vendor_id);
        redirect('admin/reports/verify_sales');
    }//end function delete_sales_daily()

    /**
     * This function is used for Deleting Weekly Sales from stage table
     */
    public function delete_sales_weekly()
    {
        is_admin_loggedin('admin/reports/delete_sales_weekly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');// get VendorID from Session Variable
        $daterange = $this->input->post('datefilter', true);//get date from POST Variable
        $daterangeIndex = explode(" - ", $daterange);//split Date Range
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for end Date
        //check vendorID , start date and end date is not empty
        if ($vendor_id != '' && $s_date != '' && $e_date) {
            //calling model to delete weekly sale and get response
            $Response = $this->Reports_model->delete_sales_weekly($vendor_id, $s_date, $e_date);
            //check response of model
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when there is no record to delete
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//check vendorID , start date and end date is empty 
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_sales');
    }//end function delete_sales_weekly()

    /**
     * This function is used for Deleting Monthly Sales from stage table
     */
    public function delete_sales_monthly()
    {
        is_admin_loggedin('admin/reports/delete_sales_monthly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');// get VendorID from Session Variable
        $daterange = $this->input->post('datefilter1', true);//get date from POST Variable
        $daterangeIndex = explode(" - ", $daterange);//split Date Range
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for end Date
        //check vendorID , start date and end date is not empty
        if ($vendor_id != '' && $s_date != '' && $e_date) {
            //calling model to delete monthly sale and get response
            $Response = $this->Reports_model->deleteMonthlySalesVendor($vendor_id, $s_date, $e_date);
            //check response of model
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when there is no record to delete
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//check vendorID , start date and end date is empty 
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_sales');
    }//end function delete_sales_monthly()

    /**
     * This function is used for Move Sales from stage table to Main
     */
    public function move_to_main_sales()
    {
        is_admin_loggedin('admin/reports/move_to_main_sales');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');// get VendorID from Session Variable
        $this->Reports_model->move_to_main_sale($vendor_id);//calling model to Move sale and get response
        $this->session->set_userdata('fk_vendor_id', $vendor_id);
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report moved successfully!');
        redirect('admin/reports/verify_sales');
    }//end function move_to_main_sales()

    /**
     * This function is for Uploading Sales Detail
     */
    public function sales_detailed()
    {
        is_admin_loggedin('admin/reports/sales_detailed');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all active vendor 
        $data['status'] = FALSE;
        //Check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $fk_vendor_id = $this->input->post('fk_vendor_id', true);//get VendorID from POST Variable
            $this->load->library('Excel');//load Excel Library
            ini_set('memory_limit', '1024M');//set memory limit
            $fetchData = salesDetailed();//read file
            //check file have data
            if (!empty($fetchData)) {
                $storeArray = [];
                foreach ($fetchData as $data) {
                    if (empty($data['tana_category'])) {
                        break;
                    }//end if statment
                    $dbdata['fk_vendor_id'] = $fk_vendor_id;
                    $dbdata['category'] = $data['tana_category'];
                    $dbdata['shipped_cogs'] = $data['shipped_cogs'];
                    $dbdata['shipped_units'] = $data['shipped_units'];
                    $dbdata['receipt_dollar'] = $data['receipt_cogs'];
                    $dbdata['month_date'] = DateConversionExcelFile($data['date']);
                    array_push($storeArray, $dbdata);
                }//end foreach
                if (!empty($storeArray)) {
                    $this->Reports_model->insert_sale_sptp($storeArray);
                    $this->session->set_userdata('fk_vendor_id', $fk_vendor_id);
                    $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                    $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report uploaded successfully!');
                }//end if statment
                $this->session->set_userdata('fk_vendor_id', $fk_vendor_id);
                redirect('admin/reports/sales_detailed');
            } else {//when file have no data
                echo 'error';
            }// end if statment
        }// end if statment
        $this->load->view('admin/reports/sales_detailed', isset($data) ? $data : NULL);
    }//end function sales_detailed()

    /**
     * This function is for Uploading Weekly Traffic
     */
    public function weekly_traffic()
    {
        is_admin_loggedin('admin/reports/weeklytraffic');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get lsit of all active vendor
        $data['fk_vendor_id'] = $this->session->userdata('we_vendor_id', true);//get VendorID
        $data['status'] = FALSE;
        $this->session->set_userdata('fk_vendor_id', $data['fk_vendor_id']);//st VendorID in Session
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set MAX exe time
            ini_set("memory_limit", "2048M");//set memory limit
            $vendor_id = $this->input->post('fk_vendor_id', true);//get VendorID form POST variable
            $daterange = $this->input->post('datefilter', true);//get Date Range form POST variable
            $daterangeIndex = explode(" - ", $daterange);//split Date Range
            $startDate = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
            $endDate = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for End Date
            $currentDate = date('Y-m-d');//get Current Data
            $this->session->set_userdata('fk_vendor_id', $vendor_id);//set VendorID in Session Variable
            if (!isset($vendor_id) || $vendor_id == NULL) {//Check VendorID is Not set or Null
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Vendor not Selected!');
            } elseif ($startDate == NULL && $endDate == NULL) {//Check Starting Date and End Date is Null
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Starting and Ending Date must be Selected!');
            } elseif ($_FILES['data_files']['error'] == 4) {// Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Detail Data File!');
            } elseif ($_FILES['data_files']['error'] != 4) {// Check UPLOAD_ERR_NO_FILE(4); file was uploaded.
                $FileNameDetail = $_FILES['data_files']['name'];//get file name
                $FileTypeDetail = 'Detail';///set file type
                $MsgDetail = 'Kindly select appropriate detail file';//set file message when file is invalid
                $error_typeDetail = 'empty_filesDetail';//set file errortype
                $RedirectDetail = '';
                // verify its Detail file.
                $fileCheckResponse = checkFileType($FileNameDetail, $FileTypeDetail, $MsgDetail, $RedirectDetail, $error_typeDetail);
                if ($fileCheckResponse == FALSE) {
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Detail report file must be valid!');
                    redirect('admin/reports/weekly_traffic');
                }//end if
                // get traffic Detail File Data
                $file_Data = weekly_trafficDetail_file();
                $storeData = [];
                foreach ($file_Data as $key2 => $data) {
                    $db_data['fk_vendor_id'] = $vendor_id;
                    $db_data['asin'] = $data['asin'];
                    $db_data['product_title'] = $data['product_title'];
                    $db_data['sub_category'] = isset($data['subcategory']) ? $data['subcategory'] : '';
                    $db_data['category'] = $data['category'];
                    $db_data['str_change_glance_view_reported'] = isset($data['change_in_glance_view_reported']) ? $data['change_in_glance_view__reported'] : '';
                    $db_data['str_change_glance_view_prior_period'] = isset($data['change_in_glance_view_prior_period']) ? $data['change_in_glance_view_prior_period'] : '';
                    $db_data['str_change_glance_view_last_year'] = isset($data['change_in_gv_last_year']) ? $data['change_in_gv_last_year'] : '';
                    $db_data['str_change_conversion_reported'] = isset($data['change_conversion_reported']) ? $data['change_conversion_reported'] : '';
                    $db_data['str_change_conversion_prior_period'] = isset($data['change_in_conversion_prior_period']) ? $data['change_in_conversion_prior_period'] : '';
                    $db_data['str_change_conversion_last_year'] = isset($data['change_in_conversion_last_year']) ? $data['change_in_conversion_last_year'] : '';
                    $db_data['str_change_unique_visitors_reported'] = isset($data['change_conversion_reported']) ? $data['change_conversion_reported'] : '';
                    $db_data['str_change_unique_visitors_prior_period'] = isset($data['unique_visitors_prior_period']) ? $data['unique_visitors_prior_period'] : '';
                    $db_data['str_change_unique_visitors_last_year'] = isset($data['unique_visitors_last_year']) ? $data['unique_visitors_last_year'] : '';
                    $db_data['str_fast_track_glance_view_reported'] = isset($data['fast_track_glance_view']) ? $data['fast_track_glance_view'] : '';
                    $db_data['str_fast_track_glance_view_prior_period'] = isset($data['fast_track_glance_view_prior_period']) ? $data['fast_track_glance_view_prior_period'] : '';
                    $db_data['str_fast_track_glance_view_last_year'] = isset($data['fast_track_glance_view_last_year']) ? $data['fast_track_glance_view_last_year'] : '';
                    $db_data['change_glance_view_reported'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_glance_view_reported'])));
                    $db_data['change_glance_view_prior_period'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_glance_view_prior_period'])));
                    $db_data['change_glance_view_last_year'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_glance_view_last_year'])));
                    $db_data['change_conversion_reported'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_conversion_reported'])));
                    $db_data['change_conversion_prior_period'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_conversion_prior_period'])));
                    $db_data['change_conversion_last_year'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_conversion_last_year'])));
                    $db_data['change_unique_visitors_reported'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_unique_visitors_reported'])));
                    $db_data['change_unique_visitors_prior_period'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_unique_visitors_prior_period'])));
                    $db_data['change_unique_visitors_last_year'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_change_unique_visitors_last_year'])));
                    $db_data['fast_track_glance_view_reported'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_fast_track_glance_view_reported'])));
                    $db_data['fast_track_glance_view_prior_period'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_fast_track_glance_view_prior_period'])));
                    $db_data['fast_track_glance_view_last_year'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_fast_track_glance_view_last_year'])));
                    $db_data['start_date'] = DateConversion($startDate);
                    $db_data['end_date'] = DateConversion($endDate);
                    $db_data['capture_date'] = $currentDate;
                    array_push($storeData, $db_data);
                }//end foreach
                // insert data using model
                $Response = $this->Reports_model->insert_weekly_traffic($storeData);
                //check response of model
                if ($Response == true) {
                    $this->session->set_userdata('fk_vendor_id', $vendor_id);
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('success_msgDetail', '<strong>Success!</strong> Weekly Traffic uploaded successfully!');
                } else {//when response is false
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Fail To add Weekly Traffic!');
                }//end if statment
                redirect('admin/reports/weekly_traffic');
            } else {//UPLOAD_ERR_NO_FILE(4); file was not uploaded.
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Kindly add valid record!');
            }//end nested if statments
        }
        $this->load->view('admin/reports/weeklytraffic', isset($data) ? $data : NULL);
    }//end fucntion weekly_traffic()

    /**
     *  This function is for Verification of Traffic
     */
    public function verify_traffic()
    {
        $vendor_id = $this->input->post('fk_vendor_id');//get VendorID from POST variable
        is_admin_loggedin('admin/reports/verifytraffic');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all vendor
        $data['countt'] = $this->Reports_model->get_traffic_count($vendor_id);// get traffic record count
        $data['repeated_dates_traffic'] = $this->Reports_model->repeated_records_traffic($vendor_id);//get repeated records
        $data['date_traffic'] = $this->Reports_model->date_daily_traffic_record($vendor_id);//get records
        $this->session->set_userdata('fk_vendor_id', $vendor_id);
        $this->load->view('admin/reports/verifytraffic', isset($data) ? $data : NULL);
    }//end fucntion verify_traffic()

    /**
     *  This function is for date of last entries for all vendor in main
     */
    public function traffic_dashboard()
    {
        is_admin_loggedin('admin/reports/traffic_dashboard');//get VendorID from POST variable
        $data['last_entries'] = $this->Reports_model->get_traffic_last_entries();//get date of last entries for all vendor in main
        $this->load->view('admin/reports/trafficdashboard', isset($data) ? $data : NULL);//load view and send data
    }//end fucntion traffic_dashboard()

    /**
     *  This function is for Moving Traffic record to main
     */
    public function move_to_main_traffic()
    {
        is_admin_loggedin('admin/reports/move_to_main_traffic');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get vendorID from Session
        //check $VendorID is not Empty
        if (!empty($vendor_id)) {
            //move record of vendor to main
            $this->Reports_model->move_to_main_traffic($vendor_id);
            $this->session->set_userdata('fk_vendor_id', $vendor_id);
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Moved Successfully!');
            $this->session->set_flashdata('delete_success_msg', '<strong>Success!</strong> Report Deleted Successfully!');
        } else {//when Vendor is not set
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Kindly Select Vendor!');
        }//end if statment
        redirect('admin/reports/verify_traffic');
    }//end fucntion move_to_main_traffic()

    /**
     *  This function is for Deleting Traffic record
     */
    public function delete_traffic()
    {
        is_admin_loggedin('admin/reports/delete_traffic');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get vendorID from Session
        //check $VendorID is not Empty
        if ($vendor_id != '') {
            //Delete record of vendor to main
            $delete_traffic = $this->Reports_model->delete_traffic($vendor_id);
            //check response of model
            if ($delete_traffic == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Record deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record deleted!');
            }//end if statment
        } else {//when vendorID is empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_traffic');
    }//end fucntion delete_traffic()

    /**
     *  This function is for Deleting Selected weekly Traffic record
     */
    public function delete_traffic_weekly()
    {
        is_admin_loggedin('admin/reports/delete_traffic_weekly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get vendorID from Session
        $daterange = $this->input->post('datefilter', true);//get date range from Post
        $daterangeIndex = explode(" - ", $daterange); // split  date range
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for Ending Date
        //check vendor_id,s_date && e_date is not empty
        if ($vendor_id != '' && $s_date != '' && $e_date != '') {
            //delete Weekly Record
            $Response = $this->Reports_model->delete_traffic_weekly($vendor_id, $s_date, $e_date);
            //check response
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//check vendor_id,s_date && e_date is empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_traffic');
    }//end function delete_traffic_weekly()

    /**
     *  This function is for Uploading weekly forecast record
     */
    function weekly_forecast()
    {
        is_admin_loggedin('admin/reports/weekly_forecast');
        $data['vendors'] = $this->Reports_model->get_all_vendors();
        $data['fk_vendor_id'] = $this->session->userdata('we_vendor_id', true);
        $data['status'] = FALSE;
        $this->load->helper('excel');
        $this->load->library('excel');
        $target_dir = "assets/uploads/";
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);
            ini_set("memory_limit", "8192M");
            $vendor_id = $this->input->post('fk_vendor_id', true);
            $daterange = $this->input->post('datefilter', true);
            $daterangeIndex = explode(" - ", $daterange);
            $startDate = date('Y-m-d', strtotime($daterangeIndex[0]));
            $endDate = date('Y-m-d', strtotime($daterangeIndex[1]));
            $this->session->set_userdata('fk_vendor_id', $vendor_id);
            if (!isset($vendor_id) && $vendor_id != NULL) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Vendor not Selected!');
            } elseif ($startDate == NULL && $endDate == NULL) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Starting and Ending Date must be Slected!');
            } elseif ($_FILES['data_files']['error'] == 4) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Detail Data File!');
            } elseif ($_FILES['data_files']['error'] != 4) {
                $FileNameDetail = $_FILES['data_files']['name'];
                $FileTypeDetail = 'Forecast';
                $MsgDetail = 'Kindly select appropriate detail file';
                $error_typeDetail = 'empty_filesDetail';
                $RedirectDetail = '';
                $fileCheckResponse = checkFileType($FileNameDetail, $FileTypeDetail, $MsgDetail, $RedirectDetail, $error_typeDetail);
                if ($fileCheckResponse == FALSE) {
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Detail report file must be valid!');
                    redirect('admin/reports/weekly_forecast');
                }


                $data_files = $_FILES["data_files"];

                $ResponseFilePath_data_files = UploadFiles($data_files, $target_dir);
                if ($ResponseFilePath_data_files != FALSE) {
                    $filedata = readExcel($ResponseFilePath_data_files);
                    $storeData = [];
                    foreach ($filedata as $key => $data) {
                        $db_data['fk_vendor_id'] = $vendor_id;
                        $db_data['asin'] = $data['A'];
                        $db_data['product_title'] = $data['B'];
                        $db_data['shippted_units'] = isset($data['F']) ? $data['F'] : '';
                        $db_data['available_inventory'] = isset($data['I']) ? $data['I'] : '';
                        $db_data['str_week1_mean_forecast'] = isset($data['Q']) ? $data['Q'] : '';
                        $db_data['str_week1_p70_forecast'] = isset($data['AQ']) ? $data['AQ'] : '';
                        $db_data['str_week1_p80_forecast'] = isset($data['BQ']) ? $data['BQ'] : '';
                        $db_data['str_week1_p90_forecast'] = isset($data['CQ']) ? $data['CQ'] : '';
                        $db_data['week1_mean_forecast'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_week1_mean_forecast'])));
                        $db_data['week1_p70_forecast'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_week1_p70_forecast'])));
                        $db_data['week1_p80_forecast'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_week1_p80_forecast'])));
                        $db_data['week1_p90_forecast'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_week1_p90_forecast'])));
                        $db_data['start_date'] = DateConversion($startDate);
                        $db_data['end_date'] = DateConversion($endDate);
                        array_push($storeData, $db_data);
                    }
                    //dd($storeData);
                    $Response = $this->Reports_model->insert_weekly_forecast($storeData);
                    if ($Response == true) {
                        $this->session->set_userdata('fk_vendor_id', $vendor_id);
                        $this->session->set_flashdata('vendor_id', $vendor_id);
                        $this->session->set_flashdata('success_msgDetail', '<strong>Success!</strong> Weekly forecast uploaded successfully!');
                    } else {
                        $this->session->set_flashdata('vendor_id', $vendor_id);
                        $this->session->set_flashdata('error', '<strong>Error!</strong> Fail To add Weekly forecast!');
                    }
                    redirect('admin/reports/weekly_forecast');
                } else {
                    $this->session->set_flashdata('error_msg_open', '<strong>Error!</strong> File not upload successfully!');
                    redirect('admin/reports/weekly_forecast');
                }
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('empty_filesSummary', '<strong>Error!</strong> Kindly add valid record!');
            }
        }
        $this->load->view('admin/reports/weeklyforecast', isset($data) ? $data : NULL);
    }

    /**
     * This function is for Verification weekly forecast record
     */
    public function verify_forecast()
    {
        $vendor_id = $this->input->post('fk_vendor_id');//Get VendorID from POST
        is_admin_loggedin('admin/reports/verifyforecast');//Check login Status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all active Vendors
        $data['countt'] = $this->Reports_model->get_forecast_count($vendor_id);//get forecast record count
        $data['repeated_dates_forecast'] = $this->Reports_model->repeated_records_forecast($vendor_id);//get forecast repeated record
        $data['date_forecast'] = $this->Reports_model->date_daily_forecast_record($vendor_id);//get forecast record by date
        $this->session->set_userdata('fk_vendor_id', $vendor_id);//set VendorID in session 
        $this->load->view('admin/reports/verifyforecast', isset($data) ? $data : NULL); // load View and send data
    }//end function verify_forecast()

    /**
     * This function is for date of Forecast Last Entry in main for all vendors
     */
    public function forecast_dashboard()
    {
        is_admin_loggedin('admin/reports/forecast_dashboard');//Check login Status
        $data['last_entries'] = $this->Reports_model->get_forecast_last_entries();//get last entry of records in main 
        $this->load->view('admin/reports/forecastdashboard', isset($data) ? $data : NULL);// load View and send data
    }//end function forecast_dashboard()

    /**
     * This function is for moving forecast Record to main
     */
    public function move_to_main_forecast()
    {
        is_admin_loggedin('admin/reports/move_to_main_forecast');//Check login Status
        $vendor_id = $this->session->userdata('fk_vendor_id');//Get VendorID from Session
        //check VendorID is not Empty
        if (!empty($vendor_id)) {
            //move forecast record from stage to main
            $this->Reports_model->move_to_main_forecast($vendor_id);
            $this->session->set_userdata('fk_vendor_id', $vendor_id);
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Moved Successfully!');
            $this->session->set_flashdata('delete_success_msg', '<strong>Success!</strong> Report Deleted Successfully!');
        } else {//when VendorID is Empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Kindly Select Vendor!');
        }//end if statment
        redirect('admin/reports/verify_forecast');
    }//end function move_to_main_forecast()

    /**
     * This function is for Deleting forecast Record
     */
    public function delete_forecast()
    {
        is_admin_loggedin('admin/reports/delete_forecast');//Check login Status
        $vendor_id = $this->session->userdata('fk_vendor_id');//Get VendorID from Session
        //check VendorID is not Empty
        if ($vendor_id != '') {
            //Delete forecast record from stage
            $delete_forecast = $this->Reports_model->delete_forecast($vendor_id);
            //check response of model
            if ($delete_forecast == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Record deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record deleted!');
            }//end if statment
        } else {//when VendorID is Empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_forecast');
        $this->load->view('admin/reports/verifyforecast', isset($data) ? $data : NULL);
    }//end fucntion delete_forecast()

    /**
     * This function is for Deleting selected Weekly forecast Record
     */
    public function delete_forecast_weekly()
    {
        is_admin_loggedin('admin/reports/delete_forecast_weekly');//Check login Status
        $vendor_id = $this->session->userdata('fk_vendor_id');//Get VendorID from Session
        $daterange = $this->input->post('datefilter', true);//get date range from Post
        $daterangeIndex = explode(" - ", $daterange);// split  date range
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for Ending Date
        //check VendorID,s_date and e_date is not Empty
        if ($vendor_id != '' && $s_date != '' && $e_date != '') {
            //Delete forecast record from stage by date
            $Response = $this->Reports_model->delete_forecast_weekly($vendor_id, $s_date, $e_date);
            //check response of model
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//when VendorID is Empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_forecast');
    }//end fucntion delete_forecast_weekly()

    /**
     * This function is for Uploading Promotion Summary Record
     */
    public function monthly_promotion()
    {
        is_admin_loggedin('admin/reports/monthly_promotion');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all Active Vendor
        $data['fk_vendor_id'] = $this->session->userdata('we_vendor_id', true);//get VendorID from SESSION variable
        $data['status'] = FALSE;
        //Check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set MAX Execution Time
            ini_set("memory_limit", "2048M");//Set Memory Limit
            $vendor_id = $this->input->post('fk_vendor_id', true);//Get VendorID from POST 
            $this->session->set_userdata('fk_vendor_id', $vendor_id);//set VendorID in SESSION
            if (!isset($vendor_id) || $vendor_id == NULL) {//check Vendor is Not Set or VendorID is NULL
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Vendor not Selected!');
            } elseif ($_FILES['summary_files']['error'] == 4) {// Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Summary File!');
            } elseif ($_FILES['coupons_files']['error'] == 4) {// Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Coupons File!');
            } elseif ($_FILES['summary_files']['error'] != 4 && $_FILES['coupons_files']['error'] != 4) {// Check UPLOAD_ERR_NO_FILE(4); file was uploaded.
                //set Summary File Uploading Rules
                $FileNameSummary = $_FILES['summary_files']['name'];
                $FileTypeSummary = 'promotion';
                $MsgSummary = 'Kindly select appropriate Summary file';
                $error_typeSummary = 'empty_files ';
                $RedirectSummary = '';
                $fileCheckResponse = checkFileType($FileNameSummary, $FileTypeSummary, $MsgSummary, $RedirectSummary, $error_typeSummary);
                if ($fileCheckResponse == FALSE) {
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Summary file must be valid!');
                    redirect('admin/reports/monthly_promotion');
                }//end if Statment
                //set Coupons File Uploading Rules
                $FileNameCoupons = $_FILES['coupons_files']['name'];
                $FileTypeCoupons = 'Coupons';
                $MsgCoupons = 'Kindly select appropriate Coupons file';
                $error_typeCoupons = 'empty_files ';
                $RedirectCoupons = '';
                $fileCheckResponse = checkFileType($FileNameCoupons, $FileTypeCoupons, $MsgCoupons, $RedirectCoupons, $error_typeCoupons);
                if ($fileCheckResponse == FALSE) {
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Coupons file must be valid!');
                    redirect('admin/reports/monthly_promotion');
                }//end if Statment

                // get promotion summarry File Data
                $file_Data = monthly_promotionSummarry_file();
                $storeData = [];
                foreach ($file_Data as $key2 => $data) {
                    $db_data['fk_vendor_id'] = $vendor_id;
                    $db_data['asin'] = $data['asin'];
                    $db_data['vendor_code'] = $data['vendor_code'];
                    $db_data['promotion_id'] = isset($data['paws_id']) ? $data['paws_id'] : '';
                    $db_data['promotion_name'] = isset($data['promotion_name']) ? $data['promotion_name'] : '';
                    $db_data['promotion_type'] = isset($data['promotion_type']) ? $data['promotion_type'] : '';
                    $db_data['product_name'] = isset($data['product_name']) ? $data['product_name'] : '';
                    $db_data['product_group'] = isset($data['product_group']) ? $data['product_group'] : '';
                    $db_data['str_net_unit_demand'] = isset($data['net_unit_demand']) ? $data['net_unit_demand'] : '';
                    $db_data['net_unit_demand'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_net_unit_demand'])));
                    $db_data['str_net_sales'] = isset($data['net_sales_pcogs']) ? $data['net_sales_pcogs'] : '';
                    $db_data['net_sales'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data['str_net_sales'])));
                    $db_data['start_date'] = DateConversion($data['promotion_start_date']);
                    $db_data['end_date'] = DateConversion($data['promotion_end_date']);
                    array_push($storeData, $db_data);
                }//end foreach
                //insert Summary Record using Model
                $promotionResponse = $this->Reports_model->insert_monthly_promotion($storeData);

                // get promotion Coupons File Data
                $file_Coupons = monthly_promotionCoupons_file();
                $storeCouponsData = [];
                foreach ($file_Coupons as $key2 => $data1) {
                    $db_data1['fk_vendor_id'] = $vendor_id;
                    $db_data1['product_title'] = isset($data1['product_title']) ? $data1['product_title'] : '';
                    $db_data1['cuopon_name'] = isset($data1['coupon_name']) ? $data1['coupon_name'] : '';
                    $db_data1['clips'] = isset($data1['clips']) ? $data1['clips'] : '';
                    $db_data1['redemptions'] = isset($data1['redemptions']) ? $data1['redemptions'] : '';
                    $db_data1['sales_lift'] = isset($data1['sales_lift']) ? $data1['sales_lift'] : '';
                    $db_data1['str_total_discount'] = isset($data1['total_discount']) ? $data1['total_discount'] : '';
                    $db_data1['str_budget_spend'] = isset($data1['budget_spent']) ? $data1['budget_spent'] : '';
                    $db_data1['str_budget_remaining'] = isset($data1['budget_remaining']) ? $data1['budget_remaining'] : '';
                    $db_data1['str_budget_used'] = isset($data1['budget_used']) ? $data1['budget_used'] : '';
                    $db_data1['str_total_budget'] = isset($data1['total_budget']) ? $data1['total_budget'] : '';
                    $db_data1['total_discount'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data1['str_total_discount'])));
                    $db_data1['budget_spend'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data1['str_budget_spend'])));
                    $db_data1['budget_remaining'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data1['str_budget_remaining'])));
                    $db_data1['budget_used'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data1['str_budget_used'])));
                    $db_data1['total_budget'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_data1['str_total_budget'])));
                    $db_data1['start_date'] = isset($data1['start_date']) ? DateConversion($data1['start_date']) : '';
                    $db_data1['end_date'] = isset($data1['end_date']) ? DateConversion($data1['end_date']) : '';
                    array_push($storeCouponsData, $db_data1);
                }//end foreach
                //insert Coupons Record using Model
                $couponsResponse = $this->Reports_model->insert_monthly_promotion_coupons($storeCouponsData);


                //check Response of Summary Promotion and Coupons Promotion From Model
                if ($promotionResponse == true && $couponsResponse == true) {
                    $this->session->set_userdata('fk_vendor_id', $vendor_id);
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('success_msgDetail', '<strong>Success!</strong> Monthly promotion uploaded successfully!');
                } else {//when Response is False
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Fail To add Monthly promotion!');
                }//end if Statment
                redirect('admin/reports/monthly_promotion');
            } else {//when file was not uploaded
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('empty_files', '<strong>Error!</strong> Kindly add valid record!');
            }//end Nested if Statments
        }
        $this->load->view('admin/reports/monthlypromotion', isset($data) ? $data : NULL);
    }//end function monthly_promotion()

    /**
     *  This function is for Verification of Promotion Summary Record
     */
    public function verify_promotion()
    {
        $vendor_id = $this->input->post('fk_vendor_id');//Get VendorID from POST
        is_admin_loggedin('admin/reports/verifypromotion');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get List of All Active Vendor

        $data['countt'] = $this->Reports_model->get_promotion_count($vendor_id);//Get Number of Record in Promotion Summary
        $data['repeated_dates_promotion'] = $this->Reports_model->repeated_records_promotion($vendor_id);//Get List of Repeated Record in Promotion Summary by date
        $data['date_promotion'] = $this->Reports_model->date_daily_promotion_record($vendor_id);//Get List of Record in Promotion Summary by date

        $data['coupons_countt'] = $this->Reports_model->get_promotion_coupons_count($vendor_id);//Get Number of Record in Promotion coupon
        $data['repeated_dates_coupons'] = $this->Reports_model->repeated_records_promotion_coupons($vendor_id);//Get List of Repeated Record in Promotion coupon by date
        $data['date_coupons'] = $this->Reports_model->date_daily_promotion_coupons_record($vendor_id);//Get List of Record in Promotion coupon by date

        $this->session->set_userdata('fk_vendor_id', $vendor_id);//set VendorID in Session
        $this->load->view('admin/reports/verifypromotion', isset($data) ? $data : NULL);//load Verification View and load data
    }//end fucntion verify_promotion()

    /**
     *  This function is for Last Entry Promotion Summary Record in Main Table
     */
    public function promotion_dashboard()
    {
        is_admin_loggedin('admin/reports/promotion_dashboard');//Check login status
        $data['last_entries'] = $this->Reports_model->get_promotion_last_entries();//get list of vendor with last entry date of Promotion Summary 
        $this->load->view('admin/reports/promotiondashboard', isset($data) ? $data : NULL);//load View and Send Data
    }//end fucntion promotion_dashboard()

    /**
     *  This function is for Last Entry Promotion Summary Record in Main Table
     */
    public function move_to_main_promotion()
    {
        is_admin_loggedin('admin/reports/move_to_main_promotion');//check Login Status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from SESSION
        //check VendorID is Not Empty
        if (!empty($vendor_id)) {
            $this->Reports_model->move_to_main_promotion($vendor_id);
            $this->session->set_userdata('fk_vendor_id', $vendor_id);
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Moved Successfully!');
            $this->session->set_flashdata('delete_success_msg', '<strong>Success!</strong> Report Deleted Successfully!');
        } else {//when Vendor is Empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Kindly Select Vendor!');
        }//end if statment
        redirect('admin/reports/verify_promotion');
    }//end function move_to_main_promotion()

    /**
     *  This function is for Deleting Promotion Summary Record from Stage Table
     */
    public function delete_promotion()
    {
        is_admin_loggedin('admin/reports/delete_promotion');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from SESSION
        //check Vendor is Not empty
        if ($vendor_id != '') {
            //Delete Promotion Summary Record for VendorID
            $delete_promotion = $this->Reports_model->delete_promotion($vendor_id);
            //check Response
            if ($delete_promotion == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Record deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record deleted!');
            }//end if statment
        } else {//when vendor is empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_promotion');
    }//end function Promotion Summary

    /**
     *  This function is for Deleting Selected Monthly Promotion Summary Record from Stage Table
     */
    public function delete_promotion_monthly()
    {
        is_admin_loggedin('admin/reports/delete_promotion_monthly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from SESSION
        $daterange = $this->input->post('datefilter', true);//get Date Range from POST 
        $daterangeIndex = explode(" - ", $daterange);//split Date Range
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for End Date
        //check if vendor_id , s_date and  e_date is Not Empty
        if ($vendor_id != '' && $s_date != '' && $e_date != '') {
            //delete promotion Summary record by date
            $Response = $this->Reports_model->delete_promotionSummary_monthly($vendor_id, $s_date, $e_date);
            //check response
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//when vendor_id , s_date Or  e_date is Empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_promotion');
    }//end fucntion delete_promotion_monthly()

    /**
     *  This function is for Deleting Selected Monthly Coupons Summary Record from Stage Table
     */
    public function delete_promotionCoupons_monthly()
    {
        is_admin_loggedin('admin/reports/delete_promotionCoupons_monthly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from SESSION
        $daterange = $this->input->post('datefilter2', true);//get Date Range from POST 
        $daterangeIndex = explode(" - ", $daterange);//split Date Range
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for End Date
        //check if vendor_id , s_date and  e_date is Not Empty
        if ($vendor_id != '' && $s_date != '' && $e_date != '') {
            //delete promotion Coupons record by date
            $Response = $this->Reports_model->delete_promotionCoupons_monthly($vendor_id, $s_date, $e_date);
            //check response
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//when vendor_id , s_date Or  e_date is Empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_promotion');
    }//end fucntion delete_promotionCoupons_monthly()


    /**
     * This Function is used for uploading Brand Store File
     */
    public function weekly_brandstore()
    {
        is_admin_loggedin('admin/reports/weekly_brandstore');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of Vendor
        $data['fk_vendor_id'] = $this->session->userdata('we_vendor_id', true);//get VendorID from SESSION
        $data['status'] = FALSE;
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0); // set MAX Execution Time
            ini_set("memory_limit", "2048M"); // set Memory Limit
            $vendor_id = $this->input->post('fk_vendor_id', true); // get VendorID from POST Variable
            $daterange = $this->input->post('datefilter', true); // get DateRange from POST Variable
            $daterangeIndex = explode(" - ", $daterange); // Split DateRange
            $startDate = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
            $endDate = date('Y-m-d', strtotime($daterangeIndex[1])); // convert String to time and set date formate "Y-m-d" for end Date
            $currentDate = date('Y-m-d');//current Date
            $this->session->set_userdata('fk_vendor_id', $vendor_id);// Set VendorID in Session Variable
            if (!isset($vendor_id) || $vendor_id == NULL) { //check VendorID is not set or NULL
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Vendor not Selected!');
            } elseif ($_FILES['page_files']['error'] == 4) {//  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Page File!');
            } elseif ($_FILES['source_files']['error'] == 4) {//  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Source File!');
            } elseif ($_FILES['date_files']['error'] == 4) {//  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Date File!');
            } elseif ($_FILES['page_files']['error'] != 4 && $_FILES['source_files']['error'] != 4 && $_FILES['date_files']['error'] != 4) {

                //set rule for Page File and Validate
                $FileNamePage = $_FILES['page_files']['name'];
                $FileTypePage = 'page';
                $MsgPage = 'Kindly select appropriate Page file';
                $error_typePage = 'empty_files_page';
                $RedirectPage = '';
                $fileCheckResponse_page = checkFileType($FileNamePage, $FileTypePage, $MsgPage, $RedirectPage, $error_typePage);

                //set rule for Source File and Validate
                $FileNameSource = $_FILES['source_files']['name'];
                $FileTypeSource = 'source';
                $MsgSource = 'Kindly select appropriate Source file';
                $error_typeSource = 'empty_files_source';
                $RedirectSource = '';
                $fileCheckResponse_source = checkFileType($FileNameSource, $FileTypeSource, $MsgSource, $RedirectSource, $error_typeSource);

                //set rule for Date File and Validate
                $FileNameDate = $_FILES['date_files']['name'];
                $FileTypeDate = 'date';
                $MsgDate = 'Kindly select appropriate Date file';
                $error_typeDate = 'empty_files_date';
                $RedirectDate = '';
                $fileCheckResponse_date = checkFileType($FileNameDate, $FileTypeDate, $MsgDate, $RedirectDate, $error_typeDate);

                //check vrification response of all files
                if ($fileCheckResponse_page == FALSE || $fileCheckResponse_source == FALSE || $fileCheckResponse_date == FALSE) {
                    redirect('admin/reports/weekly_brandstore');
                }//end if statment

                // get Brand Store Page File Data
                $page_file_Data = weekly_brandstorePage_file();
                $PageData = [];
                foreach ($page_file_Data as $key2 => $data) {
                    $db_page_data['fk_vendor_id'] = $vendor_id;
                    $db_page_data['page'] = isset($data['page']) ? $data['page'] : '';
                    $db_page_data['sales'] = isset($data['sales']) ? $data['sales'] : '';
                    $db_page_data['start_date'] = DateConversion($startDate);
                    $db_page_data['end_date'] = DateConversion($endDate);
                    array_push($PageData, $db_page_data);
                }//end foreach 

                // get Brand Store Source File Data
                $source_file_Data = weekly_brandstoreSource_file();
                $SourceData = [];
                foreach ($source_file_Data as $key2 => $data) {
                    $db_source_data['fk_vendor_id'] = $vendor_id;
                    $db_source_data['source'] = isset($data['source']) ? $data['source'] : '';
                    $db_source_data['sales'] = isset($data['sales']) ? $data['sales'] : '';
                    $db_source_data['start_date'] = DateConversion($startDate);
                    $db_source_data['end_date'] = DateConversion($endDate);
                    array_push($SourceData, $db_source_data);
                }//end foreach 

                // get Brand Store Date File Data
                $date_file_Data = weekly_brandstoreDate_file();
                $DateData = [];
                foreach ($date_file_Data as $key2 => $data) {
                    $db_date_data['fk_vendor_id'] = $vendor_id;
                    $db_date_data['brand_store_date'] = isset($data['date']) ? DateConversion($data['date']) : '';
                    $db_date_data['sales'] = isset($data['sales']) ? $data['sales'] : '';
                    $db_date_data['shipped_units'] = isset($data['units']) ? $data['units'] : '';
                    $db_date_data['visitors'] = isset($data['visitors']) ? $data['visitors'] : '';
                    $db_date_data['sales_orders'] = isset($data['sales_order']) ? $data['sales_order'] : '';
                    $db_date_data['units_orders'] = isset($data['units_order']) ? $data['units_order'] : '';
                    $db_date_data['views_visitors'] = isset($data['views_visitor']) ? $data['views_visitor'] : '';
                    $db_date_data['sales_visitors'] = isset($data['sales_visitor']) ? $data['sales_visitor'] : '';
                    $db_date_data['start_date'] = DateConversion($startDate);
                    $db_date_data['end_date'] = DateConversion($endDate);
                    array_push($DateData, $db_date_data);
                }//end foreach 

                //combine data
                $storeDate['page'] = $PageData;
                $storeDate['source'] = $SourceData;
                $storeDate['date'] = $DateData;

                //add Data to DB using Model
                $brandstoreResponse = $this->Reports_model->insert_weekly_brandstore($storeDate);

                //check response of model
                if ($brandstoreResponse == true) {
                    $this->session->set_userdata('fk_vendor_id', $vendor_id);
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('success_msgDetail', '<strong>Success!</strong> Brand Store Report uploaded successfully!');
                } else {//when response of model is false
                    $this->session->set_flashdata('vendor_id', $vendor_id);
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Fail To add Brand Report Store!');
                }//end if statment
                redirect('admin/reports/weekly_brandstore');
            } else {//when Invalid record
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('empty_files', '<strong>Error!</strong> Kindly add valid record!');
            }//end if statment
        }//end if statment
        $this->load->view('admin/reports/weeklybrandstore', isset($data) ? $data : NULL);
    }//end fucntion weekly_brandstore()

    /**
     * This Function is used to verify Brandstore reports
     */
    public function verify_brandstore()
    {
        $vendor_id = $this->input->post('fk_vendor_id');//get vendorID
        is_admin_loggedin('admin/reports/verifybrandstore');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all Active vendors

        $data['countt_bypage'] = $this->Reports_model->get_brandstore_bypage_count($vendor_id);//get Number of Record for vendor By Page
        $data['repeated_dates_brandstore_bypage'] = $this->Reports_model->repeated_records_brandstore_bypage($vendor_id);//get repeated Record for vendor By Page
        $data['date_brandstore_bypage'] = $this->Reports_model->date_daily_brandstore_bypage_record($vendor_id);//get Record for vendor By Page

        $data['countt_bysource'] = $this->Reports_model->get_brandstore_bysource_count($vendor_id);//get Number of Record for vendor By Source
        $data['repeated_dates_brandstore_bysource'] = $this->Reports_model->repeated_records_brandstore_bysource($vendor_id);//get repeated Record for vendor By Source
        $data['date_brandstore_bysource'] = $this->Reports_model->date_daily_brandstore_bysource_record($vendor_id);//get Record for vendor By Source

        $data['countt_bydate'] = $this->Reports_model->get_brandstore_bydate_count($vendor_id);//get Number of Record for vendor By Date
        $data['repeated_dates_brandstore_bydate'] = $this->Reports_model->repeated_records_brandstore_bydate($vendor_id);//get repeated Record for vendor By Date
        $data['date_brandstore_bydate'] = $this->Reports_model->date_daily_brandstore_bydate_record($vendor_id);//get Record for vendor By Date

        $this->session->set_userdata('fk_vendor_id', $vendor_id);//set VendorID to Session Variable
        $this->load->view('admin/reports/verifybrandstore', isset($data) ? $data : NULL);//load view and send data
    }//end function verify_brandstore()

    /**
     * This Function is Last entry to Main for Brandstore reports
     */
    public function brandstore_dashboard()
    {
        is_admin_loggedin('admin/reports/brandstore_dashboard');//check login status
        //get List of all Vendor to Main with Date
        $data['last_entries_bypage'] = $this->Reports_model->get_brandstore_bypage_last_entries(); //by page
        $data['last_entries_bysource'] = $this->Reports_model->get_brandstore_bysource_last_entries(); //by source
        $data['last_entries_bydate'] = $this->Reports_model->get_brandstore_bydate_last_entries(); //by date
        $this->load->view('admin/reports/brandstoredashboard', isset($data) ? $data : NULL); //load view and send data
    }//end function brandstore_dashboard()

    /**
     * This Function is for moving Brandstore reports to Main
     */
    public function move_to_main_brandstore()
    {
        is_admin_loggedin('admin/reports/move_to_main_brandstore');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        //check VendorID is Not empty
        if (!empty($vendor_id)) {
            $this->Reports_model->move_to_main_brandstore($vendor_id);
            $this->session->set_userdata('fk_vendor_id', $vendor_id);
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Moved Successfully!');
            $this->session->set_flashdata('delete_success_msg', '<strong>Success!</strong> Report Deleted Successfully!');
        } else {//when vendorID is Empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Kindly Select Vendor!');
        }//end if statment
        redirect('admin/reports/verify_brandstore');
    }//end function move_to_main_brandstore()

    /**
     * This Function is for Deleting Brandstore reports From Stage
     */
    public function delete_brandstore()
    {
        is_admin_loggedin('admin/reports/delete_brandstore');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        //check VendorID is Not empty
        if ($vendor_id != '') {
            //delete Vendor Brandstore record by calling Model
            $delete_brandstore = $this->Reports_model->delete_brandstore($vendor_id);
            //check response of model
            if ($delete_brandstore == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Record deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record deleted!');
            }//end if statment
        } else {//when vendorID is empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_brandstore');
    }//end function delete_brandstore()

    /**
     * This Function is for Deleting Brandstore Page reports by Selected Week From Stage
     */
    public function delete_brandstore_bypage_weekly()
    {
        is_admin_loggedin('admin/reports/delete_brandstore_bypage_weekly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        $daterange = $this->input->post('datefilter', true);// get DateRange from POST Variable
        $daterangeIndex = explode(" - ", $daterange);// Split DateRange
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for end Date
        //check vendorID , Start date AND End Date is not Empty
        if ($vendor_id != '' && $s_date != '' && $e_date != '') {
            //Delete Record by Week
            $Response = $this->Reports_model->delete_brandstore_bypage_weekly($vendor_id, $s_date, $e_date);
            //check response
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//when vendorID , Start date OR End Date is Empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_brandstore');
    }//end function delete_brandstore_bypage_weekly()

    /**
     * This Function is for Deleting Brandstore Source reports by Selected Week From Stage
     */
    public function delete_brandstore_bysource_weekly()
    {
        is_admin_loggedin('admin/reports/delete_brandstore_bysource_weekly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        $daterange = $this->input->post('datefilter1', true);// get DateRange from POST Variable
        $daterangeIndex = explode(" - ", $daterange);// Split DateRange
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for end Date
        //check vendorID , Start date AND End Date is not Empty  
        if ($vendor_id != '' && $s_date != '' && $e_date) {
            //Delete Record by Week
            $Response = $this->Reports_model->delete_brandstore_bysource_weekly($vendor_id, $s_date, $e_date);
            //check response
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//when vendorID , Start date OR End Date is Empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_brandstore');
    }//end function delete_brandstore_bysource_weekly()

    /**
     * This Function is for Deleting Brandstore Date reports by Selected Week From Stage
     */
    public function delete_brandstore_bydate_weekly()
    {
        is_admin_loggedin('admin/reports/delete_brandstore_bypage_weekly');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        $daterange = $this->input->post('datefilter2', true);// get DateRange from POST Variable
        $daterangeIndex = explode(" - ", $daterange);// Split DateRange
        $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
        $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for end Date
        //check vendorID , Start date AND End Date is not Empty  
        if ($vendor_id != '' && $s_date != '' && $e_date) {
            //Delete Record by Week
            $Response = $this->Reports_model->delete_brandstore_bydate_weekly($vendor_id, $s_date, $e_date);
            //check response
            if ($Response == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {//when vendorID , Start date OR End Date is Empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_brandstore');
    }//end function delete_brandstore_bydate_weekly()


    /**
     * This Function is used for uploading Exective Dashboard Date File
     */
    function executivedashboard_report()
    {
        is_admin_loggedin('admin/reports/executivedashboard_report');//check login status
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set MAX execution time
            ini_set("memory_limit", "2048M");//set Memory Limit
            //Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['date_file']['error'] == 4) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error', '<strong>Error!</strong> Please Select Detail File!');
            } else {

                $FileNameDetail = $_FILES['date_file']['name'];
                $FileTypeDetail = 'date';
                $MsgDetail = 'Kindly select appropriate date file';
                $error_typeDetail = 'empty_file_Date';
                $RedirectDetail = '';
                $fileCheckResponse_Detail = checkFileType($FileNameDetail, $FileTypeDetail, $MsgDetail, $RedirectDetail, $error_typeDetail);

                if ($fileCheckResponse_Detail == FALSE) {
                    redirect('admin/reports/verify_executivedashboard');
                }//end if statment

                // get Date File Data
                $dete_file_Data = executive_dashboard_file();
                $DateData = [];
                //Check Date Column is exist or not
                if (isset($dete_file_Data[0]['date'])) {
                    //get MAX date from the Date for end date
                    $end_date = MAX(array_column($dete_file_Data, 'date'));
                    foreach ($dete_file_Data as $key2 => $data) {
                        $db_date_data['start_date'] = DateConversion($data['date']);
                        $db_date_data['end_date'] = DateConversion($end_date);
                        $db_date_data['str_ordered_product_sales'] = isset($data['ordered_product_sales']) ? $data['ordered_product_sales'] : '';
                        $db_date_data['units_ordered'] = isset($data['units_ordered']) ? $data['units_ordered'] : '';
                        $db_date_data['total_order_items'] = isset($data['total_order_items']) ? $data['total_order_items'] : '';
                        $db_date_data['average_sales_per_order_item'] = isset($data['average_sales_per_order_item']) ? $data['average_sales_per_order_item'] : '';
                        $db_date_data['average_units_per_order_item'] = isset($data['average_units_per_order_item']) ? $data['average_units_per_order_item'] : '';
                        $db_date_data['average_selling_price'] = isset($data['average_selling_price']) ? $data['average_selling_price'] : '';
                        $db_date_data['sessions'] = isset($data['sessions']) ? $data['sessions'] : '';
                        $db_date_data['order_item_session_percentage'] = isset($data['order_item_session_percentage']) ? $data['order_item_session_percentage'] : '';
                        $db_date_data['average_offer_count'] = isset($data['average_percentagefer_count']) ? $data['average_percentagefer_count'] : '';
                        $db_date_data['ordered_product_sales'] = RemoveVariations(RemoveComma(RemoveDollarSign($db_date_data['str_ordered_product_sales'])));
                        array_push($DateData, $db_date_data);
                    }//end foreach
                    $executivedashboardResponse = $this->Reports_model->insert_executivedashboard($DateData);
                    if ($executivedashboardResponse == true) {
                        $this->session->set_flashdata('success_msgDetail', '<strong>Success!</strong> Executive Dashboard Report Uploaded successfully!');
                    } else {//when responce is false
                        $this->session->set_flashdata('error', '<strong>Error!</strong> Failed To add Executive Dashboard Report!');
                    }//end if statment
                } else {//when date column not exist
                    $this->session->set_flashdata('error', '<strong>Error!</strong> Kindly select appropriate date file!');
                }//end if statment
                redirect('admin/reports/verify_executivedashboard');
            }//end if 
        }//end if 
        $this->load->view('admin/reports/verifyexecutivedashboard', isset($data) ? $data : NULL);
    }//end function executivedashboard_report

    /**
     * This Function is used for verification of Reports
     */
    function verify_executivedashboard()
    {
        $vendor_id = $this->input->post('fk_vendor_id');//get VendorID from POST
        is_admin_loggedin('admin/reports/verify_executivedashboard');//check login statue
        $data['count'] = $this->Reports_model->get_executivedashboard_count();//get number of record
        $data['repeated_record'] = $this->Reports_model->repeated_executivedashboard_records();//get number of repeated record
        $data['record'] = $this->Reports_model->executivedashboard_records();//get list of record
        $data['years'] = $this->Reports_model->executivedashboard_records_years();//get year of record
        $data['last_entry_year'] = $this->Reports_model->executivedashboard_last_entry();//last entry year in main

        $this->load->view('admin/reports/verifyexecutivedashboard', isset($data) ? $data : NULL);
    }//end function verify_executivedashboard

    /**
     * This Function is used for Moving Reports to main
     */
    function move_to_main_executivedashboard()
    {
        is_admin_loggedin('admin/reports/move_to_main_executivedashboard');//check login status
        $move_to_main_executivedashboard = $this->Reports_model->move_to_main_executivedashboard();
        $this->session->set_flashdata('success_move_msg', '<strong>Success!</strong> Report Moved Successfully!');
        redirect('admin/reports/verify_executivedashboard');
    }//end function move_to_main_executivedashboard

    /**
     * This Function is used for Moving Reports to main
     */
    function delete_executivedashboard()
    {
        is_admin_loggedin('admin/reports/verify_executivedashboard');//check login status
        $year = $this->input->post('year', true); //get Year from POST
        $delete_executivedashboard = $this->Reports_model->delete_executivedashboard($year);
        if ($delete_executivedashboard == true) {
            $this->session->set_flashdata('success_year_delete_msg', '<strong>Success!</strong> Record deleted successfully!');
        } else {//when no record is deleted
            $this->session->set_flashdata('error_year_delete_msg', '<strong>Error!</strong> No record deleted!');
        }//end if statment
        redirect('admin/reports/verify_executivedashboard');
    }//end function delete_executivedashboard()

    /**
     * This fucntion is used to Display AND POST method for Daily Charge Back
     */
    public function daily_chargeback()
    {
        is_admin_loggedin('admin/reports/daily_chargeback');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all Active vendors
        $data['status'] = FALSE;
        //check Input Method is POST
        if ($this->input->method(TRUE) === 'POST') {
            ini_set('max_execution_time', 0);//set MAX execution time
            ini_set('memory_limit', '2048M');//set Memory Limit
            $fk_vendor_id = $this->input->post('fk_vendor_id', true);//get VendorID for POST
            $this->load->library('Excel');//load Excel Library
            $fetchData = chargeback();//get Chargeback data
            //check Error in Data
            if (isset($fetchData['error'])) {
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> ' . strip_tags($fetchData['error']));
            } elseif (!empty($fetchData)) { //when no Error in data
                //check data information
                if (!isset($fetchData[0]['issue_id']) && !isset($fetchData[0]['financial_charge']) && !isset($fetchData[0]['quantity']) && !isset($fetchData[0]['status']) && !isset($fetchData[0]['vendor_code']) && !isset($fetchData[0]['issue_type']) && !isset($fetchData[0]['creation_date']) && !isset($fetchData[0]['dispute_by'])) {
                    $this->session->set_flashdata('error_msg', '<strong>Error!</strong> File columns are not matched.');
                    $this->session->set_userdata('fk_vendor_id', $fk_vendor_id);
                    redirect('admin/reports/daily_chargeback');
                }//end if statment
                $StoreArray = [];
                foreach ($fetchData as $data) {
                    $datadb['fk_vendor_id'] = $fk_vendor_id;
                    $datadb['issue_id'] = $data['issue_id'];
                    $datadb['financial_charge'] = $data['financial_charge'];
                    $datadb['quantity'] = $data['quantity'];
                    $datadb['status'] = $data['status'];
                    $datadb['vendor_code'] = $data['vendor_code'];
                    $datadb['issue_type'] = $data['issue_type'];
                    $datadb['creation_date'] = DateConversion($data['creation_date']);
                    $datadb['dispute_by'] = DateConversion($data['dispute_by']);
                    $datadb['uploaded_date'] = CURRENT_DATE;
                    array_push($StoreArray, $datadb);
                }//end foreach statment
                //insert chargeback data
                $response = $this->Reports_model->insert_chargeback($StoreArray);
                //check response
                if ($response) {
                    $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                    $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report uploaded successfully!');
                } else {//when response is false
                    $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                    $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Report data is not inserted.');
                }//end if statment
            }//end if statment
            $this->session->set_userdata('fk_vendor_id', $fk_vendor_id);
            redirect('admin/reports/daily_chargeback');
        }// end if statment
        $this->load->view('admin/reports/dailychargeback', isset($data) ? $data : NULL);
    }//end function daily_chargeback()

    /**
     * This function is used to Display and Post Action Perform
     */
    public function verify_chargeback()
    {
        is_admin_loggedin('admin/reports/verify_chargeback');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from SESSION
        //check Input Method is POST
        if ($this->input->method(TRUE) === 'POST') {
            $vendor_idPost = $this->input->post('fk_vendor_id', true);
            $this->session->set_userdata('fk_vendor_id', $vendor_idPost);
            redirect('admin/reports/verify_chargeback');
        }//end if statment
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all active vendors
        $data['count'] = $this->Reports_model->get_all_count_chargeback($vendor_id);// get Numbers of records of Chargeback
        $data['repeated_dates'] = $this->Reports_model->repeated_date_chargeback($vendor_id); // get list Repeated of records of Chargeback
        $data['date_records'] = $this->Reports_model->dates_for_chargeback($vendor_id); // get list records of Chargeback
        $this->load->view('admin/reports/verifychargeback', isset($data) ? $data : NULL);// load view and send data
    }//end function verify_chargeback()

    /**
     * This function is for Last Entry Date of Chargeback Report for all vendors
     */
    public function chargeback_dashboard()
    {
        is_admin_loggedin('admin/reports/chargeback_dashboard');//check login status
        $data['last_entries'] = $this->Reports_model->get_chargeback_last_entries();//check list of all Vendor with LastEntry date in Chargeback
        $this->load->view('admin/reports/chargebackdashboard', isset($data) ? $data : NULL);//load View and send data
    }//end function chargeback_dashboard()

    /**
     * This function is for moving Chargeback Report to main
     */
    public function move_chargeback()
    {
        is_admin_loggedin('admin/reports/verify_chargeback');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        $this->Reports_model->move_to_main_chargeback($vendor_id);// move record to main
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Records moved to main successfully!');
        $this->session->set_flashdata('delete_msg', '<strong>Success!</strong> Records deleted successfully!');
        redirect('admin/reports/verify_chargeback ');
    }//end function move_chargeback()

    /**
     * This function is for Deleting Chargeback Report
     */
    public function delete_chargebacks()
    {
        is_admin_loggedin('admin/reports/verify_chargeback');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        $this->Reports_model->delete_chargeback($vendor_id);// Delete record from stage
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Records deleted successfully!');
        redirect('admin/reports/verify_chargeback');
    }//end function delete_chargebacks()

    /**
     * This function is used to Display and PerForm POST action Function for AMS Report
     */
    public function ams_report()
    {
        is_admin_loggedin('admin/reports/amsreport');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all active vendors
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        $data['status'] = FALSE;
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('max_execution_time', 0);//set MAX Execution time
            ini_set('memory_limit', '2048M');//set Memory Limit
            $this->load->library('Excel');//load excel library
            $vendor_id_post = $this->input->post('fk_vendor_id', true);//get VendorID from POST variable
            $daterange = $this->input->post('datefilter', true);//get DataRange from POST variable
            $daterangeIndex = explode(" - ", $daterange);//split DataRange
            $start_date2 = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
            $end_date2 = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for Ending Date
            $InsertDataArray = [];
            //  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['campaign']['error'] == 4 || $_FILES['brands']['error'] == 4 || $_FILES['product']['error'] == 4) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Campaign , Brand and Product files are missing.');
            }//end if statment
            // check Campaign file
            if ($_FILES['campaign']['error'] != 4) {
                $FileName = $_FILES['campaign']['name'];
                $FileType = 'Campaigns';
                $Msg = 'Kindly select appropriate campaign file';
                $error_type = 'empty_filesCampaign';
                $Redirect = '';
                // verify its campaign file.
                $fileCampaignCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                if ($fileCampaignCheckResponse != false) {
                    // get campaign File Data
                    $campaigns = campaigns();
                    if (isset($campaigns['error'])) {
                        $this->session->set_flashdata('vendor_id', $vendor_id);
                        $this->session->set_flashdata('c_error_msg', '<strong>Error!</strong> Campaign file' . $campaigns['error']);
                        redirect('admin/reports/ams_report');
                    } else if (!empty($campaigns)) {
                        $StoreCampaignsArray = [];
                        foreach ($campaigns as $data) {
                            $dc_data['fk_vendor_id'] = $vendor_id_post;
                            $dc_data['campaigns'] = $data['campaigns'];
                            $dc_data['type'] = $data['type'];
                            $dc_data['status'] = $data['status'];
                            $dc_data['state'] = $data['state'];
                            $dc_data['portfolio'] = $data['portfolio'];
                            $dc_data['targeting'] = $data['targeting'];
                            $dc_data['impressions'] = $data['impressions'];
                            $dc_data['clicks'] = $data['clicks'];
                            $dc_data['ctr'] = $data['ctr()'];
                            $dc_data['cpc'] = $data['cpc(usd)'];
                            $dc_data['budget'] = $data['budget(usd)'];
                            $dc_data['spend'] = $data['spend(usd)'];
                            $dc_data['acos'] = $data['acos()'];
                            $dc_data['sales'] = $data['sales(usd)'];
                            $dc_data['campaign_bid'] = $data['campaign_bidding_strategy'];
                            $dc_data['c_start_date'] = $data['start_date'];
                            $dc_data['c_end_date'] = $data['end_date'];
                            $dc_data['sales_ntb_per'] = $data['_percentage_sales_ntb'];
                            $dc_data['orders'] = $data['orders'];
                            $dc_data['ntb_orders'] = $data['ntb_orders'];
                            $dc_data['orders_ntb_per'] = $data['_percentage_orders_ntb'];
                            $dc_data['ntb_sales'] = $data['ntb_sales'];
                            $dc_data['start_date'] = DateConversion($start_date2);
                            $dc_data['end_date'] = DateConversion($end_date2);
                            array_push($StoreCampaignsArray, $dc_data);
                        }//end foreach 
                        $InsertDataArray['CampaignData'] = $StoreCampaignsArray;
                    }//end if statment
                }//end if statment
            }//end if statment
            // check brands file
            if ($_FILES['brands']['error'] != 4) {
                $FileName = $_FILES['brands']['name'];
                $FileType = 'Brands';
                $Msg = 'Kindly select appropriate brand file';
                $error_type = 'empty_filesBrand';
                $Redirect = '';
                // verify its campaign file.
                $fileBrandCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                if ($fileBrandCheckResponse != false) {
                    // get brands File Data
                    $brands = brands();
                    if (isset($brands['error'])) {
                        $this->session->set_flashdata('vendor_id', $vendor_id);
                        $this->session->set_flashdata('b_error_msg', '<strong>Error!</strong> Brand file ' . $brands['error']);
                        redirect('admin/reports/ams_report');
                    } else if (!empty($brands)) {
                        $StoreBrandsArray = [];
                        foreach ($brands as $data) {
                            $db_data['fk_vendor_id'] = $vendor_id_post;
                            $db_data['campaign_name'] = $data['campaign_name'];
                            $db_data['portfolio_name'] = $data['portfolio_name'];
                            $db_data['match_type'] = $data['match_type'];
                            $db_data['targeting'] = $data['targeting'];
                            $db_data['currency'] = $data['currency'];
                            $db_data['impressions'] = $data['impressions'];
                            $db_data['clicks'] = $data['clicks'];
                            $db_data['ctr'] = $data['clickthru_rate_(ctr)'];
                            $db_data['cpc'] = $data['cost_per_click_(cpc)'];
                            $db_data['spend'] = $data['spend'];
                            $db_data['acos'] = $data['total_advertising_cost_percentage_sales_(acos)_'];
                            $db_data['roas'] = $data['total_return_on_advertising_spend_(roas)'];
                            $db_data['total_sales'] = $data['14_day_total_sales_'];
                            $db_data['total_orders'] = $data['14_day_total_orders_(#)'];
                            $db_data['total_units'] = $data['14_day_total_units_(#)'];
                            $db_data['conversion_rate'] = $data['14_day_conversion_rate'];
                            $db_data['brand_total_detail_page_views'] = $data['14_day_brand_total_detail_page_views_(#)'];
                            $db_data['new_to_brand_orders'] = $data['14_day_newtobrand_orders_(#)'];
                            $db_data['orders_new_to_brand'] = $data['14_day_percentage_orders_newtobrand'];
                            $db_data['new_to_brand_sales'] = $data['14_day_newtobrand_sales'];
                            $db_data['sales_new_to_brand'] = $data['14_day_percentage_sales_newtobrand'];
                            $db_data['new_to_brand_units'] = $data['14_day_newtobrand_units_(#)'];
                            $db_data['units_new_to_brand'] = $data['14_day_percentage_units_newtobrand'];
                            $db_data['new_to_brand_order_rate'] = $data['14_day_newtobrand_order_rate'];
                            $db_data['start_date'] = DateConversion($start_date2);
                            $db_data['end_date'] = DateConversion($end_date2);
                            array_push($StoreBrandsArray, $db_data);
                        }//end foreach 
                        $InsertDataArray['brandData'] = $StoreBrandsArray;
                    }//end if statment
                }//end if statment
            }//end if statment
            if ($_FILES['product']['error'] != 4) {
                $FileName = $_FILES['product']['name'];
                $FileType = 'Products';
                $Msg = 'Kindly select appropriate product file';
                $error_type = 'empty_filesProduct';
                $Redirect = '';
                // verify its Product file.
                $fileProductCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                if ($fileProductCheckResponse != false) {
                    // get products File Data
                    $products = products();
                    if (isset($products['error'])) {
                        $this->session->set_flashdata('p_error_msg', '<strong>Error!</strong> Product file ' . $products['error']);
                        redirect('admin/reports/ams_report');
                    } else if (!empty($products)) {
                        $StoreProductsArray = [];
                        foreach ($products as $data) {
                            $dp_data['fk_vendor_id'] = $vendor_id_post;
                            $dp_data['campaign_name'] = $data['campaign_name'];
                            $dp_data['advertised_asin'] = $data['advertised_asin'];
                            $dp_data['portfolio_name'] = $data['portfolio_name'];
                            $dp_data['currency'] = $data['currency'];
                            $dp_data['impressions'] = $data['impressions'];
                            $dp_data['clicks'] = $data['clicks'];
                            $dp_data['ctr'] = $data['clickthru_rate_(ctr)'];
                            $dp_data['cpc'] = $data['cost_per_click_(cpc)'];
                            $dp_data['spend'] = $data['spend'];
                            $dp_data['total_sales'] = $data['14_day_total_sales_'];
                            $dp_data['acos'] = $data['total_advertising_cost_percentage_sales_(acos)_'];
                            $dp_data['roas'] = $data['total_return_on_advertising_spend_(roas)'];
                            $dp_data['total_orders'] = $data['14_day_total_orders_(#)'];
                            $dp_data['total_units'] = $data['14_day_total_units_(#)'];
                            $dp_data['conversion_rate'] = $data['14_day_conversion_rate'];
                            $dp_data['start_date'] = DateConversion($start_date2);
                            $dp_data['end_date'] = DateConversion($end_date2);
                            array_push($StoreProductsArray, $dp_data);
                        }//end foreach 
                        $InsertDataArray['ProductsData'] = $StoreProductsArray;
                    }//end if statment
                }//end if statment
            }//end if statment
            if (!isset($InsertDataArray['CampaignData']) && !isset($InsertDataArray['ProductsData']) && !isset($InsertDataArray['brandData'])) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Data is missing.');
                redirect('admin/reports/ams_report');
            } else if (!isset($InsertDataArray['CampaignData'])) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong>Campaign Data is missing.');
                redirect('admin/reports/ams_report');
            }//end if statment
            // insert Data into DB
            $this->Reports_model->insert_amsData($InsertDataArray);
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> All report uploaded successfully!');
            $this->session->set_userdata('fk_vendor_id', $vendor_id_post);
            redirect('admin/reports/ams_report');
        }//end if statment
        $this->load->view('admin/reports/amsreport', isset($data) ? $data : NULL);
    }//end if statment

    /**
     * This function is used for Verification of AMS Report
     */
    public function verify_ams()
    {
        is_admin_loggedin('admin/reports/verify_ams');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all active vendors
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $vendor_id = $this->input->post('fk_vendor_id');//get VendorID from Post
            $data['count_ams'] = $this->Reports_model->get_all_count_amscampaign($vendor_id);
            $data['date_recordsc'] = $this->Reports_model->dates_for_ams_campaigns($vendor_id);
            $data['repeated_dates_recordsc'] = $this->Reports_model->repeated_dates_recordsc($vendor_id);
            $data['count_br'] = $this->Reports_model->get_all_count_amsbrand($vendor_id);
            $data['date_recordsb'] = $this->Reports_model->dates_for_ams_brands($vendor_id);
            $data['repeated_dates_recordsb'] = $this->Reports_model->repeated_dates_recordsb($vendor_id);
            $data['count_p'] = $this->Reports_model->get_all_count_amsproduct($vendor_id);
            $data['date_recordsp'] = $this->Reports_model->dates_for_ams_products($vendor_id);
            $data['repeated_dates_recordsp'] = $this->Reports_model->repeated_dates_recordsp($vendor_id);
            $this->session->set_userdata('fk_vendor_id', $vendor_id);
        }//end if statment
        $this->load->view('admin/reports/verifyams', isset($data) ? $data : NULL);
    }//end function verify_ams()

    /**
     * This function is used for Moving AMS Report to main
     */
    public function move_ams()
    {
        is_admin_loggedin('admin/reports/verify_ams');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from SESSION
        //check VendorID is not empty
        if (!empty($vendor_id)) {
            $this->Reports_model->move_to_main_ams($vendor_id);
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Moved Successfully!');
            $this->session->set_flashdata('delete_success_msg', '<strong>Success!</strong> Report Deleted Successfully!');
        } else {//when VendorID is Empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Kindly Select Vendor!');
        }//end if statment
        redirect('admin/reports/verify_ams');
    }//end function move_ams()

    /**
     * This function is used for Update AMS Report to main
     */
    public function update_ams()
    {
        is_admin_loggedin('admin/reports/verify_ams');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from SESSION
        //check VendorID is not empty
        if (!empty($vendor_id)) {
            $this->Reports_model->update_ams_data($vendor_id);
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Moved Successfully!');
            $this->session->set_flashdata('delete_success_msg', '<strong>Success!</strong> Report Deleted Successfully!');
        } else {//when VendorID is Empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Kindly Select Vendor!');
        }//end if statment
        redirect('admin/reports/verify_ams');
    }//end function update_ams()

    /**
     * This function is used for Last Entry Date of AMS Report to main
     */
    public function ams_dashboard()
    {
        is_admin_loggedin('admin/reports/ams_dashboard');//check login status
        $data['last_entries_campaigns'] = $this->Reports_model->get_ams_campaigns_last_entries();
        $data['last_entries_brands'] = $this->Reports_model->get_ams_brands_last_entries();
        $data['last_entries_products'] = $this->Reports_model->get_ams_products_last_entries();
        $this->load->view('admin/reports/amsdashboard', isset($data) ? $data : NULL);
    }//end function ams_dashboard()

    /**
     * This function is used for Deleting AMS Report from Stage
     */
    public function delete_ams()
    {
        is_admin_loggedin('admin/reports/verify_ams');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');
        $this->Reports_model->deleteAms($vendor_id);
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
        redirect('admin/reports/verify_ams');
    }//end function delete_ams()

    /**
     * This function is used for Adding POWER BI Roles
     */
    public function powerbi_roles()
    {
        is_admin_loggedin('admin/reports/powerbi_roles');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all active Vendors
        //check REQUEST_METHOD is Post
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $vendorId = $this->input->post('fk_vendor_id', true);
            $firstname = $this->input->post('fname', true);
            $lastname = $this->input->post('lname', true);
            $email = $this->input->post('email', true);
            $is_manager = $this->input->post('is_manager', true);
            $db_data['fk_vendor_id'] = $vendorId;
            $db_data['first_name'] = $firstname;
            $db_data['last_name'] = $lastname;
            $db_data['email'] = $email;
            $db_data['is_manager'] = !empty($is_manager) ? '1' : '0';
            $response = $this->Reports_model->insert_powerbi_roles($db_data);
            if ($response == true) {
                $this->session->set_flashdata('vendor_id', $vendorId);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Role Assigned Successfully!');
            } else {
                $this->session->set_flashdata('vendor_id', $vendorId);
                $this->session->set_flashdata('error_msg', '<strong>Success!</strong> Role Already Assigned !');
            }//end if statment
            redirect('admin/reports/powerbi_roles');
        }//end if statment
        $this->load->view('admin/reports/powerbiroles', isset($data) ? $data : NULL);
    }//end function powerbi_roles()

    /**
     * This function is used for Uploading Daily Inventory Report to Stage
     */
    public function daily_inventory()
    {
        is_admin_loggedin('admin/reports/dailyinventory');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of all active Vendors
        $vendor_id = $this->session->userdata('fk_vendor_id');
        $data['status'] = FALSE;
        //check REQUEST_METHOD is Post
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('memory_limit', '2048M');
            ini_set('max_execution_time', 0);
            $vendor_idPost = $this->input->post('fk_vendor_id', true);
            $date = $this->input->post('date', true);
            $this->load->library('Excel');
            //  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4) {
                $FileName = $_FILES['data_files']['name'];
                $FileType = 'Inventory';
                $Msg = 'Kindly select appropriate Inventory file';
                $Redirect = 'admin/reports/daily_inventory';
                $error_type = 'empty_filesdaily_inventory';
                // verify its Inventory file.
                $fileCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);
                if ($fileCheckResponse != false) {
                    $file_Data = dataReadFromExcelFile();
                    if (isset($file_Data['error'])) {
                        $this->session->set_flashdata('vendor_id', $vendor_idPost);
                        $this->session->set_flashdata('error_msg', '<strong>Error!</strong> ' . strip_tags($file_Data['error']));
                    } else {
                        $StoreData = [];
                        foreach ($file_Data as $key2 => $data) {
                            $db_data['fk_vendor_id'] = $vendor_idPost;
                            $db_data['asin'] = $data['asin'];
                            $db_data['product_title'] = $data['product_title'];
                            $db_data['net_recieved'] = $data['net_received'];
                            $db_data['net_revieved_units'] = $data['net_received_units'];
                            $db_data['sell_through_rate'] = $data['sellthrough_rate'];
                            $db_data['open_purchase_order_quantity'] = $data['open_purchase_order_quantity'];
                            $db_data['str_sellable_on_hand_inventory'] = $data['sellable_on_hand_inventory'];
                            $db_data['sellable_on_hand_inventory_trailing_30_day_average'] = isset($data['sellable_on_hand_inventory_trailing_30day_average']) ? $data['sellable_on_hand_inventory_trailing_30day_average'] : '';
                            $db_data['str_sellable_on_hand_units'] = $data['sellable_on_hand_units'];
                            $db_data['unsellable_on_hand_inventory'] = isset($data['unsellable_on_hand_inventory']) ? $data['unsellable_on_hand_inventory'] : '';
                            $db_data['unsellable_on_hand_inventory_trailing_30_day_average'] = isset($data['unsellable_on_hand_inventory_trailing_30day_average']) ? $data['unsellable_on_hand_inventory_trailing_30day_average'] : '';
                            $db_data['unsellable_on_hand_units'] = isset($data['unsellable_on_hand_units']) ? $data['unsellable_on_hand_units'] : '';
                            $db_data['aged_90_days_sellable_inventory'] = $data['aged_90+_days_sellable_inventory'];
                            $db_data['aged_90+_days_sellable_inventory_trailing_30_day_average'] = $data['aged_90+_days_sellable_inventory_trailing_30day_average'];
                            $db_data['aged_90_days_sellable_units'] = $data['aged_90+_days_sellable_units'];
                            $db_data['replenishment_category'] = $data['replenishment_category'];
                            $db_data['sellable_on_hand_inventory'] = RemoveComma(RemoveDollarSign($data['sellable_on_hand_inventory']));
                            $db_data['sellable_on_hand_units'] = RemoveComma(RemoveDollarSign($data['sellable_on_hand_units']));
                            $db_data['category'] = isset($data['category']) ? $data['category'] : '';
                            $db_data['subcategory'] = isset($data['subcategory']) ? $data['subcategory'] : '';
                            $db_data['rec_date'] = DateConversion($date);
                            array_push($StoreData, $db_data);
                        }//end foreach 
                        $this->Reports_model->insert_dinventory($StoreData, $vendor_idPost, $date);
                        $this->session->set_userdata('fk_vendor_id', $vendor_idPost);
                        $this->session->set_flashdata('vendor_id', $vendor_idPost);
                        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report uploaded successfully!');
                        unset($StoreData);
                    }//end if statment
                }//end if statment
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_idPost);
                $this->session->set_flashdata('empty_filesDetail', '<strong>Error!</strong> Kindly upload detail file!');
            }//end if statment
            redirect('admin/reports/daily_inventory');
        }//end if statment
        $this->load->view('admin/reports/dailyinventory', isset($data) ? $data : NULL);
    }//end function daily_inventory()

    /**
     * This function is used for Uploading Weekly Inventory Report to Stage
     */
    public function weekly_inventory()
    {
        is_admin_loggedin('admin/reports/weeklyinventory');
        $data['vendors'] = $this->Reports_model->get_all_vendors();
        $vendor_id = $this->session->userdata('fk_vendor_id');
        $this->load->library('Excel');
        $data['status'] = FALSE;
        //Check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            ini_set('memory_limit', '2048M');
            ini_set('max_execution_time', 0);
            $vendor_idPost = $this->input->post('fk_vendor_id', true);
            $daterange = $this->input->post('datefilter', true);//Get DateRange from POST
            $daterangeIndex = explode(" - ", $daterange);//split date
            $start_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
            $end_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for Ending Date
            //  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4) {
                $FileName = $_FILES['data_files']['name'];
                $FileType = '';
                $Msg = 'Kindly select appropriate Inventory file';
                $Redirect = 'admin/reports/weekly_inventory';
                $error_type = 'empty_filesweekly_inventory';
                if (1) {
                    $file_Data = dataReadFromExcelFile();
                    $this->load->library('Excel');
                    $db_data = [];
                    if (isset($file_Data['error'])) {
                        $this->session->set_flashdata('vendor_id', $vendor_id);
                        $this->session->set_flashdata('error_msg', '<strong>Error!</strong> ' . strip_tags($file_Data['error']));
                    } else {
                        $StoreData = [];
                        foreach ($file_Data as $key2 => $data) {
                            $db_data['fk_vendor_id'] = $vendor_idPost;
                            $db_data['asin'] = $data['asin'];
                            $db_data['product_title'] = $data['product_title'];
                            $db_data['net_recieved'] = $data['net_received'];
                            $db_data['net_revieved_units'] = $data['net_received_units'];
                            $db_data['sell_through_rate'] = $data['sellthrough_rate'];
                            $db_data['open_purchase_order_quantity'] = $data['open_purchase_order_quantity'];
                            $db_data['str_sellable_on_hand_inventory'] = $data['sellable_on_hand_inventory'];
                            $db_data['sellable_on_hand_inventory_trailing_30_day_average'] = isset($data['sellable_on_hand_inventory_trailing_30day_average']) ? $data['sellable_on_hand_inventory_trailing_30day_average'] : '';
                            $db_data['str_sellable_on_hand_units'] = $data['sellable_on_hand_units'];
                            $db_data['unsellable_on_hand_inventory'] = isset($data['unsellable_on_hand_inventory']) ? $data['unsellable_on_hand_inventory'] : '';
                            $db_data['unsellable_on_hand_inventory_trailing_30_day_average'] = isset($data['unsellable_on_hand_inventory_trailing_30day_average']) ? $data['unsellable_on_hand_inventory_trailing_30day_average'] : '';
                            $db_data['unsellable_on_hand_units'] = isset($data['unsellable_on_hand_units']) ? $data['unsellable_on_hand_units'] : '';
                            $db_data['aged_90_days_sellable_inventory'] = $data['aged_90+_days_sellable_inventory'];
                            $db_data['aged_90+_days_sellable_inventory_trailing_30_day_average'] = $data['aged_90+_days_sellable_inventory_trailing_30day_average'];
                            $db_data['aged_90_days_sellable_units'] = $data['aged_90+_days_sellable_units'];
                            $db_data['replenishment_category'] = $data['replenishment_category'];
                            $db_data['sellable_on_hand_inventory'] = RemoveComma(RemoveDollarSign($data['sellable_on_hand_inventory']));
                            $db_data['sellable_on_hand_units'] = RemoveComma(RemoveDollarSign($data['sellable_on_hand_units']));
                            $db_data['category'] = isset($data['category']) ? $data['category'] : '';
                            $db_data['subcategory'] = isset($data['subcategory']) ? $data['subcategory'] : '';
                            $db_data['start_date'] = DateConversion($start_date);
                            $db_data['end_date'] = DateConversion($end_date);
                            array_push($StoreData, $db_data);
                        }//end foreach 
                        $this->Reports_model->insert_winventory($StoreData, $vendor_idPost, $start_date, $end_date);
                        $this->session->set_userdata('fk_vendor_id', $this->input->post('fk_vendor_id'));

                        $this->session->set_flashdata('vendor_id', $vendor_idPost);
                        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Uploaded Successfully!');
                        unset($storeData);
                    }//end if statment
                }//end if statment
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_idPost);
                $this->session->set_flashdata('empty_files', '<strong>Error!</strong> Kindly upload inventory file!');
            }//end if statment
            redirect('admin/reports/weekly_inventory');
        }//end if statment
        $this->load->view('admin/reports/weeklyinventory', isset($data) ? $data : NULL);
    }//end function weekly_inventory()

    /**
     * This function is used for Uploading Monthly Inventory Report to Stage
     */
    public function monthly_inventory()
    {
        is_admin_loggedin('admin/reports/monthly_inventory');//check login status
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of active vendors
        $vendor_id = $this->session->userdata('fk_vendor_id');//get list of 
        $data['status'] = FALSE;
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('Excel');//load Excel Library
            ini_set('memory_limit', '2048M');//Set Memory Limit
            ini_set('max_execution_time', 0);//Set execution time
            $vendor_idPost = $this->input->post('fk_vendor_id', true);//get VendorID from POST
            $daterange = $this->input->post('datefilter', true);//get DataRange From POST
            $daterangeIndex = explode(" - ", $daterange); //Split Data
            $start_date = date('Y-m-d', strtotime($daterangeIndex[0]));// convert String to time and set date formate "Y-m-d" for Starting Date
            $end_date = date('Y-m-d', strtotime($daterangeIndex[1]));// convert String to time and set date formate "Y-m-d" for Ending Date
            //  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4) {
                $FileName = $_FILES['data_files']['name'];
                $FileType = 'Inventory';
                $Msg = 'Kindly select appropriate Inventory file';
                $Redirect = 'admin/reports/monthly_inventory';
                $error_type = 'empty_filesDetail';
                if (1) {
                    $file_Data = dataReadFromExcelFile();
                    if (isset($file_Data['error'])) {

                        $this->session->set_flashdata('vendor_id', $vendor_idPost);
                        $this->session->set_flashdata('error_msg', '<strong>Error!</strong> ' . strip_tags($file_Data['error']));
                    } else {
                        $storeData = [];
                        foreach ($file_Data as $key2 => $data) {
                            $db_data['fk_vendor_id'] = $vendor_idPost;
                            $db_data['asin'] = $data['asin'];
                            $db_data['product_title'] = $data['product_title'];
                            $db_data['net_recieved'] = $data['net_received'];
                            $db_data['net_revieved_units'] = $data['net_received_units'];
                            $db_data['sell_through_rate'] = $data['sellthrough_rate'];
                            $db_data['open_purchase_order_quantity'] = $data['open_purchase_order_quantity'];
                            $db_data['str_sellable_on_hand_inventory'] = $data['sellable_on_hand_inventory'];
                            $db_data['sellable_on_hand_inventory_trailing_30_day_average'] = isset($data['sellable_on_hand_inventory_trailing_30day_average']) ? $data['sellable_on_hand_inventory_trailing_30day_average'] : '';
                            $db_data['str_sellable_on_hand_units'] = $data['sellable_on_hand_units'];
                            $db_data['unsellable_on_hand_inventory'] = isset($data['unsellable_on_hand_inventory']) ? $data['unsellable_on_hand_inventory'] : '';
                            $db_data['unsellable_on_hand_inventory_trailing_30_day_average'] = isset($data['unsellable_on_hand_inventory_trailing_30day_average']) ? $data['unsellable_on_hand_inventory_trailing_30day_average'] : '';
                            $db_data['unsellable_on_hand_units'] = isset($data['unsellable_on_hand_units']) ? $data['unsellable_on_hand_units'] : '';
                            $db_data['aged_90_days_sellable_inventory'] = $data['aged_90+_days_sellable_inventory'];
                            $db_data['aged_90+_days_sellable_inventory_trailing_30_day_average'] = $data['aged_90+_days_sellable_inventory_trailing_30day_average'];
                            $db_data['aged_90_days_sellable_units'] = $data['aged_90+_days_sellable_units'];
                            $db_data['replenishment_category'] = $data['replenishment_category'];
                            $db_data['sellable_on_hand_inventory'] = RemoveComma(RemoveDollarSign($data['sellable_on_hand_inventory']));
                            $db_data['sellable_on_hand_units'] = RemoveComma(RemoveDollarSign($data['sellable_on_hand_units']));
                            $db_data['category'] = isset($data['category']) ? $data['category'] : '';
                            $db_data['subcategory'] = isset($data['subcategory']) ? $data['subcategory'] : '';
                            $db_data['start_date'] = $start_date;
                            $db_data['end_date'] = $end_date;
                            array_push($storeData, $db_data);
                        }//end foreach loop
                        $this->Reports_model->insert_minventory($storeData, $vendor_idPost, $start_date, $end_date);
                        $this->session->set_userdata('fk_vendor_id', $vendor_idPost);

                        $this->session->set_flashdata('vendor_id', $vendor_idPost);
                        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Uploaded Successfully!');
                        unset($storeData);
                    }//end if statment
                }//end if statment
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_idPost);
                $this->session->set_flashdata('empty_files', '<strong>Error!</strong> Kindly upload inventory file!');
            }//end if statment
            redirect('admin/reports/monthly_inventory');
        }//end if statment
        $this->load->view('admin/reports/monthlyinventory', isset($data) ? $data : NULL);
    }//end function monthly_inventory()

    /**
     * This function is used for Verification of Inventory Report on Stage
     */
    public function verify_inventory()
    {
        $vendor_id = $this->input->post('fk_vendor_id', true);//get VendorID from POST
        is_admin_loggedin('admin/reports/verify_inventory');//check login status
        $data['count'] = $this->Reports_model->get_indaily_count($vendor_id);
        $data['vendors'] = $this->Reports_model->get_all_vendors();
        $data['countw'] = $this->Reports_model->get_inweekly_count($vendor_id);
        $data['countm'] = $this->Reports_model->get_inmonthly_count($vendor_id);
        $data['repeated_dates_daily'] = $this->Reports_model->repeated_daily_inventory($vendor_id);
        $data['date_daily'] = $this->Reports_model->dates_daily_inventory($vendor_id);
        $data['repeated_dates_weekly'] = $this->Reports_model->repeated_weekly_inventory($vendor_id);
        $data['date_weekly'] = $this->Reports_model->dates_weekly_inventory($vendor_id);
        $data['repeated_dates_monthly'] = $this->Reports_model->repeated_monthly_inventory($vendor_id);
        $data['date_monthly'] = $this->Reports_model->dates_monthly_inventory($vendor_id);
        $data['fk_vendor_id'] = $vendor_id;
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_userdata('fk_vendor_id', $vendor_id);
        $this->load->view('admin/reports/verifyinventory', isset($data) ? $data : NULL);
    }//end function verify_inventory()

    /**
     * This function is used for Deletion of Inventory Report on Stage
     */
    public function delete_inventory_daily()
    {
        is_admin_loggedin('admin/reports/delete_inventory_daily');
        $vendor_id = $this->session->userdata('fk_vendor_id');
        if (!empty($vendor_id)) {
            $date = $this->input->post('date_selected', TRUE);
            $is_record_deleted = $this->Reports_model->delete_inventory_daily($vendor_id, $date);
            if ($is_record_deleted) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('move_msg_two', '<stronvg>Success!</strong> Report Deleted Successfully!');
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg_move_error', '<strong>Error!</strong> Kindly Select Vendor.');
        }//end if statment
        redirect('admin/reports/verify_inventory');
    }//end function delete_inventory_daily()

    /**
     * This function is used for Deletion of Weekly Inventory Report on Stage
     */
    public function delete_inventory_weekly()
    {
        is_admin_loggedin('admin/reports/delete_inventory_weekly');
        $vendor_id = $this->session->userdata('fk_vendor_id');
        if (!empty($vendor_id)) {
            $daterange = $this->input->post('datefilter1', true);
            $daterangeIndex = explode(" - ", $daterange);
            $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));
            $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));
            $is_record_deleted = $this->Reports_model->delete_inventory_weekly($vendor_id, $s_date, $e_date);
            if ($is_record_deleted == true) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('move_msg_two', '<strong>Success!</strong> Report Deleted Successfully!');
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong>No record found!');
            }//end if statment
        } else {
            $this->session->set_flashdata('success_msg_move_error', '<strong>Error!</strong> Kindly Select Vendor.');
        }//end if statment
        redirect('admin/reports/verify_inventory');
    }// end function delete_inventory_weekly()

    /**
     * This function is used for last Entry Date in Inventory Report on main
     */
    public function inventory_dashboard()
    {
        is_admin_loggedin('admin/reports/inventory_dashboard');
        $data['last_entries_daily'] = $this->Reports_model->get_inventory_daily_last_entries();
        $data['last_entries_weekly'] = $this->Reports_model->get_inventory_weekly_last_entries();
        $data['last_entries_monthly'] = $this->Reports_model->get_inventory_monthly_last_entries();
        $this->load->view('admin/reports/inventorydashboard', isset($data) ? $data : NULL);
    }//end  function inventory_dashboard()

    /*
    * This Function is used for Deleting Weekly Inventory from stage
    */
    public function delete_inventory_monthly()
    {
        is_admin_loggedin('admin/reports/verify_inventory');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        //check vendorID is not Empty
        if (!empty($vendor_id)) {
            $daterange = $this->input->post('datefilter', true);//get Date Range from Post
            $daterangeIndex = explode(" - ", $daterange);//split Date
            $s_date = date('Y-m-d', strtotime($daterangeIndex[0]));//
            $e_date = date('Y-m-d', strtotime($daterangeIndex[1]));
            $is_record_deleted = $this->Reports_model->delete_inventory_monthly($vendor_id, $s_date, $e_date);
            if ($is_record_deleted == true) {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('move_msg_two', '<strong>Success!</strong> Report Deleted Successfully!');
            } else {
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record found!');
            }//end if statment
        } else {
            $this->session->set_flashdata('success_msg_move_error', '<strong>Error!</strong> Kindly Select Vendor.');
        }//end if statment
        redirect('admin/reports/verify_inventory');
    }//end function delete_inventory_monthly()

    /*
    * This Function is used for Moving inventory from stage to Main
    */
    public function move_to_main_inventory()
    {

        is_admin_loggedin('admin/reports/move_to_main_inventory');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        //check vendorID is not Empty
        if (empty($vendor_id)) {
            $this->session->set_flashdata('success_msg_move_error', '<strong>Error!</strong> Kindly Select Vendor and Refresh First then Move to Main!');
            redirect('admin/reports/verify_inventory ');
        }//end if statment
        //move inventory record to main
        $response = $this->Reports_model->move_to_main_inventory($vendor_id);
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_userdata('fk_vendor_id', $vendor_id);
        //check response 
        if ($response) {
            $this->session->set_flashdata('move_msg_one', '<strong>Success!</strong> Report moved successfully!');
            $this->session->set_flashdata('move_msg_two', '<strong>Success!</strong> Report Deleted Successfully!');
            $this->session->keep_flashdata('move_msg_one');
            $this->session->keep_flashdata('move_msg_two');
        }//end if statmen
        redirect('admin/reports/verify_inventory');
    }//end function move_to_main_inventory()

    /*
    * This Function is used for deleting Inventory from stage
    */
    public function delete_inventory()
    {
        is_admin_loggedin('admin/reports/delete_inventory');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID from Session
        //check vendorID is not Empty
        if (!empty($vendor_id)) {
            $this->session->set_userdata('fk_vendor_id', $vendor_id);//set VendorID to Session
            //delete VendorID Inventory Report
            $delete_inventory_overAll = $this->Reports_model->deleteAllInventorySpecificVendor($vendor_id);
            //check Inventory Response
            if ($delete_inventory_overAll != false) {
                if ($delete_inventory_overAll['DailyInventory'] == 1 || $delete_inventory_overAll['WeeklyInventory'] == 1 || $delete_inventory_overAll['MonthyInventory'] == 1) {
                    $this->session->set_flashdata('move_msg_two', '<strong>Success!</strong> Inventory Record deleted successfully!');
                } else {
                    $this->session->set_flashdata('move_msg_two', '<strong>Success!</strong> No Record Deleted!');
                }//end if statment
                $this->session->set_flashdata('vendor_id', $vendor_id);
            } else {//when response is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No Record Found!');
            }//end if statment
        } else {//when VendorID is empty
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Kindly Select Vendor.');
        }//end if statment
        redirect('admin/reports/verify_inventory');
    }//end function delete_inventory()

    public function monthly_dropship(){
        is_admin_loggedin('admin/reports/monthly_dropship');
        $data['vendors'] = $this->Reports_model->get_all_vendors();//get list of active vendors
        $vendor_id = $this->session->userdata('fk_vendor_id');//get list of
        $data['status'] = FALSE;
        //check REQUEST_METHOD is POST
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('Excel');//load Excel Library
            ini_set('memory_limit', '2048M');//Set Memory Limit
            ini_set('max_execution_time', 0);//Set execution time
            $fk_vendor_id = $this->input->post('fk_vendor_id', true);//get VendorID from POST
            //  Check UPLOAD_ERR_NO_FILE(4); No file was uploaded.
            if ($_FILES['data_files']['error'] != 4) {
                $FileName = $_FILES['data_files']['name'];
                $FileType = 'Dropship';
                $Msg = 'Kindly select appropriate Dropship file';
                $Redirect = 'admin/reports/monthly_dropship';
                $error_type = 'empty_filesDetail';

                $fileCheckResponse = checkFileType($FileName, $FileType, $Msg, $Redirect, $error_type);

                if($fileCheckResponse != false) {
                    $file_Data = monthly_dropship_file();
                    if (isset($file_Data['error'])) {

                        $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                        $this->session->set_flashdata('error_msg', '<strong>Error!</strong> ' . strip_tags($file_Data['error']));
                    } else {
                        $storeData = [];
                        foreach ($file_Data as $key2 => $data) {
                            $db_data['fk_vendor_id'] = $fk_vendor_id;
                            $db_data['asin'] = $data['asin'];
                            $db_data['order_id'] = $data['order_id'];
                            $db_data['item_quantity'] = $data['item_quantity'];
                            $db_data['str_item_cost'] = $data['item_cost'];
                            $db_data['str_shipped_date'] = $data['shipped_date'];
                            $db_data['item_cost'] = RemoveDollarSign($db_data['str_item_cost']);
                            $db_data['shipped_date'] = DateConversion(str_replace('GMT', '', $data['shipped_date']) );
                            array_push($storeData, $db_data);
                        }//end foreach loop

                        $this->Reports_model->insert_dropship($storeData);
                        $this->session->set_userdata('fk_vendor_id', $fk_vendor_id);
                        $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report Uploaded Successfully!');
                        unset($storeData);
                    }//end if statment
                }//end if statment
            } else {
                $this->session->set_flashdata('vendor_id', $fk_vendor_id);
                $this->session->set_flashdata('empty_files', '<strong>Error!</strong> Kindly upload inventory file!');
            }//end if statment
            redirect('admin/reports/monthly_dropship');
        }//end if statment
        $this->load->view('admin/reports/monthlydropship', isset($data) ? $data : NULL);
    }

    /**
     * This function is to Verify Dropship Record
     */
    public function verify_dropship()
    {
        is_admin_loggedin('admin/reports/verify_dropship');//Check Admin is logged in
        $vendor_id = $this->input->post('fk_vendor_id'); //get Vendor ID from POST
        $data['vendors'] = $this->Reports_model->get_all_vendors();//check list of all active vendors
        $data['count'] = $this->Reports_model->get_all_dropship_count($vendor_id);//get count of all vendors
        $data['repeated_dates'] = $this->Reports_model->repeated_dropship_date($vendor_id);//get repeated record by date
        $data['date_records'] = $this->Reports_model->dates_for_dropship_record($vendor_id);//get record by date
        $data['distinct_dropship'] = $this->Reports_model->distinct_dropship($vendor_id);//get distint PO Records
        $this->session->set_userdata('fk_vendor_id', $vendor_id); //set session
        $this->load->view('admin/reports/verifydropship', isset($data) ? $data : NULL);//load verifypurchaseorder view with data
    }//end verify_po function()

    /**
     * This function is move_to_main for moving Dropship Record to main for Specific Vendor
     */
    public function move_to_main_dropship()
    {
        is_admin_loggedin('admin/reports/move_to_main_dropship');//Check Admin is logged in
        $vendor_id = $this->session->userdata('fk_vendor_id');//get Vendor ID
        if ($vendor_id != '') {
            $this->Reports_model->move_to_main_dropship($vendor_id);//Move record of Vendor to main
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report moved successfully!');
        } else {//when vendor id is empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_dropship');
    }//end function move_to_main()

    /**
     * This function is used for Deleting all the Sales from stage table
     */
    public function delete_dropship()
    {
        is_admin_loggedin('admin/reports/delete_dropship');//check login status
        $vendor_id = $this->session->userdata('fk_vendor_id');//get VendorID form Session variable
        //check vendorID is not empty
        if ($vendor_id != '') {
            //delete all the DropShip of vendor
            $delete_dropship_overAll = $this->Reports_model->deleteAllDropshipSpecificVendor($vendor_id);
            //check response of the model
            if ($delete_dropship_overAll == true) {
                $this->session->set_userdata('fk_vendor_id', $vendor_id);
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Record deleted successfully!');
            } else {//when reponse is false
                $this->session->set_flashdata('vendor_id', $vendor_id);
                $this->session->set_flashdata('error_msg', '<strong>Error!</strong> No record deleted!');
            }//end if statment
        } else {//when vendor id is empty
            $this->session->set_flashdata('vendor_id', $vendor_id);
            $this->session->set_flashdata('error_msg', '<strong>Error!</strong> Vendor is missing!');
        }//end if statment
        redirect('admin/reports/verify_dropship');
    }//end function delete_dropship()

    /**
     * This function is delete_dropship_selected for Deleting Dropship Record for Specific Vendor by slected Date
     */
    public function delete_dropship_selected()
    {
        is_admin_loggedin('admin/reports/delete_dropship_selected');//Check Admin is logged in
        $vendor_id = $this->session->userdata('fk_vendor_id');//get Vendor ID
        $date = $this->input->post('date_selected', TRUE);//get selected date
        $this->Reports_model->delete_dropship_bydate($vendor_id, $date);//delete record of Vendor by date from stage
        $this->session->set_flashdata('vendor_id', $vendor_id);
        $this->session->set_flashdata('success_msg', '<strong>Success!</strong> Report deleted successfully!');
        redirect('admin/reports/verify_dropship');
    }//end function delete_dropship_selected()

    /**
     * This function is dropship_dashboard for Geting Last Dropship Entry in Main
     */
    public function dropship_dashboard()
    {
        is_admin_loggedin('admin/reports/dropship_dashboard');//Check Admin is logged in
        $data['last_entries'] = $this->Reports_model->get_dropship_last_entries();//get last entry in PO Main Table
        $this->load->view('admin/reports/dropshipdashboard', isset($data) ? $data : NULL);//load verifypurchaseorder view with data
    }//end fucntion dropship_dashboard()

}//end Class Reports