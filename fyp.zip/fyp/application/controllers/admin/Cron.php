<?php
/** 
* This is the class Cron for the call stored procedure from Command Line Interface.
*/ 
class Cron extends CI_Controller
{
	/** 
	* This is the Constructor of this Class in this we load libraries and Models.
	* @see model/Admin_model, model/Reports_model for Models  
	*/
	public function __construct()
	{
		parent::__construct();
	}//end __construct
	
	/** 
	* This function is for call stored procedure by checking request is through CLI or from browser.
	*/
    public function call_stored_procedure()
    {
		//check request type  
		if($this->input->is_cli_request()) {
            //get response by call store procedure function from Reports_model
			$result = $this->Reports_model->call_stored_procedure();
			//check response
            if(isset($result)){
                echo 'yes';
            }else{//when response is FALSE
                echo 'no';
            }//end if Statement
        }//end if Statement
    }//end function call_stored_procedure

}// end of Cron Class
?>