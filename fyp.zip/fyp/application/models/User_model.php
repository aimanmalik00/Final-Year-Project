<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
*This Class is for User Model for All User Database operations
*/
class User_model extends CI_Model
{
    private $table_name = "tbl_user";
    private $tbl_purchaseorders_vendor_distribution_type = "tbl_purchaseorders_vendor_distribution_type";

	/*
	*This function is for authenticate User Information
	*@param data
	*/
    public function authenticate_user($data)
    {
        return $this->db->get_where($this->table_name, $data)->row();
    }//end function authenticate_user

	/*
	*This function is for Updating User Information
	*@param user_id
	*@param data
	*@return mixed
	*/
    public function update($user_id, $data)
    {
        $this->db->where('user_id', $user_id);
        return $this->db->update($this->table_name, $data);
    }//end function update

    /**
     * This function is used insert and update Data
     * @param $db_data
     */
    public function insert_categories($db_data)
    {
        $this->db->insert_batch('tbl_temp_asin_sales_category', $db_data);
    }//end function insert_categories

    /**
	* this function is used for add new vendor record 
     * @param $storeArray
     * @return array
     */
    public function AddVendorRecord($storeArray)
    {
        // define Return Value Array
        $returnValueArray = [];
        // Store Values
        $returnValueArray['totalValue'] = COUNT($storeArray);
        $returnValueArray['insetValue'] = 0;
        // Get All Store Vendor Code From DB
        $getAllValue = $this->db->get($this->tbl_purchaseorders_vendor_distribution_type)->result();
        if (!empty($getAllValue)) {
            // Find Duplicated Vendor Code
            foreach ($storeArray as $index => $value) {
                $ExistValueRespnse = $this->db->get_where($this->tbl_purchaseorders_vendor_distribution_type, array('vendor_code' => $value['vendor_code']))->row();
                if (empty($ExistValueRespnse)) {
                    $singleArray = [
                        'vendor_code' => $value['vendor_code'],
                        'distribution_type' => $value['distribution_type'],
                        'capture_date' => $value['capture_date']
                    ];
                    $this->db->insert($this->tbl_purchaseorders_vendor_distribution_type, $singleArray);
                    $returnValueArray['insetValue'] = $returnValueArray['insetValue'] + 1;
                }//end if statment
            }//end foreach
        } else {
            $this->db->insert_batch($this->tbl_purchaseorders_vendor_distribution_type, $storeArray);
            $returnValueArray['insetValue'] = $returnValueArray['totalValue'];
        }//end if statment
        return $returnValueArray;
    }//end function AddVendorRecord
}//end class User_model