<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
*This Class is for Notification Model for FTP files
*/
class Notification_model extends CI_Model
{
    private $notification_table = "tbl_notification";
	
	public function insert_notification($data)
    {
        $this->db->trans_begin();
        $this->db->insert($this->notification_table, $data);
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_notification
	
	
	public function get_notification_count()
    {
        $this->db->where('status', 1);
        return $this->db->get($this->notification_table)->num_rows();
    }//end function get_notification_count
	
	public function get_all_notification()
    {
        $this->db->order_by('send_at', 'DESC');
		return $this->db->get($this->notification_table)->result();
    }//end function get_all_notification
	
	public function get_unreaded_by_limit()
    {
		$this->db->limit(5);
		$this->db->order_by('status', 'DESC');
		$this->db->order_by('send_at', 'DESC');
        return $this->db->get($this->notification_table)->result();
    }//end function get_unreaded_by_limit
	
	
	public function get_notification_info($notification_id)
    {
		$this->mark_as_readed($notification_id);
		
		$this->db->where('id', $notification_id);
		return $this->db->get($this->notification_table)->result();
    }//end function get_notification_info
	
	public function mark_as_readed($notification_id)
    {
		$data = array(
            'status' => 0
        );
		$this->db->where('id', $notification_id);
		$this->db->update($this->notification_table,$data);
		return ($this->db->affected_rows() > 0) ? TRUE : FALSE; 		
    }//end function mark_as_readed

    public function dismiss_notification($notification_id)
    {
        $this->db->where('id', $notification_id);
        $this->db->delete($this->notification_table);
        return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
    }//end function mark_as_readed

	public function mark_all_as_readed()
    {
		$data = array(
            'status' => 0
        );
		$this->db->update($this->notification_table,$data);
		return ($this->db->affected_rows() > 0) ? TRUE : FALSE; 
    }//end function mark_all_as_readed
	
}//end class Notification_model