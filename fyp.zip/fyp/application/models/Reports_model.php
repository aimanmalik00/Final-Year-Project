<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class Reports_model
 */
class Reports_model extends CI_Model
{
    private $tbl_purchaseOrders = "tbl_stage_tanabi_purchaseorders";
    private $tbl_dailySales = "tbl_stage_daily_sales";
    private $tbl_weeklySalesDetail = "tbl_stage_weekly_sales";
    private $tbl_weeklySalesSummary = "tbl_stage_weekly_sales_summary";
    private $tbl_asin_sales_category = "tbl_asin_sales_category";
    private $tbl_monthlySalesDetail = "tbl_stage_monthly_sales";
    private $tbl_monthlySalesSummary = "tbl_stage_monthly_sales_summary";
    private $tbl_powerbi_roles = "tbl_powerbi_roles";
    private $tbl_stage_monthly_ams_campaigns = 'tbl_stage_monthly_ams_campaigns';
    private $tbl_stage_monthly_ams_spbrand = 'tbl_stage_monthly_ams_spbrand';
    private $tbl_stage_monthly_ams_spproduct = 'tbl_stage_monthly_ams_spproduct';
    private $tbl_stage_daily_inventory = 'tbl_stage_daily_inventory';
    private $tbl_stage_weekly_inventory = 'tbl_stage_weekly_inventory';
    private $tbl_stage_monthly_inventory = 'tbl_stage_monthly_inventory';
    private $tbl_stage_daily_chargebacks = 'tbl_stage_daily_chargebacks';

    /**
	* This function is for authenticate Vendor information
     * @param $data
     * @return mixed
     */
    public function authenticate_user($data)
    {
        return $this->db->get_where($this->tbl_purchaseOrders, $data)->row();
    }//end function authenticate_user

    /**
	* this function is used to update information
     * @param $user_id
     * @param $data
     * @return mixed
     */
    public function update($user_id, $data)
    {
        $this->db->where('admin_id', $user_id);
        return $this->db->update($this->tbl_purchaseOrders, $data);
    }//end function update

    /**
     * @param $fetchdata
     * @return mixed
     */
    public function insert_report($data)
    {
        $this->db->insert_batch($this->tbl_purchaseOrders, $data);
    }//end function insert_report

    /**
     * @return mixed
     */
    public function get_all_vendors()
    {
        $this->db->select('vendor_id, vendor_name, domain,tier,vendor_status');
        $this->db->from('tbl_purchaseorders_vendors');
		$this->db->where('vendor_status',1);
        $this->db->order_by('vendor_name');
        return $this->db->get()->result();
    }//end function get_all_vendors
	
	/**
     * @return mixed
     */
    public function get_vendors_list()
    {
        $this->db->select('vendor_id, vendor_name, domain,tier,vendor_status');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->order_by('vendor_name');
        return $this->db->get()->result();
    }//end function get_vendors_list
	
    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_all_count($vendor_id)
    {
        $this->db->from($this->tbl_purchaseOrders);
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_all_count

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_each_date($vendor_id)
    {
        $this->db->select('orderon_date AS Order_Date, COUNT(`po_id`) AS Repeated_Record , COUNT(asin) as Repeated_asin');
        $this->db->from($this->tbl_purchaseOrders);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`fk_vendor_id`,`po`,`ship_to_location`,`asin`,`title`,`delivery_window_start`,`delivery_window_end`,`submitted_cases`,`accepted_cases`,`total_cost`');
        $this->db->having('Repeated_Record >', 1);
        $this->db->having('Repeated_asin >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_each_date

    /**
     * @return mixed
     */
    public function get_po_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_tanabi_main_purchaseorders.orderon_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_tanabi_main_purchaseorders', 'tbl_tanabi_main_purchaseorders.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_po_last_entries

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_for_record($vendor_id)
    {

        $this->db->select('orderon_date AS dates ,COUNT(`asin`) AS cnt');
        $this->db->from($this->tbl_purchaseOrders);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('orderon_date');
        return $this->db->get()->result();

    }//end function dates_for_record

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function distinct_po($vendor_id)
    {
        $this->db->select('COUNT(po) AS No_of_POs');
        $this->db->from($this->tbl_purchaseOrders);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('po');
        return $this->db->get()->num_rows();
    }//end function distinct_po

    /**
     * @param $vendor_id
     * @param $date
     * @return mixed
     */
    public function delete_po($vendor_id, $date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete($this->tbl_purchaseOrders);
    }//end function delete_po

    /**
     * @param $vendor_id
     * @param $date
     * @return mixed
     */
    public function delete_po_selected($vendor_id, $date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('orderon_date', $date);
        return $this->db->delete($this->tbl_purchaseOrders);
    }//end function delete_po_selected

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main($vendor_id)
    {

        $query = $this->db->query("call spEtlPurchaseOrder(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;

    }//end function move_to_main

    /**
     * @return mixed
     */
    public function call_stored_procedure()
    {
        return $this->db->query("call spPopulatePoFactTables");
    }//end function call_stored_procedure

    /**
     * This function is used to Update Category Daily Detail File Subcategory On Base of ASIN
     * @param $vendor_id
     * @param $startDate
     * @param $endDate
     */
    public function updateCategoryAsinDaily($vendor_id, $Date)
    {
        $this->db->select('sales.asin,cat.category as subcategory');
        $this->db->from($this->tbl_dailySales . ' as sales');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = sales.asin');
        $this->db->where('sales.sale_date', $Date);
        $this->db->where('sales.fk_vendor_id', $vendor_id);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_dailySales, $dataArray, 'asin');
        }//end if statment
    }//end function updateCategoryAsinDaily

    /**
     * This function is used to update Category Depend on ASIN Number
     * @param $vendor_id
     * @param $startDate
     * @param $endDate
     */
    public function updateCategoryAsinWeekly($vendor_id, $startDate, $endDate)
    {
        $this->db->select('sales.asin,cat.category as subcategory');
        $this->db->from($this->tbl_weeklySalesDetail . ' as sales');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = sales.asin');
        $this->db->where('sales.start_date', $startDate);
        $this->db->where('sales.end_date', $endDate);
        $this->db->where('sales.fk_vendor_id', $vendor_id);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_weeklySalesDetail, $dataArray, 'asin');
        }//end if statment
    }//end function updateCategoryAsinWeekly

    /**
     * This function is used to get All Same ASIN number Category
     * Update all same ASIN Number subcategory in DB
     * @param $vendor_id
     * @param $startDate
     * @param $endDate
     */
    public function updateCategoryAsinMonthty($vendor_id, $startDate, $endDate)
    {
        $this->db->select('sales.asin,cat.category as subcategory');
        $this->db->from($this->tbl_monthlySalesDetail . ' as sales');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = sales.asin');
        $this->db->where('sales.start_date', $startDate);
        $this->db->where('sales.end_date', $endDate);
        $this->db->where('sales.fk_vendor_id', $vendor_id);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_monthlySalesDetail, $dataArray, 'asin');
        }//end if statment
    }//end function updateCategoryAsinMonthty

    public function insert_poData($StoreArray)
    {
        $this->db->trans_begin();
        $this->db->insert_batch($this->tbl_purchaseOrders, $StoreArray);
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_poData

    /**
     * This fucntion is used to insert Daily Detail file Data
     * @param $db_data
     * @return mixed
     */
    public function insert_sales_data($db_data, $vendor_id, $Date)
    {
        $this->db->trans_begin();
        //$this->db->insert($this->tbl_dailySales, $db_data);
        // written BY ABDUL WAQAR reason insertion time reduce
        $this->db->insert_batch($this->tbl_dailySales, $db_data);
        $this->db->select('sales.asin,cat.category as subcategory');
        $this->db->from($this->tbl_dailySales . ' as sales');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = sales.asin');
        $this->db->where('sales.sale_date', $Date);
        $this->db->where('sales.fk_vendor_id', $vendor_id);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_dailySales, $dataArray, 'asin');
        }//end if statment
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_sales_data

    /**
     * @param $db_data
     * @param $vendor_id
     * @param $startDate
     * @param $endDate
     */
    public function insert_sales_weekly($db_data, $vendor_id, $startDate, $endDate)
    {
        $this->db->trans_begin();
        //$this->db->insert($this->tbl_weeklySalesDetail,$db_data);
        // written BY ABDUL WAQAR reason insertion time reduce
        $this->db->insert_batch($this->tbl_weeklySalesDetail, $db_data);
        // update Subcategory On BASES of ASIN
        $this->db->select('sales.asin,cat.category as subcategory');
        $this->db->from($this->tbl_weeklySalesDetail . ' as sales');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = sales.asin');
        $this->db->where('sales.start_date', $startDate);
        $this->db->where('sales.end_date', $endDate);
        $this->db->where('sales.fk_vendor_id', $vendor_id);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_weeklySalesDetail, $dataArray, 'asin');
        }//end if statment
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_sales_weekly

    /**
     * This function is used to Insert Weekly Summary File Data
     * @param $summary_data
     * @return mixed
     */
    public function insert_sales_weekly_summary($summary_data)
    {
        $this->db->insert($this->tbl_weeklySalesSummary, $summary_data);
        return $this->db->insert_id();
    }//end function insert_sales_weekly_summary

    /**
     * @param $db_data
     * @param $vendor_id
     * @param $startDate
     * @param $endDate
     */
    public function insert_sales_monthly($db_data, $vendor_id, $startDate, $endDate)
    {
        $this->db->trans_begin();
        // $this->db->insert($this->tbl_monthlySalesDetail, $db_data);
        // written BY ABDUL WAQAR reason insertion time reduce
        $this->db->insert_batch($this->tbl_monthlySalesDetail, $db_data);
        // update Subcategory On BASES of ASIN
        $this->db->select('sales.asin,cat.category as subcategory');
        $this->db->from($this->tbl_monthlySalesDetail . ' as sales');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = sales.asin');
        $this->db->where('sales.start_date', $startDate);
        $this->db->where('sales.end_date', $endDate);
        $this->db->where('sales.fk_vendor_id', $vendor_id);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_monthlySalesDetail, $dataArray, 'asin');
        }//end if statment
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_sales_monthly

    /**
     * This function is used to Insert Monthly Sales Summary File Data
     * @param $summary_data
     */
    public function insert_sales_monthly_summary($summary_data)
    {
        $this->db->insert($this->tbl_monthlySalesSummary, $summary_data);
    }//end function insert_sales_monthly_summary

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_daily_sales_date($vendor_id)
    {
        $this->db->select('sale_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_daily_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`asin`,`fk_vendor_id`,`sale_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_daily_sales_date

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_daily_sales_record($vendor_id)
    {
        $this->db->select('sale_date AS dates, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_daily_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('sale_date');
        return $this->db->get()->result();
    }//end function dates_daily_sales_record

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_weekly_sales_date($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`asin`) AS cnt , COUNT(str_shipped_cogs) as cntCogs');
        $this->db->from("tbl_stage_weekly_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by(' `asin`,`fk_vendor_id`,`start_date`,`end_date`,str_shipped_cogs');
        $this->db->having('cnt  >', 1);
        $this->db->having('cntCogs  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_weekly_sales_date

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_weekly_sales_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(`asin`) AS cnt');
        $this->db->from('tbl_stage_weekly_sales');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('start_date,"-",end_date');
        return $this->db->get()->result();
    }//end function dates_weekly_sales_record

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_monthly_sales_date($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_monthly_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by(' `asin`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_monthly_sales_date

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_monthly_sales_record($vendor_id)
    {

        $this->db->select('`start_date`,"-",`end_date`, COUNT(`asin`) AS cnt');
        $this->db->from('tbl_stage_monthly_sales');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('start_date,"-",end_date');
        return $this->db->get()->result();
    }//end function dates_monthly_sales_record

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_sales($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete($this->tbl_purchaseOrders);
    }//end function delete_sales

    /**
     * @param $vendor_id
     * @param $date
     * @return mixed
     */
    public function delete_sales_daily($vendor_id, $date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('sale_date', $date);
        $this->db->delete("tbl_stage_daily_sales");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_sales_daily

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_sales_weekly($vendor_id, $s_date, $e_date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_weekly_sales");
		$weekly_sales = $this->db->affected_rows();
        // delete weekly sales summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_weekly_sales_summary");
		$weekly_sales_summary = $this->db->affected_rows();
        if ($weekly_sales > 0 || $weekly_sales_summary > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_sales_weekly

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_sales_monthly($vendor_id, $s_date, $e_date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_monthly_sales");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_sales_monthly

    public function deleteMonthlySalesVendor($vendor_id, $s_date, $e_date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_monthly_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_monthly_sales_summary");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function deleteMonthlySalesVendor

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_sales_selected($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('orderon_date', $vendor_id);
        return $this->db->delete($this->tbl_purchaseOrders);
    }//end function delete_sales_selected

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_sales($vendor_id)
    {
        $query = $this->db->query("call spEtlPurchaseOrder(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_sales

    /**
     * @return mixed
     */
    public function get_sales_daily_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_daily_sales.sale_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_daily_sales', 'tbl_main_daily_sales.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_sales_daily_last_entries

    /**
     * @return mixed
     */
    public function get_sales_weekly_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_weekly_sales.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_weekly_sales', 'tbl_main_weekly_sales.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_sales_weekly_last_entries

    /**
     * @return mixed
     */
    public function get_sales_monthly_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_monthly_sales.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_monthly_sales', 'tbl_main_monthly_sales.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_sales_monthly_last_entries

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_sdaily_count($vendor_id)
    {
        $this->db->from("tbl_stage_daily_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_sdaily_count

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_sweekly_count($vendor_id)
    {
        $this->db->from("tbl_stage_weekly_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_sweekly_count

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_smonthly_count($vendor_id)
    {
        $this->db->from("tbl_stage_monthly_sales");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_smonthly_count

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_salesd($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete("tbl_stage_daily_sales");
    }//end function delete_salesd

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_salesw($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete("tbl_stage_weekly_sales");
    }//end function delete_salesw

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_salesm($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete("tbl_stage_monthly_sales");
    }//end function delete_salesm

    /**
     * This function is used to delete Single Vendor Record FROM DB
     * @param $vendor_id
     * @return bool
     */
    public function deleteAllSalesSpecificVendor($vendor_id)
    {

        // delete sales
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_daily_sales");

        // delete weekly sales
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_weekly_sales");

        // Delete monthly sales summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_monthly_sales");

        // Delete weekly sale summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_weekly_sales_summary");

        // Delete monthly sales summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_monthly_sales_summary");

        return true;

    }//end function deleteAllSalesSpecificVendor

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_sale($vendor_id)
    {
        $query = $this->db->query("call spEtlSales(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_sale

    public function insert_dropship($StoreArray)
    {
        $this->db->trans_begin();
        $this->db->insert_batch('tbl_stage_tanabi_dropship', $StoreArray);
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_poData

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_all_dropship_count($vendor_id)
    {
        $this->db->from('tbl_stage_tanabi_dropship');
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_all_dropship_count


    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_dropship_date($vendor_id)
    {
        $this->db->select('shipped_date, COUNT(`order_id`) AS Repeated_Record , COUNT(asin) as Repeated_asin');
        $this->db->from('tbl_stage_tanabi_dropship');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`fk_vendor_id`,`asin`,`order_id`');
        $this->db->having('Repeated_Record >', 1);
        $this->db->having('Repeated_asin >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_each_date

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_for_dropship_record($vendor_id)
    {

        $this->db->select('shipped_date AS dates ,COUNT(`asin`) AS cnt');
        $this->db->from('tbl_stage_tanabi_dropship');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('shipped_date');
        return $this->db->get()->result();

    }//end function dates_for_dropship_record

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function distinct_dropship($vendor_id)
    {
        $this->db->select('COUNT(order_id) AS No_of_order');
        $this->db->from('tbl_stage_tanabi_dropship');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('order_id');
        return $this->db->get()->num_rows();
    }//end function distinct_dropship

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_dropship($vendor_id)
    {
        $query = $this->db->query("call spEtlDropship(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_dropship

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function deleteAllDropshipSpecificVendor($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete('tbl_stage_tanabi_dropship');
    }//end function delete_po

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_dropship_bydate($vendor_id,$date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('shipped_date', $date);
        return $this->db->delete('tbl_stage_tanabi_dropship');
    }//end function delete_dropship_bydate

    /**
     * @return mixed
     */
    public function get_dropship_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_tanabi_dropship.shipped_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_tanabi_dropship', 'tbl_main_tanabi_dropship.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_po_last_entries


    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_forecast_count($vendor_id)
    {
        $this->db->from("tbl_stage_forecast_weekly");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_forecast_count

    /**
     * @return mixed
     */
    public function get_forecast_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_forecast_weekly.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_forecast_weekly', 'tbl_main_forecast_weekly.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_forecast_last_entries

    
     /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_records_forecast($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_forecast_weekly");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`asin`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();

    }//end function repeated_records_forecast

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function date_daily_forecast_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(fk_vendor_id) AS cnt');
        $this->db->from('tbl_stage_forecast_weekly');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`start_date`,`end_date`');
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function date_daily_forecast_record
    
       /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_weekly_forecast($summary_data)
    {
        $this->db->trans_start();
        $this->db->insert_batch("tbl_stage_forecast_weekly", $summary_data);
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
                $this->db->trans_rollback();
                $result = false;
        }else{//when transaction Status is TRUE
                $this->db->trans_commit();
                $result = true;
        }//end if statment
        return $result;
    }//end function insert_weekly_forecast


    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_forecast($vendor_id)
    {
        $query = $this->db->query("call spEtlForecast(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_forecast

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_forecast($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_forecast_weekly");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_forecast

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_forecast_weekly($vendor_id, $s_date, $e_date)
    {
        // delete weekly traffic summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_forecast_weekly");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_forecast_weekly


    
    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_brandstore_bypage_count($vendor_id)
    {
        $this->db->from("tbl_stage_brandstore_bypage");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_brandstore_bypage_count

    /**
     * @return mixed
     */
    public function get_brandstore_bypage_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_brandstore_bydate.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_brandstore_bydate', 'tbl_main_brandstore_bydate.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_brandstore_bypage_last_entries

    
     /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_records_brandstore_bypage($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`page`) AS cnt');
        $this->db->from("tbl_stage_brandstore_bypage");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`page`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();

    }//end function repeated_records_brandstore_bypage

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function date_daily_brandstore_bypage_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(fk_vendor_id) AS cnt');
        $this->db->from('tbl_stage_brandstore_bypage');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`start_date`,`end_date`');
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function date_daily_brandstore_bypage_record



    
    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_brandstore_bysource_count($vendor_id)
    {
        $this->db->from("tbl_stage_brandstore_bysource");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_brandstore_bysource_count

    /**
     * @return mixed
     */
    public function get_brandstore_bysource_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_brandstore_bysource.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_brandstore_bysource', 'tbl_main_brandstore_bysource.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_brandstore_bysource_last_entries

    
     /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_records_brandstore_bysource($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`source`) AS cnt');
        $this->db->from("tbl_stage_brandstore_bysource");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`source`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();

    }//end function repeated_records_brandstore_bysource

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function date_daily_brandstore_bysource_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(fk_vendor_id) AS cnt');
        $this->db->from('tbl_stage_brandstore_bysource');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`start_date`,`end_date`');
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function date_daily_brandstore_bysource_record
    

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_brandstore_bydate_count($vendor_id)
    {
        $this->db->from("tbl_stage_brandstore_bydate");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_brandstore_bydate_count

    /**
     * @return mixed
     */
    public function get_brandstore_bydate_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_brandstore_bydate.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_brandstore_bydate', 'tbl_main_brandstore_bydate.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_brandstore_bydate_last_entries

    
     /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_records_brandstore_bydate($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`brand_store_date`) AS cnt');
        $this->db->from("tbl_stage_brandstore_bydate");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`brand_store_date`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();

    }//end function repeated_records_brandstore_bydate

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function date_daily_brandstore_bydate_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(fk_vendor_id) AS cnt');
        $this->db->from('tbl_stage_brandstore_bydate');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`start_date`,`end_date`');
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function date_daily_brandstore_bydate_record

    
       /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_weekly_brandstore($summary_data)
    {
        $this->db->trans_start();
        
        $this->db->insert_batch("tbl_stage_brandstore_bydate", $summary_data['date']);
        $this->db->insert_batch("tbl_stage_brandstore_bypage", $summary_data['page']);
        $this->db->insert_batch("tbl_stage_brandstore_bysource", $summary_data['source']);
        
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
                $this->db->trans_rollback();
                $result = false;
        }else{//when transaction Status is TRUE
                $this->db->trans_commit();
                $result = true;
        }//end if statment
        return $result;
    }//end function insert_weekly_brandstore

    /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_weekly_brandstore_bydate($summary_data)
    {
        $this->db->trans_start();

        $this->db->insert_batch("tbl_stage_brandstore_bydate", $summary_data);

        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
            $this->db->trans_rollback();
            $result = false;
        }else{//when transaction Status is TRUE
            $this->db->trans_commit();
            $result = true;
        }//end if statment
        return $result;
    }//end function insert_weekly_brandstore_bydate

    /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_weekly_brandstore_bypage($summary_data)
    {
        $this->db->trans_start();

        $this->db->insert_batch("tbl_stage_brandstore_bypage", $summary_data);

        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
            $this->db->trans_rollback();
            $result = false;
        }else{//when transaction Status is TRUE
            $this->db->trans_commit();
            $result = true;
        }//end if statment
        return $result;
    }//end function insert_weekly_brandstore_bypage

    /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_weekly_brandstore_bysource($summary_data)
    {
        $this->db->trans_start();

        $this->db->insert_batch("tbl_stage_brandstore_bysource", $summary_data);

        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
            $this->db->trans_rollback();
            $result = false;
        }else{//when transaction Status is TRUE
            $this->db->trans_commit();
            $result = true;
        }//end if statment
        return $result;
    }//end function insert_weekly_brandstore_bysource


    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_brandstore($vendor_id)
    {
        $query = $this->db->query("call spBrandstoreETL(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_brandstore

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_brandstore($vendor_id)
    {

        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_brandstore_bydate");
        $bydate_rows = $this->db->affected_rows();

        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_brandstore_bypage");
        $bypage_rows = $this->db->affected_rows();

        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_brandstore_bysource");
        $bysource_rows = $this->db->affected_rows();
        
        
        if ($bydate_rows > 0 || $bypage_rows > 0 || $bysource_rows > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_brandstore

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_brandstore_bypage_weekly($vendor_id, $s_date, $e_date)
    {
        // delete weekly traffic summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_brandstore_bypage");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_brandstore_bypage_weekly

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_brandstore_bysource_weekly($vendor_id, $s_date, $e_date)
    {
        // delete weekly traffic summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_brandstore_bysource");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_brandstore_bysource_weekly

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_brandstore_bydate_weekly($vendor_id, $s_date, $e_date)
    {
        // delete weekly traffic summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_brandstore_bydate");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_brandstore_bydate_weekly


       /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_executivedashboard($DateData)
    {
        $this->db->trans_start();
        
        $this->db->insert_batch("tbl_sc_stage_daily_sales_agg", $DateData);
        
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
                $this->db->trans_rollback();
                $result = false;
        }else{
                $this->db->trans_commit();
                $result = true;
        }
        return $result;
    }


    /**
     * @return mixed
     */
    function get_executivedashboard_count()
    {
        $this->db->from("tbl_sc_stage_daily_sales_agg");
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }

    
    /**
     * @param $vendor_id
     * @return mixed
     */
    function repeated_executivedashboard_records()
    {
        $this->db->select('MONTH(start_date) as month,"-",YEAR(start_date) as year, COUNT(`start_date`) AS cnt');
        $this->db->from("tbl_sc_stage_daily_sales_agg");
        $this->db->group_by('DAY(start_date),MONTH(start_date),YEAR(start_date)');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();

    }

    /**
     * @return mixed
     */
    function executivedashboard_records()
    {
        $this->db->select('MONTH(start_date) as month,"-",YEAR(start_date) as year, COUNT(`start_date`) AS cnt');
        $this->db->from("tbl_sc_stage_daily_sales_agg");
        $this->db->group_by('MONTH(start_date),YEAR(start_date)');
        $this->db->distinct();
        return $this->db->get()->result();
    }

    /**
     * @return mixed
     */
    function executivedashboard_records_years()
    {
        $this->db->select('YEAR(start_date) as year, COUNT(`start_date`) AS records');
        $this->db->from("tbl_sc_stage_daily_sales_agg");
        $this->db->group_by('YEAR(start_date)');
        return $this->db->get()->result();
    }

    /**
     * @return mixed
     */
    function move_to_main_executivedashboard()
    {
        $query = $this->db->query("call spETLexecutiveDashboard()");
        $return = $query->num_rows();
        return $return;
    }

    /**
     * @return mixed
     */
    function delete_executivedashboard($year)
    {
        $this->db->where('YEAR(start_date)', $year);
        $this->db->delete("tbl_sc_stage_daily_sales_agg");
        if ($this->db->affected_rows() > 0) {
            return true;
        }
        return false;
    }

     /**
     * @return mixed
     */
    function executivedashboard_last_entry()
    {
        $this->db->select('MAX(YEAR(start_date)) as max_year');
        $this->db->from("tbl_sc_main_daily_sales_agg");
        $this->db->group_by('YEAR(start_date)');
        return $this->db->get()->result();
    }

        /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_promotion_count($vendor_id)
    {
        $this->db->from("tbl_stage_monthly_promotion_summary");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_promotion_count

        /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_promotion_coupons_count($vendor_id)
    {
        $this->db->from("tbl_stage_monthly_coupons");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_promotion_coupons_count

    
    
     /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_records_promotion($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_monthly_promotion_summary");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`asin`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();

    }  //end function repeated_records_promotion
    
    /**
     * @return mixed
     */
    public function get_chargeback_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_daily_chargebacks.creation_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_daily_chargebacks', 'tbl_main_daily_chargebacks.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_chargeback_last_entries
    
    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_records_promotion_coupons($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`cuopon_name`) AS cnt');
        $this->db->from("tbl_stage_monthly_coupons");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`cuopon_name`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_records_promotion_coupons

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function date_daily_promotion_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(fk_vendor_id) AS cnt');
        $this->db->from('tbl_stage_monthly_promotion_summary');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`start_date`,`end_date`');
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function date_daily_promotion_record

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function date_daily_promotion_coupons_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(fk_vendor_id) AS cnt');
        $this->db->from('tbl_stage_monthly_coupons');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`start_date`,`end_date`');
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function date_daily_promotion_coupons_record
    
       /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_monthly_promotion($summary_data)
    {
        $this->db->trans_start();
        $this->db->insert_batch("tbl_stage_monthly_promotion_summary", $summary_data);
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
                $this->db->trans_rollback();
                $result = false;
        }else{//when transaction Status is TRUE
                $this->db->trans_commit();
                $result = true;
        }//end if statment
        return $result;
    }//end function insert_monthly_promotion

       /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_monthly_promotion_coupons($summary_data)
    {
        $this->db->trans_start();
        $this->db->insert_batch("tbl_stage_monthly_coupons", $summary_data);
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
                $this->db->trans_rollback();
                $result = false;
        }else{//when transaction Status is TRUE
                $this->db->trans_commit();
                $result = true;
        }//end if statment
        return $result;
    }//end function insert_monthly_promotion_coupons


    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_promotion($vendor_id)
    {
        $query = $this->db->query("call spEtlPromotionSummaryPrac(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_promotion

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_promotion($vendor_id)
    {
        $rows_promotion_affected = false;
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_monthly_promotion_summary");
        if ($this->db->affected_rows() > 0) {
            $rows_promotion_affected =  true;
        }//end if statment

        $rows_coupons_affected = false;
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_monthly_coupons");
        if ($this->db->affected_rows() > 0) {
            $rows_coupons_affected = true;
        }//end if statment

        if($rows_coupons_affected || $rows_coupons_affected){
            return true;
        }//end if statment
        return false;
    }//end function delete_promotion

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_promotionSummary_monthly($vendor_id, $s_date, $e_date)
    {
        // delete weekly promotion summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_monthly_promotion_summary");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_promotionSummary_monthly

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_promotionCoupons_monthly($vendor_id, $s_date, $e_date)
    {
        // delete weekly promotion summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_monthly_coupons");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_promotionCoupons_monthly

    /**
     * @param $summary_data
     * @return mixed
     */
    public function insert_weekly_traffic($summary_data)
    {
        $this->db->trans_start();
        $this->db->insert_batch("tbl_stage_weekly_traffic_summary", $summary_data);
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
                $this->db->trans_rollback();
                $result = false;
        }else{//when transaction status is TRUE
                $this->db->trans_commit();
                $result = true;
        }//end if statment
        return $result;
    }//end function insert_weekly_traffic

    /**
     * @return mixed
     */
    public function get_traffic_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_weekly_traffic_summary.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_weekly_traffic_summary', 'tbl_main_weekly_traffic_summary.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_traffic_last_entries

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_traffic_count($vendor_id)
    {
        $this->db->from("tbl_stage_weekly_traffic_summary");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_traffic_count

     /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_records_traffic($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_weekly_traffic_summary");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`asin`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_records_traffic

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function date_daily_traffic_record($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(fk_vendor_id) AS cnt');
        $this->db->from('tbl_stage_weekly_traffic_summary');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`start_date`,`end_date`');
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function date_daily_traffic_record


    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_traffic($vendor_id)
    {
        $query = $this->db->query("call spEtlTrafficSummary(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_traffic

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_traffic($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete("tbl_stage_weekly_traffic_summary");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_traffic

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_traffic_weekly($vendor_id, $s_date, $e_date)
    {
        // delete weekly traffic summary
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_weekly_traffic_summary");
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_traffic_weekly


    /**
     * @param $fetchdata
     * @return mixed
     */
    public function insert_chargeback($fetchdata)
    {
        $this->db->insert_batch($this->tbl_stage_daily_chargebacks, $fetchdata);
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function insert_chargeback

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_date_chargeback($vendor_id)
    {
        $this->db->select('creation_date AS Chargeback_Date, COUNT(`id`) AS Repeated_Record');
        $this->db->from("tbl_stage_daily_chargebacks");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`fk_vendor_id`,`issue_id`');
        $this->db->having('Repeated_Record >', 1);
        $this->db->distinct();
        $this->db->order_by('Chargeback_Date');
        return $this->db->get()->result();
    }//end function repeated_date_chargeback

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_for_chargeback($vendor_id)
    {
        $this->db->select('creation_date AS dates,Count(id) as cnt');
        $this->db->from("tbl_stage_daily_chargebacks");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('creation_date');
        return $this->db->get()->result();
    }//end function dates_for_chargeback

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function distinct_chargeback($vendor_id)
    {
        $this->db->select('COUNT(issue_id) AS No_of_Issues');
        $this->db->from("tbl_stage_daily_chargebacks");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('issue_id');
        return $this->db->get()->num_rows();
    }//end function distinct_chargeback

    /**
     * @return mixed
     */
    public function get_promotion_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_monthly_promotion_summary.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_monthly_promotion_summary', 'tbl_main_monthly_promotion_summary.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_promotion_last_entries

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_all_count_chargeback($vendor_id)
    {
        $this->db->from($this->tbl_stage_daily_chargebacks);
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_all_count_chargeback

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_ams($vendor_id)
    {
        $query = $this->db->query("call spETLAMS(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_ams

    
    /**
     * @return mixed
     */
    public function get_ams_campaigns_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_monthly_ams_campaigns.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_monthly_ams_campaigns', 'tbl_main_monthly_ams_campaigns.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_ams_campaigns_last_entries

    /**
     * @return mixed
     */
    public function get_ams_brands_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_monthly_ams_spbrand.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_monthly_ams_spbrand', 'tbl_main_monthly_ams_spbrand.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_ams_brands_last_entries

    /**
     * @return mixed
     */
    public function get_ams_products_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_monthly_ams_spproduct.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_monthly_ams_spproduct', 'tbl_main_monthly_ams_spproduct.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_ams_products_last_entries

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function update_ams_data($vendor_id)
    {
        $query = $this->db->query("call spEtlUpdateAMS(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function update_ams_data

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_chargeback($vendor_id)
    {
        $query = $this->db->query("call spEtlChargeback(?)", array($vendor_id));
        $return = $query->num_rows();
        return $return;
    }//end function move_to_main_chargeback

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_chargeback($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete($this->tbl_stage_daily_chargebacks);
    }//end function delete_chargeback

    /**
     * @param $fetchdata
     * @return mixed
     */
    public function insert_amscampaigns($fetchdata)
    {
        $this->db->trans_begin();
        $this->db->insert_batch($this->tbl_stage_monthly_ams_campaigns, $fetchdata);
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_amscampaigns

    /**
     * @param $fetchdata
     * @return mixed
     */
    public function insert_amsbrands($fetchdata)
    {
        $this->db->trans_begin();
        $this->db->insert_batch($this->tbl_stage_monthly_ams_campaigns, $fetchdata);
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_amsbrands

    /**
     * @param $fetchdata
     * @return mixed
     */
    public function insert_amsproducts($fetchdata)
    {
        $this->db->trans_begin();
        $this->db->insert_batch($this->tbl_stage_monthly_ams_campaigns, $fetchdata);
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_amsproducts

    /**
     * @param $InsertDataArray
     * @return bool
     */
    public function insert_amsData($InsertDataArray)
    {
        $this->db->trans_begin();
        if (!empty($InsertDataArray['CampaignData'])) {
            $this->db->insert_batch($this->tbl_stage_monthly_ams_campaigns, $InsertDataArray['CampaignData']);
        }//end if statment
        if (!empty($InsertDataArray['ProductsData'])) {
            $this->db->insert_batch($this->tbl_stage_monthly_ams_spproduct, $InsertDataArray['ProductsData']);
        }//end if statment
        if (!empty($InsertDataArray['brandData'])) {
            $this->db->insert_batch($this->tbl_stage_monthly_ams_spbrand, $InsertDataArray['brandData']);
        }//end if statment
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_amsData

    /**
     * @param $InsertDataArray
     * @return bool
     */
    public function insert_amsCampaign($InsertDataArray)
    {
        $this->db->trans_begin();
        $this->db->insert_batch($this->tbl_stage_monthly_ams_campaigns, $InsertDataArray);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_amsCampaign

    /**
     * @param $InsertDataArray
     * @return bool
     */
    public function insert_ams_product($InsertDataArray)
    {
        $this->db->trans_begin();
        $this->db->insert_batch($this->tbl_stage_monthly_ams_spproduct, $InsertDataArray);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_amsData

    /**
     * @param $InsertDataArray
     * @return bool
     */
    public function insert_ams_brand($InsertDataArray)
    {
        $this->db->trans_begin();
        $this->db->insert_batch($this->tbl_stage_monthly_ams_spbrand, $InsertDataArray);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_ams_brand

    /**
     * This is function is used to Delete AMS Record
     * @param $vendor_id
     */
    public function deleteAms($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete($this->tbl_stage_monthly_ams_campaigns);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete($this->tbl_stage_monthly_ams_spproduct);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete($this->tbl_stage_monthly_ams_spbrand);
    }//end function deleteAms

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_for_ams_campaigns($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(`campaigns`) AS cnt');
        $this->db->from('tbl_stage_monthly_ams_campaigns');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('start_date,"-",end_date');
        return $this->db->get()->result();
    }//end function dates_for_ams_campaigns

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_for_ams_brands($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(`portfolio_name`) AS cnt');
        $this->db->from('tbl_stage_monthly_ams_spbrand');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('start_date,"-",end_date');
        return $this->db->get()->result();
    }//end function dates_for_ams_brands

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_for_ams_products($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(`advertised_asin`) AS cnt');
        $this->db->from('tbl_stage_monthly_ams_spproduct');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('start_date,"-",end_date');
        return $this->db->get()->result();
    }//end function dates_for_ams_products

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_all_count_amscampaign($vendor_id)
    {
        $this->db->select('COUNT(`c_id`) AS count');
        $this->db->from("tbl_stage_monthly_ams_campaigns");
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->get()->row()->count;
    }//end function get_all_count_amscampaign

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_all_count_amsbrand($vendor_id)
    {
        $this->db->select('COUNT(`c_id`) AS count');
        $this->db->from("tbl_stage_monthly_ams_spbrand");
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->get()->row()->count;
    }//end function get_all_count_amsbrand

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_all_count_amsproduct($vendor_id)
    {
        $this->db->select('COUNT(`c_id`)  AS count');
        $this->db->from("tbl_stage_monthly_ams_spproduct");
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->get()->row()->count;
    }//end function get_all_count_amsproduct

    /**
     * @param $fetchdata
     * @return mixed
     */
    public function insert_sale_sptp($fetchdata)
    {
        $this->db->insert_batch('tbl_stage_sales_ptp_forecast', $fetchdata);
        return $this->db->insert_id();
    }//end function insert_sale_sptp

    /**
     * @return mixed
     */
    public function get_all_categories()
    {
        $this->db->select('asin, category');
        $this->db->from("tbl_asin_sales_category");
        return $this->db->get()->result_array();
    }//end function get_all_categories

    /**
     * @param $data
     * @return bool
     */
    public function insert_powerbi_roles($data)
    {
        $array = [
            'email' => $data['email']
        ];
        $response = $this->db->get_where($this->tbl_powerbi_roles, $array)->row_array();
        if ($response['is_manager'] != 1) {
            $ExistValue = $this->db->get_where($this->tbl_powerbi_roles, $array);
            if ($ExistValue->num_rows() == 0) {
                $this->db->insert($this->tbl_powerbi_roles, $data);
                return true;
            }//end if statment
        }//end if statment
    }//end function insert_powerbi_roles
	
	

    /**
     * @param $db_data
     * @param $vendor_idPost
     * @param $date
     */
    public function insert_dinventory($db_data, $vendor_idPost, $date)
    {
        $this->db->trans_begin();
        // written BY ABDUL WAQAR reason insertion time reduce
        $this->db->insert_batch($this->tbl_stage_daily_inventory, $db_data);
        // update Subcategory On BASES of ASIN
        $this->db->select('dinventory.asin,cat.category as subcategory');
        $this->db->from($this->tbl_stage_daily_inventory . ' as dinventory');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = dinventory.asin');
        $this->db->where('dinventory.rec_date', $date);
        $this->db->where('dinventory.fk_vendor_id', $vendor_idPost);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_stage_daily_inventory, $dataArray, 'asin');
        }//end if statment
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_dinventory

    /**
     * @param $db_data
     * @return mixed
     */
    public function insert_winventory($db_data, $vendor_idPost, $start_date, $end_date)
    {
        $this->db->trans_begin();

        $this->db->insert_batch($this->tbl_stage_weekly_inventory, $db_data);
        // update Subcategory On BASES of ASIN
        $this->db->select('winventory.asin,cat.category as subcategory');
        $this->db->from($this->tbl_stage_weekly_inventory . ' as winventory');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = winventory.asin');
        $this->db->where('winventory.start_date', $start_date);
        $this->db->where('winventory.end_date', $end_date);
        $this->db->where('winventory.fk_vendor_id', $vendor_idPost);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_stage_weekly_inventory, $dataArray, 'asin');
        }//end if statment
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_winventory

    /**
     * @param $db_data
     * @return mixed
     */
    public function insert_minventory($db_data, $vendor_idPost, $start_date, $end_date)
    {

        $this->db->trans_begin();

        $this->db->insert_batch($this->tbl_stage_monthly_inventory, $db_data);
        // update Subcategory On BASES of ASIN
        $this->db->select('minventory.asin,cat.category as subcategory');
        $this->db->from($this->tbl_stage_monthly_inventory . ' as minventory');
        $this->db->join($this->tbl_asin_sales_category . ' as cat', 'cat.asin = minventory.asin');
        $this->db->where('minventory.start_date', $start_date);
        $this->db->where('minventory.end_date', $end_date);
        $this->db->where('minventory.fk_vendor_id', $vendor_idPost);
        $dataArray = $this->db->get()->result_array();
        if (!empty($dataArray)) {
            // update record bulk vise
            $this->db->update_batch($this->tbl_stage_monthly_inventory, $dataArray, 'asin');
        }//end if statment
        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {//when transaction status is TRUE
            $this->db->trans_commit();
        }//end if statment
    }//end function insert_minventory

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_daily_inventory($vendor_id)
    {
        $this->db->select('rec_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_daily_inventory");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`asin`,`rec_date`,`fk_vendor_id`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_daily_inventory

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_daily_inventory($vendor_id)
    {
        $this->db->select('rec_date AS dates, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_daily_inventory");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('rec_date');
        return $this->db->get()->result();
    }//end function dates_daily_inventory

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_weekly_inventory($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_weekly_inventory");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by(' `asin`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_weekly_inventory

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_weekly_inventory($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(`asin`) AS cnt');
        $this->db->from('tbl_stage_weekly_inventory');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('start_date,"-",end_date');
        return $this->db->get()->result();
    }//end function dates_weekly_inventory

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_monthly_inventory($vendor_id)
    {
        $this->db->select('start_date,"-",end_date, COUNT(`asin`) AS cnt');
        $this->db->from("tbl_stage_monthly_inventory");
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by(' `asin`,`fk_vendor_id`,`start_date`,`end_date`');
        $this->db->having('cnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_monthly_inventory

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function dates_monthly_inventory($vendor_id)
    {
        $this->db->select('`start_date`,"-",`end_date`, COUNT(`asin`) AS cnt');
        $this->db->from('tbl_stage_monthly_inventory');
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('start_date,"-",end_date');
        return $this->db->get()->result();
    }//end function dates_monthly_inventory

    /**
     * @param $vendor_id
     * @param $date
     * @return mixed
     */
    public function delete_inventory_daily($vendor_id, $date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('rec_date', $date);
        $this->db->delete("tbl_stage_daily_inventory");
        //http://jira.codeinformatics.com/browse/TANA-102
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_inventory_daily

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_inventory_weekly($vendor_id, $s_date, $e_date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_weekly_inventory");
        //http://jira.codeinformatics.com/browse/TANA-102
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_inventory_weekly

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_inventory_monthly($vendor_id, $s_date, $e_date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        $this->db->delete("tbl_stage_monthly_inventory");
        //http://jira.codeinformatics.com/browse/TANA-102
        if ($this->db->affected_rows() > 0) {
            return true;
        }//end if statment
        return false;
    }//end function delete_inventory_monthly

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function move_to_main_inventory($vendor_id)
    {
        $query = $this->db->query("call spEtlInventory(?)", array($vendor_id));
        $return = $query->num_rows();
        return true;
    }//end function move_to_main_inventory

    /**
     * @return mixed
     */
    public function get_inventory_daily_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_daily_inventory.rec_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_daily_inventory', 'tbl_main_daily_inventory.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_inventory_daily_last_entries

    /**
     * @return mixed
     */
    public function get_inventory_weekly_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_weekly_inventory.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_weekly_inventory', 'tbl_main_weekly_inventory.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_inventory_weekly_last_entries

    /**
     * @return mixed
     */
    public function get_inventory_monthly_last_entries()
    {
        $this->db->select('tbl_purchaseorders_vendors.vendor_id, tbl_purchaseorders_vendors.vendor_name, tbl_purchaseorders_vendors.domain , MAX(tbl_main_monthly_inventory.start_date) as date');
        $this->db->from('tbl_purchaseorders_vendors');
        $this->db->join('tbl_main_monthly_inventory', 'tbl_main_monthly_inventory.fk_vendor_id = tbl_purchaseorders_vendors.vendor_id','left');
        $this->db->group_by('tbl_purchaseorders_vendors.vendor_id');
        $this->db->order_by('tbl_purchaseorders_vendors.vendor_name');
        return $this->db->get()->result();
    }//end function get_inventory_monthly_last_entries

    public function deleteAllInventorySpecificVendor($vendor_id)
    {
        $responseDailyInventory = 0;
        $responseWeeklyInventory = 0;
        $responseMonthInventory = 0;
        // delete daily inventory
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete($this->tbl_stage_daily_inventory);
        if ($this->db->affected_rows() > 0) {
            $responseDailyInventory = 1;
        }//end if statment
        // Delete weekly inventory
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete($this->tbl_stage_weekly_inventory);
        if ($this->db->affected_rows() > 0) {
            $responseWeeklyInventory = 1;
        }//end if statment
        // Delete monthly inventory
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->delete($this->tbl_stage_monthly_inventory);
        if ($this->db->affected_rows() > 0) {
            $responseMonthInventory = 1;
        }//end if statment

        if ($responseDailyInventory > 0 || $responseWeeklyInventory > 0 || $responseMonthInventory > 0) {
            return $data = array(
                'DailyInventory' => $responseDailyInventory,
                'WeeklyInventory' => $responseWeeklyInventory,
                'MonthyInventory' => $responseMonthInventory
            );
        } else {
            return false;
        }//end if statment 

    }//end function deleteAllInventorySpecificVendor

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_indaily_count($vendor_id)
    {
        $this->db->from("tbl_stage_daily_inventory");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_indaily_count

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_inweekly_count($vendor_id)
    {
        $this->db->from("tbl_stage_weekly_inventory");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_inweekly_count

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_inmonthly_count($vendor_id)
    {
        $this->db->from("tbl_stage_monthly_inventory");
        $this->db->where('fk_vendor_id', $vendor_id);
        $query = $this->db->get();
        $rowcount = $query->num_rows();
        return $rowcount;
    }//end function get_inmonthly_count

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_weeksumm($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete("tbl_stage_weekly_sales_summary");
    }//end function delete_weeksumm

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function delete_monsumm($vendor_id)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        return $this->db->delete("tbl_stage_monthly_sales_summary");
    }//end function delete_monsumm

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_summary_weekly($vendor_id, $s_date, $e_date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        return $this->db->delete("tbl_stage_weekly_sales_summary");
    }//end function delete_summary_weekly

    /**
     * @param $vendor_id
     * @param $s_date
     * @param $e_date
     * @return mixed
     */
    public function delete_summary_monthly($vendor_id, $s_date, $e_date)
    {
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->where('start_date', $s_date);
        $this->db->where('end_date', $e_date);
        return $this->db->delete("tbl_stage_monthly_sales_summary");
    }//end function delete_summary_monthly

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_dates_recordsc($vendor_id)
    {
        $this->db->select('start_date,end_date,, COUNT(`campaigns`) AS campaignsCnt, COUNT(`type`) AS typeCnt, COUNT(`status`) AS statuCnt, COUNT(`portfolio`) AS portfolioCnt');
        $this->db->from($this->tbl_stage_monthly_ams_campaigns);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`fk_vendor_id`,`campaigns`,`type`,portfolio,targeting,start_date,end_date');
        $this->db->having('campaignsCnt  >', 1);
        $this->db->having('typeCnt  >', 1);
        $this->db->having('statuCnt  >', 1);
        $this->db->having('portfolioCnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_dates_recordsc

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_dates_recordsb($vendor_id)
    {
        $this->db->select('start_date,end_date,, COUNT(`campaign_name`) AS campaignsCnt, COUNT(`match_type`) AS typeCnt, COUNT(`targeting`) AS statuCnt, COUNT(`portfolio_name`) AS portfolioCnt');
        $this->db->from($this->tbl_stage_monthly_ams_spbrand);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`fk_vendor_id`,`campaign_name`,`match_type`,portfolio_name,targeting,start_date,end_date');
        $this->db->having('campaignsCnt  >', 1);
        $this->db->having('typeCnt  >', 1);
        $this->db->having('statuCnt  >', 1);
        $this->db->having('portfolioCnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_dates_recordsb

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function repeated_dates_recordsp($vendor_id)
    {
        $this->db->select('`start_date`,
        `end_date`,COUNT(`campaign_name`) AS campaignsCnt, COUNT(`advertised_asin`) AS advertised_asinCnt,
        COUNT(`portfolio_name`) AS portfolioCnt');
        $this->db->from($this->tbl_stage_monthly_ams_spproduct);
        $this->db->where('fk_vendor_id', $vendor_id);
        $this->db->group_by('`fk_vendor_id`,`campaign_name`,`advertised_asin`,portfolio_name,start_date,end_date');
        $this->db->having('campaignsCnt  >', 1);
        $this->db->having('advertised_asinCnt  >', 1);
        $this->db->having('portfolioCnt  >', 1);
        $this->db->distinct();
        return $this->db->get()->result();
    }//end function repeated_dates_recordsp

    /**
     * @param $data
     * @param $report
     * @return mixed
     */
    public function insert_ftp_file_data($data)
    {
        $this->db->trans_start();
        $this->db->insert_batch($data['table'], $data['data']);
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
            $this->db->trans_rollback();
            $result = false;
        }else{//when transaction Status is TRUE
            $this->db->trans_commit();
            $result = true;
        }//end if statment
        return $result;
    }//end function insert_weekly_forecast


    /**
     * @param $response
     * @return mixed
     */
    public function insert_ftp_meta_data($response)
    {
        $this->db->trans_start();
        $this->db->insert_batch("tbl_ftp_metadata", $response);
        $this->db->trans_complete();

        $result = "";
        if ($this->db->trans_status() === FALSE)
        {
            $this->db->trans_rollback();
            $result = false;
        }else{//when transaction Status is TRUE
            $this->db->trans_commit();
            $result = true;
        }//end if statment
        return $result;
    }//end function insert_ftp_meta_data

    /**
     * @param $vendor_id
     * @return mixed
     */
    public function get_ftp_meta_data()
    {
        $this->db->select('report,report_data_granularity,report_type,vendor_name,original_file_name,report_date,status,file_status,capture_date');
        $this->db->from("tbl_ftp_metadata");
        $this->db->order_by("capture_date", "DESC");
        return $this->db->get()->result();
    }//end function repeated_dates_recordsp

}//end class
