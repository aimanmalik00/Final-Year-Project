<!DOCTYPE html>
<html lang="en">
<head>
  <?php $this->load->view('admin/includes/header'); ?>
  <?php $this->load->view('admin/includes/header_files');?>

</head>

<body class="bg-gradient-primary">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-8 col-md-6">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-12">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Welcome</h1>
                  </div>
				  
				  <!-- BEGIN LOGIN FORM -->
				<?php echo form_open('admin',array('name'=>'login-form','id'=>'login-form','class'=>'user','method'=>'post')); ?>
				
				<?php if(isset($error_msg)){ ?>
							<div class="alert alert-danger"><?php echo $error_msg;?></div>
				<?php }?>
					
					<div class="form-group">
                      <input type="text" class="form-control form-control-user" id="username" name="username" aria-describedby="emailHelp" placeholder="Enter username...">
                    </div>
						
					<div class="form-group">
                      <input type="password" class="form-control form-control-user" id="password" name="password" aria-describedby="emailHelp" placeholder="Enter password...">
                    </div>
						
					<div class="form-actions">
						<?php echo form_submit('btn_submit', 'Login',array('class' => 'btn btn-system btn-user btn-block' ,'type' =>'submit', 'id' => 'btn_submit')); ?>
					</div>
					<?php echo form_close(); ?>
				  
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo base_url('/assets/vendor/jquery/jquery.min.js')?>"></script>
  <script src="<?php echo base_url('/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url('/assets/vendor/jquery-easing/jquery.easing.min.js')?>"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo base_url('/assets/js/sb-admin-2.min.js')?>"></script>
    <script>
   var FormValidation = function () {

	   // basic validation
			var handleValidation1 = function() {
				// for more info visit the official plugin documentation:
				// http://docs.jquery.com/Plugins/Validation

				var form1 = $('#login-form');
				var error1 = $('.alert-danger', form1);
				var success1 = $('.alert-success', form1);

				form1.validate({
					errorElement: 'span', //default input error message container
					errorClass: 'help-block help-block-error', // default input error message class
					focusInvalid: false, // do not focus the last invalid input
					ignore: "",  // validate all fields including form hidden input
					messages: {
						select_multi: {
							maxlength: jQuery.validator.format("Max {0} items allowed for selection"),
							minlength: jQuery.validator.format("At least {0} items must be selected")
						}
					},
					rules: {
						username: {
							minlength: 2,
							required: true
						},
						password: {
							required: true,
							minlength: 2
						}
					},

					invalidHandler: function (event, validator) { //display error alert on form submit
						success1.hide();
						error1.show();
						App.scrollTo(error1, -200);
					},

					highlight: function (element) { // hightlight error inputs
						$(element)
							.closest('.form-group').addClass('has-error'); // set error class to the control group
					},

					unhighlight: function (element) { // revert the change done by hightlight
						$(element)
							.closest('.form-group').removeClass('has-error'); // set error class to the control group
					},

					success: function (label) {
						label
							.closest('.form-group').removeClass('has-error'); // set success class to the control group
					},

					submitHandler: function (form) {
						alert('kasgdghd');
						success1.show();
						error1.hide();
						form.submit();

					}
				});

				$('.login-form input').keypress(function(e) {
					if (e.which == 13) {
						if ($('.login-form').validate().form()) {
							$('.login-form').submit(); //form validation success, call ajax form submit
						}
						return false;
					}
				});


			}
			return {
				//main function to initiate the module
				init: function () {

					handleValidation1();

				}

			};

		}();

		$(document).ready(function() {
			FormValidation.init();
		});
</script>

</body>

</html>






