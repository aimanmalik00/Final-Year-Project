<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-2 text-gray-800">Vendor Information</h1>
			<a href="#" class=" d-none d-sm-inline-block btn btn-system shadow-sm" data-toggle="modal" data-target="#AddVendorModal" >
                 <i class="fas fa-plus fa-sm text-white-100"></i> Add New Vendor
                </a>
          </div>
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">
				<?php if ($this->session->flashdata('success_msg')) { ?>
					<div class="alert alert-success">
						<?php echo $this->session->flashdata('success_msg'); ?>
					</div>
				<?php } ?>
				<?php if ($this->session->flashdata('error_msg')) { ?>
					<div class="alert alert-danger">
						<?php echo $this->session->flashdata('error_msg'); ?>
					</div>
				<?php } ?>

          <!-- Vendor Table Div -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-system">List of All Vendor</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th width="10%">Vendor ID</th>
                      <th>Vendor Name</th>
                      <th>Domain</th>
					  <th>Tier</th>
					  <th>Vendor Status</th>
					  <th>Action</th>
					  
                    </tr>
                  </thead>
                  <tbody>
				  <?php foreach($vendor as $row){?>
                    <tr>
                      <td>#<?php echo($row->vendor_id); ?></td>
                      <td><?php echo($row->vendor_name); ?></td>
                      <td><?php echo($row->domain); ?></td>
					  <td><?php echo($row->tier); ?></td>
                      <td>
						<?php if($row->vendor_status){
							echo "Active";
						}else{
							echo "InActive";
						} ?>
					  </td>
					  <td>
						<button  class="btn btn-info btn-circle btn-sm" id="vendor_edit" title="Edit Vendor Information" data-id="<?php echo($row->vendor_id); ?>"  data-name="<?php echo($row->vendor_name); ?>" data-tier="<?php echo($row->tier); ?>" data-domain="<?php echo($row->domain); ?>" data-toggle="modal" data-target="#UpdateVendorModal" >
							<i class="fa fa-edit"></i> 
						</button>
						<?php if($row->vendor_status){
						?>
							<button  class="btn btn-danger  btn-circle  btn-sm" id="inactivate_vendor" title="Inactivate Vendor Status" data-id="<?php echo($row->vendor_id); ?>" data-toggle="modal" data-target="#InactivateVendorModal" >
								<i class="fa fa-times"></i> 
							</button>
						<?php
						}else{
						?>
							<button  class="btn btn-info btn-circle  btn-sm" id="activate_vendor"  title="Activate Vendor Status" data-id="<?php echo($row->vendor_id); ?>" data-toggle="modal" data-target="#ActivateVendorModal" >
								<i class="fa fa-check"></i> 
							</button>
						<?php
						} ?>
						 
						 
					  </td>
                    </tr>
				  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

            </div>            
          </div>

        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		<script>
			$("document").ready(function () {
				$(document).on('click','#vendor_edit',function(){
					var Vendor_ID =  $(this).attr('data-id');
					var name =  $(this).attr('data-name');
					var domain =  $(this).attr('data-domain');
					var tier =  $(this).attr('data-tier');

					$('#update_vendor_id').val(Vendor_ID);
					$('#update_vendor_name').val(name);
					$('#update_vendor_domain').val(domain);
					$('#update_vendor_tier').val(tier);
				});
				
				$(document).on('click','#inactivate_vendor',function(){
					var Vendor_ID =  $(this).attr('data-id');
					$('#inactivate_vendor_id').val(Vendor_ID);
				});
				
				$(document).on('click','#activate_vendor',function(){
					var Vendor_ID =  $(this).attr('data-id');
					$('#activate_vendors_id').val(Vendor_ID);
				});
				
				$("#popup").submit(function (e) {
					//disable the submit button
					$(".uploadbtn").attr("disabled", true);
				});
				setTimeout(function () {
					$("div.alert").remove();
				}, 5000); // 5 secs
				
				
			});
			
			$(".custom-file-input").on("change", function() {
				  var fileName = $(this).val().split("\\").pop();
				  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
				});
		</script>
      <!-- End of Footer Files -->

	  <!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->
	  
	  <!-- Add Vendor Modal -->
	<div class="modal fade" id="AddVendorModal" tabindex="-1" role="dialog" aria-labelledby="AddVendorModal" aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-body">
			<!--  Form Area -->
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-system">Add New Vendor to system</h6>
				</div>
				<div class="card-body">
				<?php echo form_open('admin/admin/vendor', array('name' => 'popup', 'id' => 'popup', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
				<div class="form-group">
					<label class="control-label" for="lname">First Name</label>
					<input class="form-control" id="fname" name="lname" value="ReportingBI" readonly required>
				</div>
				<div class="form-group">
					<label class="control-label" for="lname">Last Name</label>
					<input class="form-control" id="lname" name="lname" value="Tana" readonly required>
				</div>
				<div class="form-group">
					<label class="control-label" for="email">Email</label>
					<input type="email" class="form-control" id="email" name="email" value="reportingbi@tanasales.com" readonly   required>
				</div>
				<div class="form-group">
					<label class="control-label" for="vendor">Vendor</label>
					<input type="text" class="form-control" id="vendor" name="vendor" placeholder="Enter Vendor e.g Arctix - US" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="domain">Domain</label>
					<input type="text" class="form-control" id="domain" name="domain" placeholder="Enter domain e.g US" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="tier">Tier</label>
					<input type="text" class="form-control" id="tier" name="tier" placeholder="Enter Tier e.g Platinum" required>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Add Vendor</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
				</div>
				
				<?php echo form_close(); ?>
				<!-- End Form -->

				</div>
		  </div>
		</div>
	  </div>
	</div>
	  
	  <!-- Udapte Vendor Modal -->
	<div class="modal fade" id="UpdateVendorModal" tabindex="-1" role="dialog" aria-labelledby="UpdateVendorModal" aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-body">
			<!--  Form Area -->
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-system">Update Vendor Information</h6>
				</div>
				<div class="card-body">
				<?php echo form_open('admin/admin/setVendor', array('name' => 'popup', 'id' => 'popup', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
				<div class="form-group">
					<input type="text" class="form-control" id="update_vendor_id" name="update_vendor_id" hidden required>
				</div>
				<div class="form-group">
					<label class="control-label" for="vendor">Vendor Name</label>
					<input type="text" class="form-control" id="update_vendor_name" name="update_vendor_name" placeholder="Enter Vendor e.g Arctix - US" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="domain">Domain</label>
					<input type="text" class="form-control" id="update_vendor_domain" name="update_vendor_domain" placeholder="Enter domain e.g US" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="tier">Tier</label>
					<input type="text" class="form-control" id="update_vendor_tier" name="update_vendor_tier" placeholder="Enter Tier e.g Platinum" required>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Save</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
				</div>
				
				<?php echo form_close(); ?>
				<!-- End Form -->

				</div>
		  </div>
		</div>
	  </div>
	</div>
	
	<!-- Inactive Vendor Modal -->
	<div class="modal fade" id="InactivateVendorModal" tabindex="-1" role="dialog" aria-labelledby="InactivateVendorModal" aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-body">
			<!--  Form Area -->
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-system">Inactivate Vendor Status </h6>
				</div>
				<div class="card-body">
				<?php echo form_open('admin/admin/inactivateVendor', array('name' => 'popup', 'id' => 'popup', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
				<div class="form-group">
					<input type="text" class="form-control" id="inactivate_vendor_id" name="inactivate_vendor_id" hidden required>
					<p>You are going to Inactivate this vendor. Are you sure? </p>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Inactivate Vendor</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
				</div>
				
				<?php echo form_close(); ?>
				<!-- End Form -->

				</div>
		  </div>
		</div>
	  </div>
	</div>
	
	<!-- Activate Vendor Modal -->
	<div class="modal fade" id="ActivateVendorModal" tabindex="-1" role="dialog" aria-labelledby="ActivateVendorModal" aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-body">
			<!--  Form Area -->
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-system">Activate Vendor Information </h6>
				</div>
				<div class="card-body">
				<?php echo form_open('admin/admin/activateVendor', array('name' => 'popup', 'id' => 'popup', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
				<div class="form-group">
					<input type="text" class="form-control" id="activate_vendors_id" name="activate_vendors_id" hidden required>
					<p>You are going to Activate this vendor. Are you sure? </p>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Activate Vendor</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
				</div>
				
				<?php echo form_close(); ?>
				<!-- End Form -->

				</div>
		  </div>
		</div>
	  </div>
	</div>
	
</body>

</html>



