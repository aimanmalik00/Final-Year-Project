<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
//echo $controller_name; die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Verify Brand Store Data Against Different Vendors</h1>
        
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-8 col-lg-7">

              <!-- Vendor Dropdown for Records Verification -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Verify Records</h6>
                </div>
                <div class="card-body">
					<!-- Standar Form -->
					<h4>Select Vendor</h4>
				   <?php echo form_open(current_url(),array('name'=>'popup','id'=>'popup', 'class'=>'form-horizontal', 'method'=>'post', 'enctype'=>"multipart/form-data" )); ?>
					<?php if($this->session->flashdata('success_msg')) { ?>
						<div class="alert alert-success">
							<?php echo $this->session->flashdata('success_msg'); ?>
						</div>
					<?php } ?>
					<?php if($this->session->flashdata('error_msg')) { ?>
						<div class="alert alert-danger">
							<?php echo $this->session->flashdata('error_msg'); ?>
						</div>
					<?php } ?>
					<?php if(isset($error_msg)){ ?>
						<div class="alert alert-danger"><?php echo $error_msg;?></div>
					<?php }?>
					<?php 
						$vendor_id=0;
						if ($this->session->flashdata('vendor_id')) { $vendor_id = $this->session->flashdata('vendor_id'); } 
					?>
					<div class="input-group">
					  <select class="form-control" name="fk_vendor_id">
								<?php foreach ($vendors as $row){ ?>
									<option value="<?php echo $row->vendor_id; ?>" <?php
									if($this->session->has_userdata('fk_vendor_id') || $vendor_id != 0 ){
										echo (($row->vendor_id == $_SESSION['fk_vendor_id'] || $row->vendor_id == $vendor_id )? 'selected' : '');
									}
									?>
									>
										<?php echo $row->vendor_name .' '. $row->domain ; ?></option>
								<?php }?>
							</select>
					  <div class="input-group-append">
						<button type="submit" class="btn btn-system"  ><i class="fas fa-search fa-sm"></i> Refresh</button>
					  </div>
					</div>
					<?php echo form_close(); ?>
                </div>
              </div>
			 
			
			  <div class="row">

				<!-- Page Records -->
				<div class="col-xl-4 col-md-6 mb-4">
				  <div class="card border-left-success shadow h-100 py-2">
					<div class="card-body">
					  <div class="row no-gutters align-items-center">
						<div class="col mr-2">
						  <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Page Records</div>
						  <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $countt_bypage; ?></div>
						</div>
					  </div>
					</div>
				  </div>
				</div>

				<!-- Source Records -->
				<div class="col-xl-4 col-md-6 mb-4">
				  <div class="card border-left-info shadow h-100 py-2">
					<div class="card-body">
					  <div class="row no-gutters align-items-center">
						<div class="col mr-2">
						  <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Source Records</div>
						  <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $countt_bysource; ?></div>
						</div>
					  </div>
					</div>
				  </div>
				</div>

				<!-- Date Record -->
				<div class="col-xl-4 col-md-6 mb-4">
				  <div class="card border-left-danger shadow h-100 py-2">
					<div class="card-body">
					  <div class="row no-gutters align-items-center">
						<div class="col mr-2">
						  <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Date Records</div>
						  <div class="row no-gutters align-items-center">
							<div class="col-auto">
							  <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo($countt_bydate) ; ?></div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				</div>

			  </div>
			  
			  <!--  Repeated Record -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-danger">Repeated Records</h6>
                </div>
                <div class="card-body">
				<div class="container">
				 <nav>
				  <div class="nav nav-tabs" id="nav-tab" role="tablist">
					<a class="nav-item nav-link active" id="nav-menu1-tab" data-toggle="tab" href="#nav-menu1" role="tab" aria-controls="nav-menu1" aria-selected="true">By Page</a>
					<a class="nav-item nav-link" id="nav-menu2-tab" data-toggle="tab" href="#nav-menu2" role="tab" aria-controls="nav-menu2" aria-selected="false">By Source</a>
					<a class="nav-item nav-link" id="nav-menu3-tab" data-toggle="tab" href="#nav-menu3" role="tab" aria-controls="nav-menu3" aria-selected="false">By Date</a>
				  </div>
				</nav>
				<div class="tab-content" id="nav-tabContent">
				  <div class="tab-pane fade show active" id="nav-menu1" role="tabpanel" aria-labelledby="nav-menu1-tab"><br/>
				   <h5>Repeated Record for Brand Store by Page</h5>
					<div class="table-responsive">
						<table  class="table" id="dataTable"  cellspacing="0">
							<thead>
								 <tr>
									<th>Date</th>
									<th>Records</th>
								 </tr>
							  </thead>
								<tbody>
								<?php foreach ($repeated_dates_brandstore_bypage as $dates) { ?>
									<tr>
										<td><?php echo $dates->start_date.' - '.$dates->end_date;  ?></td>
										<td><?php echo $dates->cnt ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
					  </div>
				  </div>
				  <div class="tab-pane fade" id="nav-menu2" role="tabpanel" aria-labelledby="nav-menu2-tab"><br/>
				   <h5>Repeated Record for Brand Store by Source</h5>
					<div class="table-responsive">
						<table class="table" id="dataTable1" width="100%" cellspacing="0">
								<thead>
									 <tr>
										<th>Date</th>
										<th>Records</th>
									 </tr>
								  </thead>
								<tbody>
								<?php foreach ($repeated_dates_brandstore_bysource as $dates) { ?>
									<tr>
										<td><?php echo $dates->start_date.' - '.$dates->end_date;  ?></td>
										<td><?php echo $dates->cnt ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
					  </div>
				  </div>
				  <div class="tab-pane fade" id="nav-menu3" role="tabpanel" aria-labelledby="nav-menu3-tab"><br/>
					 <h5>Repeated Record for Brand Store by Date</h5>
					<div class="table-responsive">
						<table class="table" id="dataTable2" width="100%" cellspacing="0">
								<thead>
									 <tr>
										<th>Date</th>
										<th>Records</th>
									 </tr>
								  </thead>
								<tbody>
								<?php foreach ($repeated_dates_brandstore_bydate as $dates) { ?>
									<tr>
										<td><?php echo $dates->start_date.' - '.$dates->end_date;  ?></td>
										<td><?php echo $dates->cnt ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
					  </div>
				  </div>
				</div>
				</div>
                </div>
              </div>

			  <!--  Available Record -->
			  <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-info">Available Records</h6>
                </div>
                <div class="card-body">
				<div class="container">
				 <nav>
				  <div class="nav nav-tabs" id="nav-tab" role="tablist">
					<a class="nav-item nav-link active" id="nav-menu01-tab" data-toggle="tab" href="#nav-menu01" role="tab" aria-controls="nav-menu01" aria-selected="true">By Page</a>
					<a class="nav-item nav-link" id="nav-menu02-tab" data-toggle="tab" href="#nav-menu02" role="tab" aria-controls="nav-menu02" aria-selected="false">By Source</a>
					<a class="nav-item nav-link" id="nav-menu03-tab" data-toggle="tab" href="#nav-menu03" role="tab" aria-controls="nav-menu03" aria-selected="false">By Date</a>
				  </div>
				</nav>
				<div class="tab-content" id="nav-tabContent">
				  <div class="tab-pane fade show active" id="nav-menu01" role="tabpanel" aria-labelledby="nav-menu01-tab"><br/>
				   <h5>All Available Records for Brand Store by Page</h5>
					<div class="table-responsive">
						<table class="table" id="dataTable3" width="100%" cellspacing="0">
								<thead>
									 <tr>
										<th>Date</th>
										<th>Records</th>
									 </tr>
								  </thead>
								<tbody>
								<?php foreach ($date_brandstore_bypage as $dated) { ?>
									<tr>
										<td><?php echo $dated->start_date.' - '.$dated->end_date;  ?></td>
										<td><?php echo $dated->cnt ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
					  </div>
				  </div>
				  <div class="tab-pane fade" id="nav-menu02" role="tabpanel" aria-labelledby="nav-menu02-tab"><br/>
				   <h5>All Available Records for Brand Store by Source</h5>
					<div class="table-responsive">
						<table class="table" id="dataTable4" width="100%" cellspacing="0">
								<thead>
									 <tr>
										<th>Date</th>
										<th>Records</th>
									 </tr>
								  </thead>
								<tbody>
								<?php foreach ($date_brandstore_bysource as $dated) { ?>
									<tr>
										<td><?php echo $dated->start_date.' - '.$dated->end_date; ?></td>
                                        <td><?php echo $dated->cnt; ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
					  </div>
				  </div>
				  <div class="tab-pane fade" id="nav-menu03" role="tabpanel" aria-labelledby="nav-menu03-tab"><br/>
					 <h5>All Available Records for Brand Store by Date</h5>
					<div class="table-responsive">
						<table class="table" id="dataTable5" width="100%" cellspacing="0">
								<thead>
									 <tr>
										<th>Date</th>
										<th>Records</th>
									 </tr>
								  </thead>
								<tbody>
								<?php foreach ($date_brandstore_bydate as $dated) { ?>
									<tr>
										<td><?php echo $dated->start_date.' - '.$dated->end_date;  ?></td>
                                        <td><?php echo $dated->cnt; ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
					  </div>
				  </div>
				</div>
                </div>
				</div>
              </div>
			 
            </div>

            <!-- Donut Chart -->
            <div class="col-xl-4 col-lg-5">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Move or Delete Records</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
					
					<a id="alert" class="btn btn-primary btn-lg btn-block" href="<?php echo base_url('admin/reports/move_to_main_brandstore'); ?>" title="You should only click this button when all records are verified. It will move the records to the main table">Move To Main</a>
                    <a id="alert1" class="btn btn-danger btn-lg btn-block" href="<?php echo base_url('admin/reports/delete_brandstore'); ?>" title="It will delete all records of that vendor, should only be clicked when records are incorrect" name="delete">Delete Records</a>
                </div>
              </div>
			  <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Operations</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                 	
				<?php echo form_open('admin/reports/delete_brandstore_bypage_weekly',array('name'=>'popup','id'=>'popup', 'class'=>'form-horizontal', 'method'=>'post', 'enctype'=>"multipart/form-data" )); ?>
				<label for="date_selected" >Delete Selected Page Records weekly</label>
				<div class="input-group">
					<input type="text" class="form-control" name="datefilter" value="<?php echo date('m/d/Y').' - '.date('m/d/Y'); ?>" required readonly />
				</div>
				<br>
				<div class="panel-body">
				   <input type="submit" id="alert3" class="btn btn-system" title="It will delete all records of that vendor, should only be clicked when records are incorrect" value="Delete Records">
				</div>
				<?php echo form_close(); ?>
			
				<hr/>
				
				<?php echo form_open('admin/reports/delete_brandstore_bysource_weekly',array('name'=>'popup','id'=>'popup', 'class'=>'form-horizontal', 'method'=>'post', 'enctype'=>"multipart/form-data" )); ?>
				<label for="date_selected" >Delete Selected Source Records weekly</label>
				<div class="input-group">
					<input type="text" class="form-control" name="datefilter1" value="<?php echo date('m/d/Y').' - '.date('m/d/Y'); ?>" required readonly />
				</div>
				<br>
				<div class="panel-body">
				   <input type="submit" id="alert3" class="btn btn-system" title="It will delete all records of that vendor, should only be clicked when records are incorrect" value="Delete Records">
				</div>
				<?php echo form_close(); ?>
				<hr/>
				<?php echo form_open('admin/reports/delete_brandstore_bydate_weekly',array('name'=>'popup','id'=>'popup', 'class'=>'form-horizontal', 'method'=>'post', 'enctype'=>"multipart/form-data" )); ?>
				<label for="date_selected" >Delete Selected Page Records weekly</label>
				<div class="input-group">
					<input type="text" class="form-control" name="datefilter2" value="<?php echo date('m/d/Y').' - '.date('m/d/Y'); ?>" required readonly />
				</div>
				<br>
				<div class="panel-body">
				   <input type="submit" id="alert3" class="btn btn-system" title="It will delete all records of that vendor, should only be clicked when records are incorrect" value="Delete Records">
				</div>
				<?php echo form_close(); ?>
			
				<hr/>
				
				
                </div>
              </div>
            </div>
          </div>
		  

        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		<script>
			$("document").ready(function () {
				$("#alert,#alert1,#alert3").click(function(ev) {
					if( ! confirm("Do you really want to do this?") ){
						ev.preventDefault(false); // ! => don't want to do this
					}
				});
				setTimeout(function () {
					$("div.alert").remove();
				}, 5000); // 5 secs
			});
		</script>
      <!-- End of Footer Files -->
<!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->
</body>

</html>



