<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
//echo $controller_name; die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Verify PO Data Against Different Vendors</h1>
        
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-8 col-lg-7">

              <!-- Vendor Dropdown for Records Verification -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Verify Records</h6>
                </div>
                <div class="card-body">
					<!-- Standar Form -->
					<h4>Select Vendor</h4>
					<?php echo form_open(current_url(),array('name'=>'popup','id'=>'popup', 'class'=>'form-horizontal', 'method'=>'post', 'enctype'=>"multipart/form-data" )); ?>
					<?php if($this->session->flashdata('success_msg')) { ?>
						<div class="alert alert-success">
							<?php echo $this->session->flashdata('success_msg'); ?>
						</div>
					<?php } ?>
					<?php if(isset($error_msg)){ ?>
						<div class="alert alert-danger"><?php echo $error_msg;?></div>
					<?php }?>
					<?php if($this->session->flashdata('error_msg')) { ?>
						<div class="alert alert-danger">
							<?php echo $this->session->flashdata('error_msg'); ?>
						</div>
					<?php } ?>
					<?php 
						$vendor_id=0;
						if ($this->session->flashdata('vendor_id')) { $vendor_id = $this->session->flashdata('vendor_id'); } 
					?>
					
					<div class="input-group">
					  <select class="form-control bg-light border-0 small" name="fk_vendor_id">
							<?php foreach ($vendors as $row){ ?>
								<option value="<?php echo $row->vendor_id; ?>" <?php
								if($row->vendor_id == $_SESSION['fk_vendor_id']|| $row->vendor_id == $vendor_id){
									echo 'Selected';
								}
								?> >
									<?php echo $row->vendor_name .' '. $row->domain ; ?></option>
							<?php }?>
						</select>
					  <div class="input-group-append">
						<button type="submit" class="btn btn-system"  ><i class="fas fa-search fa-sm"></i> Refresh</button>
					  </div>
					</div>
					<?php echo form_close(); ?>
                </div>
              </div>
			  
			  <div class="row">

				<!-- Total PO Records -->
				<div class="col-xl-3 col-md-6 mb-4">
				  <div class="card border-left-success shadow h-100 py-2">
					<div class="card-body">
					  <div class="row no-gutters align-items-center">
						<div class="col mr-2">
						  <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total PO Records</div>
						  <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count; ?></div>
						</div>
					  </div>
					</div>
				  </div>
				</div>

				<!-- Distinct PO Records -->
				<div class="col-xl-3 col-md-6 mb-4">
				  <div class="card border-left-info shadow h-100 py-2">
					<div class="card-body">
					  <div class="row no-gutters align-items-center">
						<div class="col mr-2">
						  <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Distinct PO Records</div>
						  <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $distinct_po; ?></div>
						</div>
					  </div>
					</div>
				  </div>
				</div>

				<!-- Repeated Record -->
				<div class="col-xl-3 col-md-6 mb-4">
				  <div class="card border-left-danger shadow h-100 py-2">
					<div class="card-body">
					  <div class="row no-gutters align-items-center">
						<div class="col mr-2">
						  <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Repeated Records</div>
						  <div class="row no-gutters align-items-center">
							<div class="col-auto">
							  <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo(sizeof($repeated_dates)) ; ?></div>
							</div>
						  </div>
						</div>
					  </div>
					</div>
				  </div>
				</div>

				<!-- Available Records -->
				<div class="col-xl-3 col-md-6 mb-4">
				  <div class="card border-left-warning shadow h-100 py-2">
					<div class="card-body">
					  <div class="row no-gutters align-items-center">
						<div class="col mr-2">
						  <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available Records</div>
						  <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo(sizeof($date_records)); ?></div>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			  
			  
			  
			  <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-danger">Repeated Records</h6>
                </div>
                <div class="card-body">
				  <div class="container">
					 <div class="col-md-12 table-responsive">
							<table  class="table" id="dataTable"  cellspacing="0">
							<thead>
								 <tr>
									<th>Date</th>
									<th>Records</th>
								 </tr>
							  </thead>
								<tbody>
								<?php foreach ($repeated_dates as $dates){ ?>
									<tr class="danger">
										<td><?php echo $dates->Order_Date;  ?></td>
										<td><?php echo $dates->Repeated_Record ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
                </div>
              </div>	
			  
			  <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-info">Available Records</h6>
                </div>
                <div class="card-body">
					<div class="container">
						<div class="col-md-12 table-responsive">
							<table class="table" id="dataTable1" width="100%" cellspacing="0">
								<thead>
									 <tr>
										<th>Date</th>
										<th>Records</th>
									 </tr>
								  </thead>
								<tbody>
								<?php foreach ($date_records as $dated){ ?>
									<tr class="info">
										<td><?php echo $dated->dates;  ?></td>
										<td><?php echo $dated->cnt ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
						</div>
                     </div>
                </div>
              </div>	

            </div>

            <!-- Report Operations -->
            <div class="col-xl-4 col-lg-5">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Move or Delete Records</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
					
					<a id="alert" class="btn btn-primary btn-lg btn-block" href="<?php echo base_url('admin/reports/move_to_main'); ?>" title="You should only click this button when all records are verified. It will move the records to the main table">Move To Main</a>
					 <a id="alert1" class="btn btn-danger btn-lg btn-block" href="<?php echo base_url('admin/reports/delete_po'); ?>" title="It will delete all records of that vendor, should only be clicked when records are incorrect" name="delete">Delete Records</a>
                </div>
              </div>
			  
			  <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Operations</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                 <?php echo form_open('admin/reports/delete_po_selected',array('name'=>'popup','id'=>'popup', 'class'=>'form-horizontal', 'method'=>'post', 'enctype'=>"multipart/form-data" )); ?>
					<div class="input-group">
						<input type="date" name="date_selected" class="form-control" >
					</div><br>
					<div class="panel-body">
						<input type="submit" id="alert3" class="btn btn-system" title="It will delete all records of that vendor, should only be clicked when records are incorrect" value="Delete Records">
					</div>
					<?php echo form_close(); ?>
                </div>
              </div>
			  
            </div>
          </div>
        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		<script>
			 $("document").ready(function(){
				setTimeout(function(){
					$("div.alert").remove();
				}, 5000 ); // 5 secs

				});

				$("#alert,#alert1,#alert3").click(function(ev) {
					if( ! confirm("Do you really want to do this?") ){
						ev.preventDefault(false); // ! => don't want to do this
					}
				});
		</script>
      <!-- End of Footer Files -->
<!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->
</body>

</html>



