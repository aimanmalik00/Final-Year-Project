<?php $controller_name = $this->router->class;

$method_name = $this->router->method;
$custom_link = $controller_name . '/' . $method_name;
//echo $controller_name; die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('admin/includes/header'); ?>
	<?php $this->load->view('admin/includes/header_files');?>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
   <?php $this->load->view('admin/includes/side_bar');?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
			<?php $this->load->view('admin/includes/header_nav');?>
        <!-- End of Topbar -->
        <!-- Begin Page Content -->
		<div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">  Upload Monthly Inventory Reports</h1>
          
          <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">

              <!--  Form Area -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Select files from your computer</h6>
                </div>
                <div class="card-body">
				 <!-- Standar Form -->
                                
								
								
								 <?php echo form_open(current_url(), array('name' => 'popup', 'id' => 'popup', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
                               <?php if ($this->session->flashdata('success_msg')) { ?>
                                    <div class="alert alert-success">
                                        <?php echo $this->session->flashdata('success_msg'); ?>
                                    </div>
                                <?php } ?>
                                <?php if ($this->session->flashdata('empty_files')) { ?>
                                    <div class="alert alert-danger">
                                        <?php echo $this->session->flashdata('empty_files'); ?>
                                    </div>
                                <?php } ?>
                                <?php if ($this->session->flashdata('empty_filesweekly_inventory')) { ?>
                                    <div class="alert alert-danger">
                                        <?php echo $this->session->flashdata('empty_filesweekly_inventory'); ?>
                                    </div>
                                <?php } ?>
                                <?php if (isset($error_msg)) { ?>
                                    <div class="alert alert-danger"><?php echo $error_msg; ?></div>
                                <?php } ?>
                                <?php 
                                        $vendor_id=0;
                                        if ($this->session->flashdata('vendor_id')) { $vendor_id = $this->session->flashdata('vendor_id'); } 
                                    ?>
								<div class="form-horizontal">
                                    <div class="form-group">
										<label class="control-label" for="sel1">Select Vendor:</label>
										 <select class="form-control" name="fk_vendor_id">
                                            <?php foreach ($vendors as $row){ ?>
                                                <option value="<?php echo $row->vendor_id; ?>" <?php
                                                if ($this->session->has_userdata('fk_vendor_id')) {
                                                    echo($row->vendor_id == $_SESSION['fk_vendor_id']|| $row->vendor_id == $vendor_id  ? 'selected' : '');
                                                }
                                                ?>
                                                >
                                                    <?php echo $row->vendor_name .' '. $row->domain ; ?></option>
                                            <?php }?>
                                        </select>
									</div>
									
									<div class="form-group">
										<label class="control-label" for="data_files">Data File</label>
										<div class="col-sm-12">
											<input type="file" class="custom-file-input" id="data_files" name="data_files" accept=".csv,.xlsx"  required>
											<label class="custom-file-label" for="data_files">Choose file</label>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label" for="datefilter">Report Date Range</label>
										<input type="text" class="form-control" name="datefilter" value="<?php echo date('m/d/Y').' - '.date('m/d/Y'); ?>" required readonly />
									</div>
									<hr/>
									<div class="form-group">
										<button type="submit" class="btn btn-system uploadbtn" >Upload files</button>
									</div>
                                </div>
									
                                <?php echo form_close(); ?>
								
								
								
				<!-- End Form -->

                </div>
              </div>

              <!-- Frorm Area end -->
              

            </div>            
          </div>

        </div>
		
		
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('admin/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('admin/includes/footer_files');?>
		
		
		
		<script>
			$("document").ready(function () {
				$("#popup").submit(function (e) {
					//disable the submit button
					$(".uploadbtn").attr("disabled", true);
				});
				setTimeout(function () {
					$("div.alert").remove();
				}, 5000); // 5 secs
			});
			$(".custom-file-input").on("change", function() {
				  var fileName = $(this).val().split("\\").pop();
				  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
				});
		</script>
      <!-- End of Footer Files -->
	  <!-- Models  -->
		<?php $this->load->view('admin/includes/models');?>
      <!-- End of Models  -->

</body>

</html>



