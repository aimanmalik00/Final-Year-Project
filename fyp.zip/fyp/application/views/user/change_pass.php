
<!DOCTYPE html>
<html lang="en">

<head>

	<?php $this->load->view('user/includes/header'); ?>
	<?php $this->load->view('user/includes/header_files');?>
	
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

   <?php $this->load->view('user/includes/side_bar');?>
	
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
			<?php $this->load->view('user/includes/header_nav');?>
        <!-- End of Topbar -->
		
        <!-- Begin Page Content -->
        <div class="container-fluid">
		<!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Password Setting</h1>
		  <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">

              <!--  Form Area -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Change Password Here</h6>
                </div>
                <div class="card-body">
				<?php echo form_open('user/user/change_pass', array('name' => 'password', 'id' => 'password', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
				<?php if ($this->session->flashdata('success_msg')) { ?>
					<div class="alert alert-success">
						<?php echo $this->session->flashdata('success_msg'); ?>
					</div>
				<?php } ?>
				<?php if (isset($error_msg)) { ?>
					<div class="alert alert-danger"><?php echo $error_msg; ?></div>
				<?php } ?>
				<div class="form-group">
					<label class="control-label" for="old_pass">Old Password</label><span class="text-danger"> * </span>
					<input class="form-control" type="password" id="old_pass" name="old_pass" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="new_pass">New Password</label><span class="text-danger"> * </span>
					<input class="form-control" type="password" id="new_pass" name="new_pass" required>
				</div>
				<div class="form-group">
					<label class="control-label" for="conf_pass">Confirm Password</label><span class="text-danger"> * </span>
					<input class="form-control" type="password" id="conf_pass" name="conf_pass" required>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Change Password</button>
				</div>
				<?php echo form_close(); ?>
				<!-- End Form -->

                </div>
              </div>
            </div>            
          </div>
		  <!-- Page Content Here -->
        </div>
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->
      <!-- Footer -->
		<?php $this->load->view('user/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('user/includes/footer_files');?>
		<script>
			$("document").ready(function () {
				$("#popup").submit(function (e) {
					//disable the submit button
					$(".uploadbtn").attr("disabled", true);
					$(".uploadbtn").hide();
				});
				setTimeout(function () {
					$("div.alert").remove();
				}, 5000); // 5 secs
			});
		</script>
      <!-- End of Footer Files -->
	 <!-- Models  -->
		<?php $this->load->view('user/includes/models');?>
      <!-- End of Models  -->

</body>

</html>
