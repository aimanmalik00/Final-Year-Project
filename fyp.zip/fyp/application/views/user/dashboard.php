
<!DOCTYPE html>
<html lang="en">

<head>

	<?php $this->load->view('user/includes/header'); ?>
	<?php $this->load->view('user/includes/header_files');?>
	
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

   <?php $this->load->view('user/includes/side_bar');?>
	
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
			<?php $this->load->view('user/includes/header_nav');?>
        <!-- End of Topbar -->
		
        <!-- Begin Page Content -->
        <div class="container-fluid">
		<!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800">Tana BI</h1>
		  <small>Welcome to Tana Business Intelligence Reports</small>
		  <!-- Page Content Here -->
        </div>
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->



      <!-- Footer -->
		<?php $this->load->view('user/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('user/includes/footer_files');?>
      <!-- End of Footer Files -->
	 <!-- Models  -->
		<?php $this->load->view('user/includes/models');?>
      <!-- End of Models  -->

</body>

</html>
