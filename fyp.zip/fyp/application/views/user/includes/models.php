<!-- Logout Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModal" aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
		  <div class="modal-body">
			<!--  Form Area -->
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-system">System Logout Message</h6>
				</div>
				<div class="card-body">
				<div class="form-group">
					<input type="text" class="form-control" id="activate_vendor_id" name="activate_vendor_id" hidden required>
					<p>Are you sure, You are Logging out your System.</p>
				</div>
				<hr/>
				<div class="form-group">
						<a  class="btn btn-system uploadbtn" href="<?php echo base_url('user/logout')?>" >Logout</a>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
				</div>
				
				<!-- End Form -->

				</div>
		  </div>
		</div>
	  </div>
	</div>