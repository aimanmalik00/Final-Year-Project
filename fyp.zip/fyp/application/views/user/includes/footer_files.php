
<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url('/assets/vendor/jquery/jquery.min.js')?>"></script>
<script src="<?php echo base_url('/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo base_url('/assets/vendor/jquery-easing/jquery.easing.min.js')?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo base_url('/assets/js/sb-admin-2.min.js')?>"></script>

<!-- Page level plugins -->
<script src="<?php echo base_url('/assets/vendor/chart.js/Chart.min.js')?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo base_url('/assets/js/demo/chart-area-demo.js')?>"></script>
<script src="<?php echo base_url('/assets/js/demo/chart-pie-demo.js')?>"></script>



<!-- DataRangePicker Files -->
<script type="text/javascript" src="<?php echo base_url('/assets/js/jquery.min.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('/assets/js/moment.min.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('/assets/js/daterangepicker.min.js')?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/assets/css/daterangepicker.css')?>" />


<!-- DataRangePicker JS Function -->
<script type="text/javascript">
	$(function() {
		
		$("#alert,#alert1,#logout").click(function(ev) {
            if( ! confirm("Do you really want to do this?") ){
                ev.preventDefault(false); // ! => don't want to do this
            }
        });

		$('input[name="datefilter"]').daterangepicker({
			autoUpdateInput: false,
			locale: {
				cancelLabel: 'Clear'
			}
		});
		$('input[name="datefilter"]').on('apply.daterangepicker', function(ev, picker) {
			$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});
		$('input[name="datefilter"]').on('cancel.daterangepicker', function(ev, picker) {
			$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});
		$('input[name="datefilter1"]').daterangepicker({
			autoUpdateInput: false,
			locale: {
				cancelLabel: 'Clear'
			}
		});
		$('input[name="datefilter1"]').on('apply.daterangepicker', function(ev, picker) {
			$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});
		$('input[name="datefilter1"]').on('cancel.daterangepicker', function(ev, picker) {
			$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		}); 
		$('input[name="datefilter2"]').daterangepicker({
			autoUpdateInput: false,
			locale: {
				cancelLabel: 'Clear'
			}
		});
		$('input[name="datefilter2"]').on('apply.daterangepicker', function(ev, picker) {
			$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});
		$('input[name="datefilter2"]').on('cancel.daterangepicker', function(ev, picker) {
			$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
		});  
	});
	
</script>

<!-- Page level plugins -->
<script src="<?php echo base_url('/assets/vendor/datatables/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('/assets/vendor/datatables/dataTables.bootstrap4.min.js')?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo base_url('/assets/js/demo/datatables-demo.js')?>"></script>
