
<!DOCTYPE html>
<html lang="en">

<head>

	<?php $this->load->view('user/includes/header'); ?>
	<?php $this->load->view('user/includes/header_files');?>
	
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

   <?php $this->load->view('user/includes/side_bar');?>
	
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
			<?php $this->load->view('user/includes/header_nav');?>
        <!-- End of Topbar -->
		
        <!-- Begin Page Content -->
        <div class="container-fluid">
		<!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"> Add Vendor Code</h1>
		  <!-- Content Row -->
          <div class="row">

            <div class="col-xl-12 col-lg-12">

              <!--  Form Area -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-system">Upload Files CSV Formate</h6>
                </div>
                <div class="card-body">
				<?php echo form_open(current_url(), array('name' => 'popup', 'id' => 'popup', 'class' => 'form-horizontal', 'method' => 'post', 'enctype' => "multipart/form-data")); ?>
				<?php if ($this->session->flashdata('success_msg')) { ?>
					<div class="alert alert-success">
						<?php echo $this->session->flashdata('success_msg'); ?>
					</div>
				<?php } ?>
				<?php if ($this->session->flashdata('error_msg')) { ?>
					<div class="alert alert-danger">
						<?php echo $this->session->flashdata('error_msg'); ?>
					</div>
				<?php } ?>
				<?php if ($this->session->flashdata('verror_msg')) { ?>
					<div class="alert alert-danger">
						<?php echo $this->session->flashdata('verror_msg'); ?>
					</div>
				<?php } ?>
				<?php if ($this->session->flashdata('derror_msg')) { ?>
					<div class="alert alert-danger">
						<?php echo $this->session->flashdata('derror_msg'); ?>
					</div>
				<?php } ?>
				<?php if ($this->session->flashdata('totalerror_msg')) { ?>
					<div class="alert alert-danger">
						<?php echo $this->session->flashdata('totalerror_msg'); ?>
					</div>
				<?php } ?>
				<?php if ($this->session->has_userdata('totalValues')) { ?>
					<div class="">
						<?php $ArrayValue = $this->session->userdata('totalValues'); ?>
						<b>Total Values = </b><?= $ArrayValue['totalValue']; ?><br>
						<b>Total Inserted Values = </b><?= $ArrayValue['insetValue']; ?><br>
						<b>Total Repeated Values =</b> <?= $RepeatedValue = $ArrayValue['totalValue'] - $ArrayValue['insetValue']; ?>
						<?php if($RepeatedValue > 0):?>
							<div class="badge-danger" style="padding:20px;"
							><b>File Not Uploaded:</b> <?=$RepeatedValue?> repeated records found. Please remove repeated records and upload again.
							</div>
						<?php endif;?>
						<?php $this->session->unset_userdata('totalValues'); ?>
					</div>
					<hr>
				<?php } ?>
				<div class="form-group">
					<label class="control-label" for="files"> Kindly select file which include these columns <b>(Vendor Code, Distribution Type)</b> and have less then 1000 records</b></label><br/>
					<label class="control-label" for="files"> Select Vendor Code File</b></label>
					<div class="col-sm-12">
						<input type="file" class="custom-file-input" id="files" name="files" accept=".csv,.xlsx"  required>
						<label class="custom-file-label" for="files">Choose file</label>
					</div>
				</div>
				<hr/>
				<div class="form-group">
						<button type="submit" class="btn btn-system uploadbtn" >Upload Vendor File</button>
				</div>
				<?php echo form_close(); ?>
				<!-- End Form -->

                </div>
              </div>
            </div>            
          </div>
		  <!-- Page Content Here -->
        </div>
        <!-- /.container-fluid -->
	  </div>
      <!-- End of Main Content -->
      <!-- Footer -->
		<?php $this->load->view('user/includes/footer');?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

	 <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>

	  <!-- Footer Files -->
		<?php $this->load->view('user/includes/footer_files');?>
		<script>
			$("document").ready(function () {
				$("#popup").submit(function (e) {
					//disable the submit button
					$(".uploadbtn").attr("disabled", true);
					$(".uploadbtn").hide();
				});
				setTimeout(function () {
					$("div.alert").remove();
				}, 5000); // 5 secs
			});
			$(".custom-file-input").on("change", function() {
				  var fileName = $(this).val().split("\\").pop();
				  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
				});
		</script>
      <!-- End of Footer Files -->
	 <!-- Models  -->
		<?php $this->load->view('user/includes/models');?>
      <!-- End of Models  -->
</body>

</html>
